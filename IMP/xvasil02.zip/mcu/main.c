/*******************************************************************************
    main.c: LCD + keyboard demo
    
    Zmeny: 
    - Maroš Vasilišin
    - xvasil02
    - prebratý kód z dema LCD + keyboard demo, upravený pre potreby projektu
    - zmeny 95%
    - 10.12.2016


    Copyright (C) 2009 Brno University of Technology,
                      Faculty of Information Technology
    Author(s): Zdenek Vasicek <vasicek AT stud.fit.vutbr.cz>

    LICENSE TERMS

    Redistribution and use in source and binary forms, with or without
    modification, are permitted provided that the following conditions
    are met:
    1. Redistributions of source code must retain the above copyright
      notice, this list of conditions and the following disclaimer.
    2. Redistributions in binary form must reproduce the above copyright
      notice, this list of conditions and the following disclaimer in
      the documentation and/or other materials provided with the
      distribution.
    3. All advertising materials mentioning features or use of this software
      or firmware must display the following acknowledgement:

        This product includes software developed by the University of
        Technology, Faculty of Information Technology, Brno and its
        contributors.

    4. Neither the name of the Company nor the names of its contributors
      may be used to endorse or promote products derived from this
      software without specific prior written permission.

    This software or firmware is provided ``as is'', and any express or implied
    warranties, including, but not limited to, the implied warranties of
    merchantability and fitness for a particular purpose are disclaimed.
    In no event shall the company or contributors be liable for any
    direct, indirect, incidental, special, exemplary, or consequential
    damages (including, but not limited to, procurement of substitute
    goods or services; loss of use, data, or profits; or business
    interruption) however caused and on any theory of liability, whether
    in contract, strict liability, or tort (including negligence or
    otherwise) arising in any way out of the use of this software, even
    if advised of the possibility of such damage.

    $Id$


*******************************************************************************/

// makrá pre vlastné značky semaforu, stavy červená, zelená, oranžová a červeno-oranžová
#define R '\x2'
#define RY '\x3'
#define Y '\x4'
#define G '\x5'

#include <fitkitlib.h>
#include <keyboard/keyboard.h>
#include <lcd/display.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>

// maximálny dlhý string pre čítanie z command line
unsigned char str_tmp[MAX_COMMAND_LEN+1];

// posledný prečítaný znak z klávesnice
char last_ch;

// čítače hodín, minút a sekúnd aktuálneho času, počiatočný stav je 12:00:00
unsigned char clk_h = 12;
unsigned char clk_m = 0;
unsigned char clk_s = 0;

// príznak pre počítanie času pre simuláciu
unsigned short sec_cnt;

// den/noc
char mode_day_night = 'D';

// stop/off/normal mode
char mode_state = 'N';
// buduci nastaveny stav - pri normal mode
char mode_state_future = 'N';

// typ reaktivity -- normal/urgent
char rtype = 'N';

// semafory aut pre smery sever/juh (NS) a vychod/zapad (EW)
char NS_car_light, EW_car_light;

// semafory chodcov pre oba smery a obrazky panacikov
char NS_ped_light, EW_ped_light, NS_ped_img, EW_ped_img;

// countery cyklov pre semafory chodcov
char NS_cycle, EW_cycle;

// countery pre semafory aut
char NS_car_light_cnt;
char EW_car_light_cnt;

// pocty aut a chodcov na jednotlivych smeroch
int NS_ped_count, EW_ped_count;
int N_car_count, S_car_count, E_car_count, W_car_count;

// celkovy pocet aut a chodcov
int all_ped_count;
int all_car_count;

// priznaky ci prisli nejaki chodci na semafor
bool NS_is_ped = false;
bool EW_is_ped = false;

// countery pre blikanie lediek
unsigned int NS_led_cnt = 5;
unsigned int EW_led_cnt = 5;


// obrazky symbolizujuce panacika + stavy na semaforoch
unsigned char pedestrian_image[8] = {0x0e, 0x0e, 0x04, 0x1f, 0x04, 0x0e, 0x11, 0x00};
unsigned char red_light[8] = {0x1f, 0x1f, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
unsigned char yellow_light[8] = {0x00, 0x00, 0x00, 0x1f, 0x1f, 0x00, 0x00, 0x00};
unsigned char red_yellow_light[8] = {0x1f, 0x1f, 0x00, 0x1f, 0x1f, 0x00, 0x00, 0x00};
unsigned char green_light[8] = {0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x1f, 0x1f};

// vypis napovedy (funkcia sa vola pri vykonavani prikazu "help")
void print_user_help(void) {
    term_send_str_crlf(" Ovladanie krizovatky:");
    term_send_str_crlf(" A : Day/Night");
    term_send_str_crlf(" B : Stop/Off/Normal");
    term_send_str_crlf(" C : Normal/Urgent");
    term_send_str_crlf("----------------------");
    term_send_str_crlf(" 2 : Sever : auto++");
    term_send_str_crlf(" 8 : Juh : auto++");
    term_send_str_crlf(" 6 : Vychod : auto++");
    term_send_str_crlf(" 4 : Zapad : auto++");
    term_send_str_crlf("----------------------");
    term_send_str_crlf(" * : SJ : chodec++");
    term_send_str_crlf(" # : VZ : chodec++");
    term_send_str_crlf("----------------------");
    term_send_str_crlf(" Ovladanie cez terminal: ");
    term_send_str_crlf(" SET HH:MM:SS  ... zmena casu");
}

// vypis stavov krizovatky - vola sa kazdych 10 sekund
void print_cnt_states(){
    char tmp[100]; 
    term_send_str_crlf("**************************************");
    sprintf (tmp, "* Cas: %d:%d:%d", clk_h, clk_m, clk_s);
    term_send_str_crlf(tmp);
    sprintf (tmp, "* Pocet aut ktore celkovo presli krizovatkou: %d", all_car_count);
    term_send_str_crlf(tmp);
    sprintf (tmp, "* Aktualny pocet aut zo smerov: S: %d, J: %d, Z: %d, V: %d", N_car_count,
            S_car_count, W_car_count, E_car_count);
    term_send_str_crlf(tmp);
    sprintf (tmp, "* Pocet chodcov ktori celkovo presli krizovatkou: %d", all_ped_count);
    term_send_str_crlf(tmp);
    sprintf (tmp, "* Aktualny pocet chodcov zo smeru: SJ: %d, VZ: %d", NS_ped_count,EW_ped_count);
    term_send_str_crlf(tmp);
    term_send_str_crlf("**************************************");
    term_send_str_crlf("");
}

// nastavenie buduceho stavu
void set_future_state(bool is_mode_state_future_set) {

    char value = is_mode_state_future_set ? mode_state_future : mode_state;

    if (value == 'N') {
        mode_state_future = 'S';
        term_send_str_crlf("Bude nastaveny: stop mode");
    }
    else if (value == 'S') {
        mode_state_future = 'O';
        term_send_str_crlf("Bude nastaveny: off mode");
    }
    else {
        mode_state_future = 'N';
        term_send_str_crlf("Bude nastaveny: normal mode");
    }
}

//  obsluha klavesnice
int keyboard_idle() {
    char ch;
    ch = key_decode(read_word_keyboard_4x4());
    if (ch != last_ch) 
    {
        last_ch = ch;
        if (ch != 0) 
        {
            switch (ch){
                case 'A':
                    if (rtype == 'U') { // zmenit den/noc instantne sa da len v urgent mode
                        if (mode_day_night == 'D') {
                            mode_day_night = 'N';
                            clk_h = 23;
                            clk_m = 0;
                            clk_s = 0;
                            term_send_str_crlf("Nastaveny stav: noc");
                        }
                        else {
                            mode_day_night = 'D';
                            clk_h = 4;
                            clk_m = 0;
                            clk_s = 0;
                            term_send_str_crlf("Nastaveny stav: den");
                        }
                    }
                    break;
                case 'B':
                    if (rtype == 'U') { //v urgente sa zmeny prejavia okamzite
                        if (mode_state == 'N') {
                            mode_state = 'S';
                            term_send_str_crlf("Nastaveny: stop mode");
                        }
                        else if (mode_state == 'S') {
                            mode_state = 'O';
                            term_send_str_crlf("Nastaveny: off mode");
                        }
                        else {
                            mode_state = 'N';
                            term_send_str_crlf("Nastaveny: normal mode");
                        }
                    }
                    else { //v normale sa zmena prejavi az na konci cyklu
                        if (mode_state_future == 'N') {
                            set_future_state(false);
                        }
                        else {
                            set_future_state(true);
                        }
                    }
                    break;
                case 'C':
                    if (rtype == 'U') {
                      rtype = 'N';
                      term_send_str_crlf("Nastaveny: normal rtype");
                    }
                    else {
                      rtype = 'U';
                      term_send_str_crlf("Nastaveny: urgent rtype");
                    }
                    break;
                case '2':
                    N_car_count++;
                    all_car_count++;
                    break;
                case '4':
                    W_car_count++;
                    all_car_count++;
                    break;
                case '6':
                    E_car_count++;
                    all_car_count++;
                    break;
                case '8':
                    S_car_count++;
                    all_car_count++;
                    break;
                case '*':
                    if (NS_ped_light == R){
                        NS_cycle = 3;
                        NS_is_ped = true;
                    }
                    NS_ped_count++;
                    all_ped_count++;
                    break;
                case '#':
                    if (EW_ped_light == R) {
                        EW_cycle = 3;
                        EW_is_ped = true;
                    }
                    EW_ped_count++;
                    all_ped_count++;
                    break;
            }
        }
    }
    return 0;
}

// prevod dat od uzivatela
unsigned char *get_data(unsigned char *str, int len) {
    
    int i, j = len-1;

    str_tmp[8] = 0;  
    for (i = (strlen(str) - 1); i >= (strlen(str) - len); i--) {
        str_tmp[j] = str[i];
        j--;
    }

    return(str_tmp);
}

// dekodovanie prikazu z terminalu
unsigned char decode_user_cmd(char *cmd_ucase, char *cmd) {
    
    unsigned char data[8];
    unsigned char tmp_clk_s, tmp_clk_m, tmp_clk_h;

    if (strcmp4(cmd_ucase, "SET ")) {
        term_send_str("Hodiny nastavene na: ");
        strcpy(data, get_data(cmd, 8));
        term_send_str_crlf(data);

        tmp_clk_h = (data[0] - 48) * 10 + (data[1] - 48);   // hh
        tmp_clk_m = (data[3] - 48) * 10 + (data[4] - 48);   // mm
        tmp_clk_s = (data[6] - 48) * 10 + (data[7] - 48);   // ss

        if(tmp_clk_s >= 60 || tmp_clk_m >= 60 || tmp_clk_h >= 24){
            term_send_str("Nespravny format casu");
        }
        else{
            clk_h = tmp_clk_h;
            clk_m = tmp_clk_m;
            clk_s = tmp_clk_s;
        }
    } 
    else {
        return CMD_UNKNOWN;
    }

    return USER_COMMAND;
}

// vypis aktualneho casu na LCD
void print_time(){

    LCD_send_cmd(LCD_SET_DDRAM_ADDR | (LCD_FIRST_HALF_OFS + 0x08), 0); 
    LCD_send_cmd((unsigned char)(clk_h / 10) + 48, 1);    // HH
    LCD_send_cmd((unsigned char)(clk_h % 10) + 48, 1); 
    LCD_send_cmd(':', 1); 
    LCD_send_cmd((unsigned char)(clk_m / 10) + 48, 1);    // MM
    LCD_send_cmd((unsigned char)(clk_m % 10) + 48, 1);    
    LCD_send_cmd(':', 1);
    LCD_send_cmd((unsigned char)(clk_s / 10) + 48, 1);    // SS
    LCD_send_cmd((unsigned char)(clk_s % 10) + 48, 1);

}

// vypis zebry
void print_zebra(){
    
    LCD_send_cmd(LCD_SET_DDRAM_ADDR | (LCD_SECOND_HALF_OFS + 2), 0);
    LCD_send_cmd(NS_ped_img, 1); 
    LCD_send_cmd(NS_ped_light, 1);
    LCD_send_cmd('#', 1);
    LCD_send_cmd(EW_ped_light, 1);
    LCD_send_cmd(EW_ped_img, 1);
}

// vypis krizovatiek
void print_crossroad(){

    LCD_send_cmd(LCD_SET_DDRAM_ADDR | LCD_SECOND_HALF_OFS, 0); 
    LCD_send_cmd(NS_car_light, 1);
    LCD_send_cmd(' ', 1);
    print_zebra();
    LCD_send_cmd(LCD_SET_DDRAM_ADDR | (LCD_SECOND_HALF_OFS + 7), 0); 
    LCD_send_cmd(' ', 1);
    LCD_send_cmd(EW_car_light, 1);
}

// vypis rezimov na displej
void print_modes(){

    LCD_send_cmd(LCD_SET_DDRAM_ADDR | LCD_FIRST_HALF_OFS, 0);
    LCD_send_cmd(mode_day_night, 1);
    LCD_send_cmd(mode_state, 1);
    LCD_send_cmd(rtype, 1);
}

// prepis displeja
void repaint() {
    print_modes();
    print_crossroad();
    print_time();
}

// inicializacia periferii/komponent pre naprogramovanie FPGA
void fpga_initialized() {
    LCD_init();
    LCD_clear();

    //inicializacie vlastnych znakov
    LCD_load_char(1, pedestrian_image); 
    LCD_load_char(2, red_light);
    LCD_load_char(3, red_yellow_light);
    LCD_load_char(4, yellow_light);
    LCD_load_char(5, green_light);
    repaint();
}

// Nastavi semafory na povodne hodnoty
void init_lights() {
    
    NS_car_light = R;
    EW_car_light = R;
    NS_ped_light = R;
    EW_ped_light = R;
    NS_ped_img = ' ';
    EW_ped_img = ' ';
}


// nastavi countery na povodne hodnoty
void init_counters() {
    
    NS_car_light_cnt = 0;
    EW_car_light_cnt = 7; // kvoli synchronizacii
    NS_cycle = 0;
    EW_cycle = 0;
    NS_ped_count = EW_ped_count = 0;
    N_car_count = S_car_count = E_car_count = W_car_count = 0;
}

// inicializacia premennych
void init() {

    init_lights();
    init_counters();
}

// zmena stavu semaforov chodcov
void change_ped_sem_state(char light, bool is_NS){
    is_NS ? (NS_ped_light = light) : (EW_ped_light = light); 
}

// odobranie chodcov z oboch smerov pri zelenej
void remove_peds (bool is_NS) {

    if (is_NS) {
        NS_ped_count -= 15;
        if (NS_ped_count < 0)
            NS_ped_count = 0;
    }
    else {     
        EW_ped_count -= 15;
        if (EW_ped_count < 0)
            EW_ped_count = 0;
    }
}

// odobranie aut z oboch smerov pri zelenej
void remove_cars (bool is_NS) {

    if (is_NS) {
        N_car_count -= 8;
        S_car_count -= 8;
        if (N_car_count < 0)
            N_car_count = 0;
        if (S_car_count < 0)
            S_car_count = 0;
    }
    else {     
        E_car_count -= 8;
        W_car_count -= 8;
        if (E_car_count < 0)
            E_car_count = 0;
        if (W_car_count < 0)
            W_car_count = 0;
    }
}

// zmena stavov semaforov aut
void change_car_sem_state(){
    
    NS_car_light_cnt++;
    EW_car_light_cnt++;
    
    switch(NS_car_light) {
        case R:
            if (NS_car_light_cnt == 1) {
                if (NS_cycle >= 3) {
                    change_ped_sem_state(G,true);
                    NS_is_ped = false;
                }
            }
            if (NS_car_light_cnt == 8) {
                NS_car_light_cnt = 0;
                NS_car_light = RY;
                if (NS_cycle >= 3) {
                    change_ped_sem_state(R,true);
                    if (!NS_is_ped) {
                        NS_cycle = 0;
                        remove_peds(true);
                    }
                }
            } 
            break;
        case RY:
            if (NS_car_light_cnt == 1) {
                NS_car_light_cnt = 0;
                NS_car_light = G;
            }  
            break;
        case Y:
            if (NS_car_light_cnt == 1) {
                NS_car_light_cnt = 0;
                NS_car_light = R;
                NS_cycle++;
            }  
            break;
        case G:
            if (NS_car_light_cnt == 4) {
                NS_car_light_cnt = 0;
                NS_car_light = Y;
                remove_cars(true);  
            }  
            break;
        default:
            term_send_str_crlf("Chybny stav v change_sem_state");
    }

    switch(EW_car_light) {
        case R:
            if (EW_car_light_cnt == 1) {
                if (EW_cycle >= 3){
                    change_ped_sem_state(G,false);
                    EW_is_ped = false;
                }
            }
            if (EW_car_light_cnt == 8) {
                EW_car_light_cnt = 0;
                EW_car_light = RY;
                if (EW_cycle >= 3) {
                    change_ped_sem_state(R,false);
                    if (!EW_is_ped) {
                        remove_peds(false);
                        EW_cycle = 0;
                    }
                }
            }                
            break;
        case RY:
            if (EW_car_light_cnt == 1) {
                EW_car_light_cnt = 0;
                EW_car_light = G;
            }  
            break;
        case Y:
            if (EW_car_light_cnt == 1) {
                EW_car_light_cnt = 0;
                EW_car_light = R;
                EW_cycle++;
            }  
            break;
        case G:
            if (EW_car_light_cnt == 4) {
                EW_car_light_cnt = 0;
                EW_car_light = Y;
                remove_cars(false);
            }  
            break;
        default:
            term_send_str_crlf("Chybny stav v change_sem_state");
    }
}

// nastavi svetla chodcov na farbu light_color
void set_ped_lights(char light_color) {
    NS_ped_light = EW_ped_light = light_color;
}

// nastavi svetla aut na farbu light_color
void set_car_lights(char light_color) {
    NS_car_light = EW_car_light = light_color;
}

// nastavi vsetky svetla na farbu light_color
void set_all_lights(char light_color) {
    set_car_lights(light_color);
    set_ped_lights(light_color);
}

// nocny rezim
void set_night_mode(){
    
    if (EW_car_light == 'x') {
        set_car_lights(Y);
    }
    else {
       set_all_lights('x'); 
    }
    NS_ped_img = ' ';
    EW_ped_img = ' ';
}

// denny rezim
void set_day_mode(){
    init();
}

// ak je naplanovana zmena stavu tak zapnut
void change_planned_future() {

    if (mode_state_future == 'S') {
        mode_state = 'S';
    }
    else if (mode_state_future == 'O') {
        mode_state = 'O';
    }
    else {
        mode_state = 'N';
    }
    mode_state_future = 'N';
}

// zmena rezimu den/noc
void change_day_night(){

    if ((clk_h == 23 && clk_m == 0 && clk_s == 1)) { // zaciatok noci
        change_planned_future();
        term_send_str_crlf("Zacina noc");
        mode_day_night = 'N';
        set_night_mode();
    }
    if ((clk_h == 4 && clk_m == 0 && clk_s == 0)) { // zaciatok dna
        change_planned_future();
        term_send_str_crlf("Zacina den");
        mode_day_night = 'D';  
        set_day_mode();
    }
}

// zmena obrazkov na semaforoch
void change_ped_symbol() {
    NS_ped_img = (NS_car_light == R) ? ' ' : '\x1';
    EW_ped_img = (EW_car_light == R) ? ' ' : '\x1';
}

// nastavenie svetiel podla modu
void change_lights_state() {
    
    switch(mode_state){
        case 'N':
            if (mode_day_night == 'D') {
                if (EW_car_light == 'x') {
                    init();
                }
                else {
                    change_car_sem_state();
                    change_ped_symbol();
                }
            }
            else {
                set_night_mode();
            }
            break;
        case 'O': 
            set_all_lights('x');
            break;
        case 'S': 
                set_all_lights(R);
            break;
        default:
            term_send_str_crlf("Chybny stav");
    }
}

// zmena NS ledky
void change_NS_led_light(){
    
    if (NS_ped_count > 0 && NS_ped_light == R) {
        if (NS_led_cnt > 5) {
            flip_led_d5();
            NS_led_cnt = 0;
        }
        
    }
    else if (NS_ped_light == G) {
        flip_led_d5();
    }
    else
        set_led_d5(0);
}

// zmena EW ledky
void change_EW_led_light(){
    
    if (EW_ped_count > 0 && EW_ped_light == R) {
        if (EW_led_cnt > 5) {
            flip_led_d6();
            EW_led_cnt = 0;
        }
    }
    else if (EW_ped_light == G) {
        flip_led_d6();
    }
    else
        set_led_d6(0);
}

// zmena casu
void change_time(){
    
    clk_s++; 
    
    if (clk_s == 60) {
        clk_m++;
        clk_s = 0;
    }
    if (clk_m == 60) {
        clk_h++;
        clk_m = 0;  
    }     
    if (clk_h == 24) {
        clk_h = clk_m = clk_s = 0;
    }
    change_day_night();
    change_lights_state();
}

int main(void) {

    unsigned int cnt = 0;
    last_ch = 0;

    init();
    initialize_hardware();
    keyboard_init();

    CCTL0 = CCIE; // rezim vystupnej komparacie 
    CCR0 = 0x1000; // nastavenie prerusenia na 1 sekundu
    TACTL = TASSEL_1 + MC_2; 
    
    set_led_d5(0);
    set_led_d6(0);
    
    while (1) {
        
        repaint();
        delay_ms(100);
        
        cnt++;
        NS_led_cnt++;
        EW_led_cnt++;
        
        if (cnt == 100) {
            print_cnt_states();
            cnt = 0;
        }
        
        change_NS_led_light();
        change_EW_led_light();
        keyboard_idle(); // obsluha klavesnice
        terminal_idle(); // obsluha terminalu
    }         
}

interrupt (TIMERA0_VECTOR) Timer_A (void) {
    
    CCR0 += 0x1000;
    sec_cnt++;
    
    if (sec_cnt >= 8) { // ak presla sekunda
        sec_cnt = 0;
        change_time();
    }
}

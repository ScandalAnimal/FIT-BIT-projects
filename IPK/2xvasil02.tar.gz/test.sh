#!/bin/sh

# ************************************* #
# IPK 2. projekt - demonstracny skript  #
# Autor: Maros Vasilisin                #
# Login: xvasil02                       #
# Datum poslednej upravy: 23.04.2016    #
# ************************************* #


# prelozenie zdrojovych suborov
make

# nahodne vypocitanie portu
PORT=`awk 'BEGIN{srand();print int(rand()*(63000-2000))+2000 }'`

# vytvorenie zloziek pre server a client
mkdir -p -m 777 server_dir
mkdir -p -m 777 client_dir

# prekopirovanie spustitelnych suborov do odpovedajucich zloziek
mv server server_dir
mv client client_dir

# prekopirovanie suborov urcenych na prenos
cp llfd.jpg server_dir
cp mickey.txt server_dir
cp barcelona.jpg client_dir
cp joke.txt client_dir

# spustenie servera, priradenie PID servera do premennej
cd server_dir
./server -p $PORT & export S_PID=$!

# sleep 2
cd ../client_dir

# spustenie clienta viackrat pre demonstraciu forku
./client -h localhost -p $PORT -d llfd.jpg
./client -h localhost -p $PORT -d mickey.txt
./client -h localhost -p $PORT -u barcelona.jpg
./client -h localhost -p $PORT -u joke.txt

cd ..


# porovnanie vyslednych suborov na urcenie spravnosti prenosu
diff server_dir/llfd.jpg client_dir/llfd.jpg
if [ $? -eq 0 ]
then
  echo "Test 01: Download jpg - OK"
else
  echo "Test 01: Download jpg - PROBLEM"
fi
diff server_dir/mickey.txt client_dir/mickey.txt
if [ $? -eq 0 ]
then
  echo "Test 02: Download txt - OK"
else
  echo "Test 02: Download txt - PROBLEM"
fi
diff server_dir/barcelona.jpg client_dir/barcelona.jpg
if [ $? -eq 0 ]
then
  echo "Test 03: Upload jpg - OK"
else
  echo "Test 03: Upload jpg - PROBLEM"
fi
diff server_dir/joke.txt client_dir/joke.txt
if [ $? -eq 0 ]
then
  echo "Test 04: Upload txt - OK"
else
  echo "Test 04: Upload txt - PROBLEM"
fi

# nakoniec vypnutie serveru
kill $S_PID
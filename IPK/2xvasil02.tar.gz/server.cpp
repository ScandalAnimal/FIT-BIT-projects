/*
 *  server.cpp
 *
 *  Created on: 17. 4. 2016
 *  Author: Maroš Vasilišin
 *  Login: xvasil02
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>
#include <string>
#include <cstdio>
#include <string.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>

using namespace std;


// funkcia na parsovanie argumentov skriptu

bool parseArguments(int argc, char *argv[], int &port) {

    if (argc != 3) {
        return false;
    }

	if (strcmp(argv[1],"-p") == 0) {
        for (int i = 0; i < ((string)argv[2]).size(); i++) {
            if (!isdigit(argv[2][i]))
                return false;
        }
        port = atoi(argv[2]);
    }
    else 
        return false;

    return true;
}

int main(int argc, char *argv[]) {

    string message,action,filename,response;
    pid_t pid;

    int my_port;
    if (!parseArguments(argc,argv,my_port)) {
        fputs("Invalid parameters\n", stderr);
        exit(1);
    }

    int my_socket, acc_socket;

    my_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (my_socket < 0) {
        fputs("Error in socket()\n", stderr);
        exit(1);
    }

    struct sockaddr_in my_addr;
    memset(&my_addr, 0, sizeof(my_addr));

    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(my_port);
    
    my_addr.sin_addr.s_addr = INADDR_ANY;

    int res = bind(my_socket, (struct sockaddr*) &my_addr, sizeof(my_addr));
    if (res < 0) {
        fputs("Error in bind()\n", stderr);
        exit(1);
    }

    res = listen(my_socket, 2);
    if (res < 0) {
        fputs("Error in listen()\n", stderr);
        exit(1);
    }

    // nekonecny cyklus, server sa nikdy nezavrie, caka na ukoncenie od uzivatela
    while (true) {

        acc_socket = accept(my_socket, NULL, NULL);
        if (acc_socket < 0) {
            fputs("Error in accept()\n", stderr);
            exit(1);
        }

        // kazda nova poziadavka dostane vlastny proces , ktory je child od rodicovskeho procesu
        if ((pid = fork()) > 0) { 
            close(acc_socket);
            waitpid(-1, 0, 0); // -1 oznacuje ze cakame na akykolvek child proces (nekonecny cyklus)
        }
         else if (pid == 0) { // ak sme v childe

            close(my_socket);
            char request[1024] = {};
            int rcv;
            int x;

            while (true) { // nacitavame spravu z klienta az kym nenarazime na \r\n\r\n
                
                memset(&request[0], 0, sizeof(request));
                
                rcv = recv(acc_socket, request, 1024, 0);
                if (rcv > 0) {
                    message.append(request, rcv);
                }
                if (rcv == -1) {
                    fputs("Error in recv()\n", stderr);
                    exit(1);
                }
                x = message.find("\r\n\r\n");
                if (x != string::npos) {
                    break;
                }
            }


            int pos;
            // zo spravy vymazeme klucove slova , a vlozime do premennych akciu, a nazov suboru
            message.erase(0, 7); 
            pos = message.find("\n");
            if (pos != string::npos) {
                action = message.substr(0,pos);
                message = message.substr(pos,message.length());
            }
            else {
                fputs("Error in request\n", stderr);
                exit(1);
            }
            
            message.erase(0, 5);
            pos = message.find("\n");
            if (pos != string::npos) {
                filename = message.substr(2,pos-2);
            }
            else {
                fputs("Error in request\n", stderr);
                exit(1);
            }

            // ak je upload tak posleme spravu OK
            if (action.compare(" upload") == 0) {
                response = "OK\r\n\r\n";
            }
            // ak je download musime zistit ci subor existuje, a podla toho poslat spravu
            else if (action.compare(" download") == 0) {
                ifstream sendingFile;
                sendingFile.open(filename.c_str(), ios::in | ios::binary);
                if (sendingFile.fail() == true) {
                    response = "XX\r\n\r\n";
                }
                else {
                    stringstream buffer;
                    buffer << sendingFile.rdbuf();
                    response = "OK\n" + buffer.str() + "\r\n\r\n";
                }
                sendingFile.close();
            }
            else {
                fputs("Error in request\n", stderr);
                exit(1);
            }

            // odosleme spravu naspat klientovi
            send(acc_socket, response.data(), response.size(), 0);

            if (action.compare(" upload") == 0) {

                message = "";
                // ak je akcia upload, tak cakame na spravu od klienta, ktora obsahuje nahravany subor
                while (true) {
                
                    memset(&request[0], 0, sizeof(request));
                    
                    rcv = recv(acc_socket, request, 1024, 0);
                    if (rcv > 0) {
                        message.append(request, rcv);
                    }
                    if (rcv == -1) {
                        fputs("Error in recv()\n", stderr);
                        exit(1);
                    }
                    x = message.find("\r\n\r\n");
                    if (x != string::npos) {
                        break;
                    }
                }

                // zmazeme hlavicku
                if (message.compare(0, 2, "OK") == 0) {
                    message = message.substr(3, message.length());
                }
                else {
                    fputs("Error on client\n", stderr);
                    exit(1);
                }

                pos = message.find("\r\n\r\n");
                if (pos != string::npos) {
                    message = message.substr(0, pos);
                }
                else {
                    fputs("Error in request\n", stderr);
                    exit(1);
                }

                // zapiseme obsah suboru do noveho suboru
                ofstream downloaded;
                downloaded.open(filename.c_str(), ofstream::out | ofstream::binary);
                downloaded << message;
                downloaded.close();

            }
            close(acc_socket);
            exit(0);
        }
        else {
            fputs("Error in fork()\n", stderr);
            close(my_socket);
            exit(1);
        }
    }

    close(my_socket);
    return 0;
}
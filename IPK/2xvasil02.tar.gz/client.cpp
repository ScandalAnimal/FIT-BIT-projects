/*
 *  client.cpp
 *
 *  Created on: 17. 4. 2016
 *  Author: Maroš Vasilišin
 *  Login: xvasil02
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <string>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>

using namespace std;

typedef struct arguments {
    string hostname;
    int port;
    string action;
    string file;
    bool was_h;
    bool was_p;
    bool was_d;
    bool was_u;
} arguments;

// funkcia na spracovanie argumentov
bool parseArguments(int argc, char *argv[], arguments &arg) {

    if (argc != 7) {
        return false;
    }

    arg.was_h = arg.was_u = arg.was_d = arg.was_p = false;

    for (int a = 1; a < argc; a+=2) {
        if (strcmp(argv[a],"-h") == 0) {
            if (arg.was_h == true)
                return false;
            arg.was_h = true;
            arg.hostname = argv[a+1];
        }
        else if (strcmp(argv[a],"-p") == 0) {
            if (arg.was_p == true)
                return false;
            arg.was_p = true;
            for (int i = 0; i < ((string)argv[a+1]).size(); i++) {
                if (!isdigit(argv[a+1][i]))
                    return false;
            }
            arg.port = atoi(argv[a+1]);
        }
        else if (strcmp(argv[a],"-d") == 0) {
            if (arg.was_d == true)
                return false;
            arg.was_d = true;
            arg.action = "download";
            arg.file = argv[a+1];
        }
        else if (strcmp(argv[a],"-u") == 0) {
            if (arg.was_u == true)
                return false;
            arg.was_u = true;
            arg.action = "upload";
            arg.file = argv[a+1];
        }
        else 
            return false;
    }

    if (arg.was_p == false || arg.was_h == false)
        return false;
    return true;
}

int main(int argc, char *argv[]) {

    arguments arg;
    if (!parseArguments(argc,argv,arg)) {
        fputs("Invalid parameters\n", stderr);
        exit(1);
    }

    int my_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (my_socket < 0) {
        fputs("Error in socket()\n", stderr);
        exit(1);
    }

    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(arg.port);

    struct hostent *server_name;
    server_name = gethostbyname(arg.hostname.c_str()); 
    if (server_name == NULL) {
        fputs("Error in gethostbyname()\n", stderr);
        exit(1);
    }

    memcpy(&(server_addr.sin_addr), server_name->h_addr, server_name->h_length);

    if (connect(my_socket, (sockaddr*) &server_addr, sizeof(server_addr)) == -1) {
        fputs("Error in connect()\n", stderr);
        exit(1);
    }

    string message,response;

    message = ("Action: " + arg.action + "\n" + "File: " + arg.file + "\n\r\n\r\n");

    // posleme spravu na server s tym co chceme vykonat
    send(my_socket, message.data(), message.size(), 0);

    char request[1024] = {};
    int rcv;
    int x,pos;

    // cakame na odpoved zo serveru
    while (true) {
        
        memset(&request[0], 0, sizeof(request));
        
        rcv = recv(my_socket, request, 1024, 0);
        if (rcv > 0) {
            response.append(request, rcv);
        }
        if (rcv == -1) {
            fputs("Error in recv()\n", stderr);
            exit(1);
        }
        x = response.find("\r\n\r\n");
        if (x != string::npos) {
            break;
        }
    }

    pos = response.find("\r\n\r\n");
    if (pos != string::npos) {
        response = response.substr(0, pos);
    }    
    else {
        fputs("Error in response\n", stderr);
        exit(1);
    }

    if (arg.action.compare("download") == 0) {

        if (response.compare(0, 2, "OK") == 0) {
            response = response.substr(3, response.length());
        }
        else {
            fputs("Error on server\n", stderr);
            exit(1);
        }

        // ak je download tak si ulozime obsah spravy do suboru
        ofstream downloaded;
        downloaded.open(arg.file.c_str(), ofstream::out | ofstream::binary);
        downloaded << response;
        downloaded.close();
    }
    else if (arg.action.compare("upload") == 0) {
        // pri uploade posielame druhu spravu s obsahom nahravaneho suboru
        if (response.compare(0, 2, "OK") == 0) {
            
            ifstream sendingFile;
            sendingFile.open(arg.file.c_str(), ios::in | ios::binary);
            if (sendingFile.fail() == true) {
                response = "XX\r\n\r\n";
            }
            else {
                stringstream buffer;
                buffer << sendingFile.rdbuf();
                response = "OK\n" + buffer.str() + "\r\n\r\n";
            }
            sendingFile.close();

            send(my_socket, response.data(), response.size(), 0);
        }
        else {
            fputs("Error on server\n", stderr);
            exit(1);
        }
    }

    close(my_socket);
    return 0;
}
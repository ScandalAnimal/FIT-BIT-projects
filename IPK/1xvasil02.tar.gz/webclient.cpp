//============================================================================
// Name        : webclient.cpp
// Author      : Maroš Vasilišin
// Description : HTTP WebClient in C++
//============================================================================

#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <unistd.h>


using namespace std;


// definovane rozne kody pre rozne chyby
#define ERR_PARAM      1
#define ERR_PROTOCOL   2
#define ERR_URL        3
#define ERR_SOCKET     4
#define ERR_HOSTNAME   5
#define ERR_CONNECT    6
#define ERR_REQUEST    7
#define ERR_RECIEVE    8
#define ERR_RECONNECT  9
#define ERR_REDIR     10


// funkcia pre vypis chybovych hlaseni na standarndny chybovy vystup
void print_error(int err_code) {

	switch(err_code) {
		case ERR_PARAM:
			cerr << "Bad arguments. Correct call is: webclient URL\n" << endl;
			break;
		case ERR_PROTOCOL:
			cerr << "Bad protocol. webclient only supports HTTP\n" << endl;
			break;
		case ERR_URL:
			cerr << "Bad URL syntax\n" << endl;
			break;
		case ERR_SOCKET:
			cerr << "Error when creating socket\n" << endl;
			break;
		case ERR_HOSTNAME:
			cerr << "Nonexistent host.\n" << endl;
			break;
		case ERR_CONNECT:
			cerr << "Error when trying to connect to host\n" << endl;
			break;
		case ERR_REQUEST:
			cerr << "Error when sending request\n" << endl;
			break;
		case ERR_RECIEVE:
			cerr << "Error receiving server reply\n" << endl;
			break;
		case ERR_RECONNECT:
			cerr << "Error when reconnecting\n" << endl;
			break;
		case ERR_REDIR:
			cerr << "Maximum allowed redirects reached\n" << endl;
			break;
	}
}

int main(int argc, char* argv[]) {

	int code = 0; // navratovy kod zo serveru

	// kontrola poctu argumentov na 2 - nazov programu a URL z ktorej sa bude stahovat
	if (argc != 2) {
		print_error(ERR_PARAM);
		return -1;
	}

	// ulozenie druheho argumentu skriptu, kde je url do premennej url
	string url = argv[1];

	string reply; // premenna kde sa uklada obsah co sa vrati zo servera
	string file; // ulozeny nazov vystupneho suboru
	string hostname; // ulozeny nazov pre hosta
	int port = 80; // port pre http request, implicitne 80 ak nebol zadany uzivatelom inak
	string path; // cesta k suboru co sa bude stahovat
	int redirects_c = 0; // pocet presmerovani, maximalne 5 zo zadania

	while (code != 200) {

		if (redirects_c > 5) { // ak pocet presmerovani prekroci 5, nastava chyba
			print_error(ERR_REDIR);
			return -1;
		}
	// ak url neobsahuje http:// tak vyhodime chybu
		if (url.compare(0,7, "http://") == 0) {
			url = url.substr(7,url.length());
		}
		else {
			print_error(ERR_PROTOCOL);
			return -1;
		}

		size_t i = url.find(":"); // prehladame url na vyskyt znaku : pre zadanie protokolu
		if (i != string::npos) { // ak naslo dvojbodku
			hostname = url.substr(0,i); // ulozime hosta
			url = url.substr(i,url.length()); // skratime url o hosta
			i = url.find("/"); // hladame lomitko
			if (i != string::npos) { // ak sme nasli lomitko
				port = atoi(url.substr(1,i-1).c_str()); // ulozime si cislo portu
				path = url.substr(i,url.length()); // ulozime si cestu k suboru
			}
			else {
				port = atoi(url.substr(1,url.length()).c_str());
				path = "/";
			}
		}
		else { // ak nenaslo dvojbodku
			i = url.find("/"); // hladame lomitko
			if (i != string::npos) { // ak naslo lomitko
				hostname = url.substr(0,i);
				path = url.substr(i,url.length());
			}
			else {
				hostname = url;
				path = "/";
			}
		}

		if (redirects_c == 0) { // mame ukladat do suboru s nazvom aky bol v requeste, teda neprepisujeme nazov
								// pri dalsich presmerovaniach
			if (path.find_last_of('/') == 0)
				file = "index.html";
			else
				file = path.substr(path.find_last_of('/') + 1);

			if (file.length() == 0) {
				file = "index.html";
			}
		}

		// nahradime vsetky medzery v nazve suboru znakom %20 aby to server rozpoznal
		for (size_t p = path.find(' '); p != string::npos; p = path.find(' ', p)) {
			path.replace(p, 1, "%20");
		}
		// nahradim tildy ascii kodom
		for (size_t p = path.find('~'); p != string::npos; p = path.find('~', p)) {
			path.replace(p, 1, "%7E");
		}

		string head_request = ("HEAD " + path + " HTTP/1.1\r\n"
							 + "Host: " + hostname + "\r\n"
							 + "Connection: close\r\n\r\n");

		int sckt;
		// inicializacia premennych potrebnych pre vytvorenie socketu
		sockaddr_in server_addr;
		server_addr.sin_family = AF_INET;
		server_addr.sin_port = htons(port);

		hostent *server_name;

		sckt = socket(AF_INET,SOCK_STREAM,0); // vytvorenie socketu
		if (sckt < 0) {
			print_error(ERR_SOCKET);
			return -1;
		}

		server_name = gethostbyname(hostname.c_str()); // zistenie nazvu hosta
		if (server_name == NULL) {
			print_error(ERR_HOSTNAME);
			return -1;
		}

		memcpy(&(server_addr.sin_addr), server_name->h_addr, server_name->h_length);

		if (connect(sckt, (sockaddr*) &server_addr, sizeof(server_addr)) == -1) { // pripojenie na server
			print_error(ERR_CONNECT);
			return -1;
		}

		ssize_t bytes_sent; // zaslanie poziadavku na server
		if ((bytes_sent = send(sckt, head_request.c_str(), strlen(head_request.c_str()), 0)) == -1) {
			print_error(ERR_REQUEST);
			return -1;
		}

		char server_reply[1000];
		if (recv(sckt , server_reply , 1000 , 0) < 0) { // prijatie spravy zo serveru
			print_error(ERR_RECIEVE);
			return -1;
		}

		reply = server_reply; // ulozime si prijatu spravu do premennej
		string first_line;
		i = 0;
		while (i < 12) { // vyberieme si navratovy kod z prijatej spravy
			if (i >= 9)
				first_line += reply[i];
			i++;
		}

		code = atoi(first_line.c_str());


		if (code == 200) // ak je kod 200, vsetko je OK
			break;
		else if (code == 302 || code == 301) { // ak je kod 302, nastavime spravne presmerovanie na novu adresu
			i = reply.find("Location:"); // vyhladame v odpovedi novu adresu, priradime do spravnych premennych
			if (i != string::npos) {
				reply = reply.substr(i+10,reply.length());
				url = reply.substr(0,reply.find("\r\n"));
				redirects_c++; // zvysime pocet presmerovani
			}
			else {
				print_error(ERR_RECONNECT);
				return -1;
			}

		}
		else { // ak pride kod 4xx,5xx atd, vyhodime chybu
			cerr << "Error. Server returned " << code << "\n" << endl;
			return -1;
		}
	}

	string first_line;
	int i = 0;
	while (reply[i] != '\r') {
		first_line += reply[i];
		i++;
	}

	string protocol = first_line.substr(0,8); // z prveho riadku odpovede si vyberieme protokol
	string get_request = ("GET " + path + " " + protocol + "\r\n" // vytvorime teda uz GET request podla novych udajov
								 + "Host: " + hostname + "\r\n"
								 + "Connection: close\r\n\r\n");

	sockaddr_in server_addr;
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(port);
	int sckt;

	hostent *server_name;

	sckt = socket(AF_INET,SOCK_STREAM,0);
	if (sckt < 0) {
		print_error(ERR_SOCKET);
		return -1;
	}

	server_name = gethostbyname(hostname.c_str());
	if (server_name == NULL) {
		print_error(ERR_HOSTNAME);
		return -1;
	}

	memcpy(&(server_addr.sin_addr), server_name->h_addr, server_name->h_length);

	if (connect(sckt, (sockaddr*) &server_addr, sizeof(server_addr)) == -1) {
		print_error(ERR_CONNECT);
		return -1;
	}

	ssize_t bytes_sent;
	if ((bytes_sent = send(sckt, get_request.c_str(), strlen(get_request.c_str()), 0)) == -1) {
		print_error(ERR_REQUEST);
		return -1;
	}

	char server_reply[1000];

	ofstream outFile(file.c_str(), ostream::out);

	string head; // premenna pre ulozenie hlavicky
	bool chunked = false; // kontrola ci data boli rozdelene na viacero casti
	string all; // spajanie vsetkych casti do jednej , tu budu ulozene
	string tmp; // docasna premenna pre pracu s odpovedou serveru
	bool found = false;
	int t;

	while ((bytes_sent = recv(sckt, server_reply, 1000, 0)) != 0) { // cyklus pokial sa nenacita vsetko

		tmp = "";
		tmp.append(server_reply,bytes_sent);

		if ((head.length() == 0) || (found == false)) { // ak este nemame hlavicku tak ju musime oddelit od zvysku suboru
			size_t i = tmp.find("\r\n\r\n"); // najdeme symbol pre koniec hlavicky
			if (i != string::npos) {
				found = true;
				t = head.length();
				head = head + tmp.substr(0,i); // priradime hlavicku do premennej
				if (head.find("Transfer-Encoding: chunked") != string::npos)
					chunked = true; // ulozime si do premennej , ak mame viacej casti odpovede
				tmp = tmp.substr(head.length()+4-t,tmp.length()); // zmazeme hlavicku od zvysku tmp

				string first_line;
				i = 0;
				while (i < 12) {
					if (i >= 9)
						first_line += head[i];
					i++;
				}

				code = atoi(first_line.c_str()); // najdeme si kod z hlavicky

				if (code != 200) { // ak kod neni 200 , vyhodime chybu
					cerr << "Error. Server returned " << code << "\n" << endl;
					return -1;
				}

			}
			else {
				head = tmp;
				found = false;
				tmp = "";
			}
		}

		all = all + tmp; // pripojime novu cast odpovede do premennej, ktora si uklada vsetko

	}

	close(sckt);

	if (chunked == false) {
		if (!outFile) { cerr << "Error writing to ..." << file << endl; } else {
		  outFile << all;
		}
	}
	else {

		size_t i = 0;
		size_t divider;
		string hexa;
		size_t length;
		string unchunked;

		while (all.length() > 0) { // pokial sme nepresli vsetko
			divider = all.find("\r\n"); // vyhladame symbol CRLF
			hexa = all.substr(i,divider-i); // vyberieme trojcislie ktore oznacuje dlzku chunku
			length = strtol(hexa.c_str(),NULL,16); // dlzku prevedieme z hexa do integeru
			i += divider + 2; // posunieme index aby sme preskocili dalsi CRLF
			unchunked += all.substr(i,length); // do premennej unchunked ukladame uz nove data
			i += length + 2;
			all = all.substr(i,all.length()); // zmazeme uz vyrieseny chunk z premennej
			i = 0; // vynulujeme poziciu
		}
		if (!outFile) { cerr << "Error writing to ..." << file << endl; } else {
			outFile << unchunked;
		}
	}


	return 0;

}

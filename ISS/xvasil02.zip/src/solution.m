%% 1. Zaostrenie obrazu
iptsetpref('UseIPPL', false);

original = imread('xvasil02.bmp');
vystup = 'step1.bmp';
filter = [-0.5 -0.5 -0.5; -0.5 5.0 -0.5; -0.5 -0.5 -0.5]
zaostreny = imfilter(original,filter);
imwrite(zaostreny,vystup);

%% 2. Preklopenie obrazu
vystup = 'step2.bmp';
preklopeny = fliplr(zaostreny);
imwrite(preklopeny,vystup);

%% 3. Medianovy filter
vystup = 'step3.bmp';
median = medfilt2(preklopeny, [5 5]);
imwrite(median,vystup);

%% 4. Rozmazanie obrazu
vystup = 'step4.bmp';
filter = [1 1 1 1 1; 1 3 3 3 1; 1 3 9 3 1; 1 3 3 3 1; 1 1 1 1 1] / 49;
rozmazany = imfilter(median,filter);
imwrite(rozmazany,vystup);

%% 5. Vypocet chyby v obraze
original = imread('xvasil02.bmp');
novy = fliplr(rozmazany);
novy_double = im2double(novy);
original_double = im2double(original);

chyba = 0;
velkost = size(original);
sirka = min(velkost);
vyska = max(velkost);

for(i=1:sirka)
    for(j=1:vyska)
        chyba = chyba + abs(original_double(i,j) - novy_double(i,j));
    end;
end;

chyba = ((chyba / (sirka * vyska)) * 255);
file = fopen('reseni.txt','w');
fprintf(file, 'chyba=%f\n',chyba);

%% 6. Roztiahnutie histogramu
vystup = 'step5.bmp';
rozmazany_double = im2double(rozmazany);

x = min(rozmazany_double);
y = max(rozmazany_double);
os_x = min(x);
os_y = max(y);
os_x_roztiahnuta = 0.0;
os_y_roztiahnuta = 1.0;
roztiahnuty = imadjust(rozmazany, [os_x os_y],[os_x_roztiahnuta os_y_roztiahnuta]);
roztiahnuty = uint8(roztiahnuty);
imwrite(roztiahnuty,vystup);

%% 7. Stredna hodnota a smerodatna odchylka
rozmazany_double = im2double(rozmazany);
stredna_pred = mean2(rozmazany_double)*255;
odchylka_pred = std2(rozmazany_double)*255;
roztiahnuty_double = im2double(roztiahnuty);
stredna_po = mean2(roztiahnuty_double)*255;
odchylka_po = std2(roztiahnuty_double)*255;
fprintf(file, 'mean_no_hist=%f\nstd_no_hist=%f\nmean_hist=%f\nstd_hist=%f\n',stredna_pred, odchylka_pred, stredna_po, odchylka_po);
fclose(file);
%% 8. Kvantizacia obrazu
vystup = 'step6.bmp';

N = 2;
a = 0;
b = 255;

velkost = size(roztiahnuty);
sirka = min(velkost);
vyska = max(velkost);
kvantovany = zeros(sirka,vyska);

kvantovany_double = double(roztiahnuty);
for(i=1:sirka)
	for(j=1:vyska)
		kvantovany(i,j) = round(((2^N)-1)*(kvantovany_double(i, j)-a)/(b-a))*(b-a)/((2^N)-1) + a;
	end;
end;

kvantovany_int = uint8(kvantovany);
imwrite(kvantovany_int,vystup);

%%
Ix = imread('step1.bmp');
Ixt = imread('xlogin00/step1.bmp');
subplot(121); imshow(Ix); subplot(122); imshow(Ixt);
sum(sum(abs(double(Ix) - double(Ixt))))
A. POPIS PROGRAMU:

	Aplikácia Reversi reprezentuje našu implementáciu rovnomernej hry, ktorej pravidlá sú na: 
		https://cs.wikipedia.org/wiki/Othello_%28deskov%C3%A1_hra%29#Pravidla_hry
	
	Naša aplikácia implementuje základné pravidlá hry, a navyše obsahuje možnosti:
		
		- zvoliť veľkosť hracej plochy
		- zvoliť si za súpera počítač alebo hra 1vs1
		- zvoliť možnosť tzv. zamrzania kameňov

	Aplikácia umožňuje hrať viacero hier súčasne a takisto ukladať si rozohranú hru a načítať uloženú hru.

	Aplikácia obsahuje grafické užívateľské rozhranie.

	Hra je implementovaná pomocou prostredia Eclipse na systéme Unix.

B. AUTORI
	Maroš Vasilišin
		xvasil02
	Martin Urbanczyk
		xurban61
	07.05.2016

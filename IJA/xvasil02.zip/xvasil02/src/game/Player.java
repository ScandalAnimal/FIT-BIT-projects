/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Reprezentuje hrace
 */
package game;

import java.io.Serializable;

import board.Board;
import board.BoardField;
import board.Disk;
import board.Field;

/**
 * Reprezentuje hrace hry. Hrac má bilou nebo cernou barvu.
 * Po vytvoreni reprezentuje volneho hrace.
 * Soucast hrace je sada kamenu, ktere ma k dispozici pro vkladani na desku.
 */

public class Player extends java.lang.Object implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3388125471383499438L;
	private boolean color;
	public int disk_cnt;
	private Disk white1;
	private Disk black1;
	private Disk white2;
	private Disk black2;
	private Field.Direction[] dirs = new Field.Direction[8];
	private int[] turned = new int[40];
	private int index = 0;
	private int size = 0;

	/**
	 * Inicializace hrace
	 * @param isWhite info o barve
	 * @param size info o velikosti
     */
	public Player(boolean isWhite, int size) {
		this.size = size;
		color = isWhite;
	}

	/**
	 * Test barvy hrace
	 * @return barva hrace
     */
	public boolean isWhite() {
		return color;
	}

	/**
	 * Otoceni
	 * @return vraci otoceni
     */
	public int[] returnTurned() {
		return turned;
	}

	/**
	 * Vlozi novy kamen na dane pole, pokud to lze.
	 * @param field pole
	 * @return uspesnost vlozeni
     */
	public boolean putDisk(Field field) {
		for (int i = 0; i < 40; i++) {
			turned[i] = 0;
		}
		int x = 0;
		if (canPutDisk(field) == true) {
			Field tmp_field = field;
			Disk disk = new Disk(color);

			tmp_field.putDisk(disk);
			for (int i = 0; i < 8; i++) {
				if (dirs[i] != null) { 
					tmp_field = tmp_field.nextField(dirs[i]);
					while (tmp_field.getDisk().color != color) {
						tmp_field.getDisk().turn();
						turned[x] = (tmp_field.getRow()*size) + tmp_field.getCol();
						x++;
						tmp_field = tmp_field.nextField(dirs[i]);
					}
				}
				tmp_field = field;
			}
			
			disk_cnt -= 1;
			for (int i = 0; i < 8; i++) {
				dirs[i] = null;
			}
			index = 0;
			return true;
		}
		return false;
	}

	/**
	 * Testuje zda jde vlozit kamen
	 * @param field pole
	 * @return vraci info o tom zda jde vlozit kamen
     */
	public boolean canPutDisk(Field field) {
		Field tmp_field = field;

		for (int i = 0; i < 8; i++) {
			dirs[i] = null;
		}
		index = 0;
		if (field.isEmpty() == true){

			if (disk_cnt <= 0) return false;
			
			for (Field.Direction dir : Field.Direction.values()) {
				tmp_field = tmp_field.nextField(dir);
				
				if ((tmp_field.isEmpty() == false) && (tmp_field.getClass() == BoardField.class) && (!tmp_field.isFrozen())) {
					
					if (tmp_field.getDisk().color == !color) {
						
						while ((tmp_field.isEmpty() == false) && (tmp_field.getClass() == BoardField.class)&& (!tmp_field.isFrozen())) {
							
							tmp_field = tmp_field.nextField(dir);
							if ((tmp_field.isEmpty() == false) && (tmp_field.getClass() == BoardField.class) && (!tmp_field.isFrozen())) {
								
								if (tmp_field.getDisk().color == color) {
									
									dirs[index] = dir;
									index++;

									break;
								}
							}
						}
					}
				}
				

				tmp_field = field;
			}
			for (int i = 0; i < 8; i++) {
				if (dirs[i] != null) return true;
			}
		}

		return false;
	
	}

	/**
	 * Test prazdnosti sady kamenu.
	 * @return Zda je sada prazdna.
     */
	public boolean emptyPool() {
		if (disk_cnt <= 0) return true;
		else return false;
	}

	/**
	 * Inicializace hrace v ramci hraci desky
	 * @param board deska
     */
	public void init(Board board) {
		int x = board.getSize();
		disk_cnt = x*x/2;
		if (this.color == true) {
			white1 = new Disk(true);
			white2 = new Disk(true);
			board.getField(x/2, x/2).putDisk(white1);
			board.getField(x/2+1, x/2+1).putDisk(white2);
		}
		else {
			black1 = new Disk(false);
			black2 = new Disk(false);
			board.getField(x/2, x/2+1).putDisk(black1);
			board.getField(x/2+1, x/2).putDisk(black2);
		}
	}

	@Override
	public String toString() {
		if (color == true) return "white";
		else return "black";
	}
	
	public void changeColor() {
		if (color) color = false;
		else color = true;
	}

}
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Reprezentuje hru.
 */
package game;

import java.io.Serializable;

import board.Board;


/**
 * Reprezentuje hru. Pri zacatku se vzdy inicializuje a nastavi desku.
 */
public class Game extends java.lang.Object implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 108291660739496005L;
	private Board board;
	private Player white_player;
	private boolean isw = false;
	private boolean isb = false;
	private Player black_player;
	private boolean current;

	/**
	 * Nastavi desku a aktualni
	 * @param board Vraci desku
     */
	public Game(Board board) {
		this.board = board;
		current = false;
	}

	/**
	 * Prida a inicializuje hrace
	 * @param player Hrac
	 * @return vraci hrace
     */
	public boolean addPlayer(Player player) {
		
		if (player.isWhite() == true) {
			if (isw == false) {
				white_player = player;
				white_player.init(board);
				isw = true;
				return true;
			}
			else return false;
		}
		else if (player.isWhite() == false) {
			if (isb == false) {
				black_player = player;
				black_player.init(board);
				isb = true;
				return true;
			}
			else return false;
		}
		return false; 
	}

	/**
	 * Vraci hrace, ktery je na tahu.
	 * @return vraci hrace
     */
	public Player currentPlayer() {
		if (current == true) return white_player;
		else return black_player;
	}
	
	/**
	 *  nastavi aktualneho hraca
	 *  @param param aktualny hrac
	 */
	
	public void setPlayer(boolean param) {
		current = param;
	}

	/**
	 * Zmeni aktualniho hrace
	 * @return vraci noveho hrace
     */
	public Player nextPlayer() {
		if (current == true) {
			current = false;
			return black_player;
		}
		else if (current == false) {
			current = true;
			return white_player;
		}
		return null;
	}

	/**
	 * Vraci hraci desku
	 * @return hraci deska
     */
	public Board getBoard() {
		return board;
	}
	public void setBoard(Board board) {
		this.board = board;
	}

}
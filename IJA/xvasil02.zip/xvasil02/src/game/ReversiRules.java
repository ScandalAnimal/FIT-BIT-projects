/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Implementuje rozhrani Rules.
 */
package game;

import java.io.Serializable;

import board.BoardField;
import board.BorderField;
import board.Field;
import board.Rules;

/**
 * Implementuje rozhrani Rules. Reprezentuje pravidla inicializace hry Reversi.
 */

public class ReversiRules extends java.lang.Object implements Rules, Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2596104782114672330L;
	private int boardsize;
	private int value;

	/**
	 * Nastavi velikost desky
	 * @param size velikost desky
     */
	public ReversiRules(int size) {
		boardsize = size;
	}

	/**
	 * Vraci velikost desky
	 * @return velikost desky
     */
	@Override
	public int getSize() {
		return boardsize;
	}

	/**
	 * Vraci pocet disku
	 * @return pocet disku
     */
	@Override
	public int numberDisks() {
		return (this.boardsize*this.boardsize)/2;
	}

	/**
	 * Vytvori pole na zadanych souradnicich.
	 * @param row radek
	 * @param col sloupec
     * @return pole
     */
	@Override
	public Field createField(int row,int col) {
		Field field;
		if ((row == boardsize+1) || (row == 0) || (col == 0) || (col == boardsize+1))
			field = new BorderField();
		else {
			if ((row == 1 && col == 1) || (row == 1 && col == boardsize) || (row == boardsize && col == 1) || (row == boardsize && col == boardsize)){
				value = 30;
			}
			else if ((row == 1 && col == 3) || (row == 1 && col == boardsize-2) || (row == boardsize && col == 3) || (row == boardsize && col == boardsize-2) ||
					(row == 3 && col == 1) || (row == boardsize-2 && col == 1) || (row == 3 && col == boardsize) || (row == boardsize-2 && col == boardsize)){
				value = 10;
			}
			else if ((row == 1 && col == 2) || (row == 1 && col == boardsize-1) || (row == boardsize && col == 2) || (row == boardsize && col == boardsize-1) ||
					(row == 2 && col == 1) || (row == boardsize-1 && col == 1) || (row == 2 && col == boardsize) || (row == boardsize-1 && col == boardsize) ||
					(row == 2 && col == 2) || (row == 2 && col == boardsize-1) || (row == boardsize-1 && col == 2) || (row == boardsize-1 && col == boardsize-1)) {
				value = -25;
			}
			else if ((row == 1) || (col == 1) || (row == boardsize) || (col == boardsize)) {
				value = 7;
			}
			else if ((row == 2) || (col == 2) || (row == boardsize-1) || (col == boardsize-1) ||
					(row == boardsize/2 && col == boardsize/2) || (row == boardsize/2 && col == boardsize/2+1) || (row == boardsize/2+1 && col == boardsize/2) || (row == boardsize/2+1 && col == boardsize/2+1)) {
				value = 1;
			}
			else if ((row == 3 && col == 3)|| (row == 3 && col == boardsize-2) || (row == boardsize-2 && col == 3) || (row == boardsize-2 && col == boardsize-2)) {
				value = 5;
			}
			else if ((row == boardsize/2-1 && col >= boardsize/2-1 && col <= boardsize/2+2) || (row == boardsize/2+2 && col >= boardsize/2-1 && col <= boardsize/2+2) ||
					(col == boardsize/2-1 && row >= boardsize/2-1 && row <= boardsize/2+2) || (col == boardsize/2+2 && row >= boardsize/2-1 && row <= boardsize/2+2)) {
				value = 3;
			}
			else value = 4;
			field = new BoardField(row,col,boardsize,value);
		}
		
		return field;
	}
}
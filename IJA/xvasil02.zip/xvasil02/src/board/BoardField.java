/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Trida, ktera reprezentuje aktivni pole.
 */
package board;

import java.io.Serializable;

/**
 * Trida, ktera reprezentuje aktivni pole tzn. pole, na ktera je mozne vlozit kamen.
 */

public class BoardField extends java.lang.Object implements Field,Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 3189912150294371023L;
	public int r, c, s;
	public int empty = 0;
	private int value;
	private boolean frozen = false;;
	
	Disk mydisk = new Disk();

	private Field[] neighbors = new Field[8]; // v poradi D,L,LD,LU,R,RD,RU,U

	/**
	 * Informace o radcich, sloupcich, velikosti dseky.
	 * @param row radek
	 * @param col sloupec
	 * @param boardsize velikost desky
     * @param value hodnota
     */
	public BoardField(int row, int col, int boardsize, int value) {
		r = row;
		c = col;
		s= boardsize;
		this.value = value;
	}

	/**
	 * Vraci hodnotu
	 * @return hodnota
     */
	@Override
	public int ret_value() {
		return value;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + c;
		result = prime * result + empty;
		result = prime * result + ((mydisk == null) ? 0 : mydisk.hashCode());
		result = prime * result + r;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BoardField other = (BoardField) obj;
		if (c != other.c)
			return false;
		if (empty != other.empty)
			return false;
		if (mydisk == null) {
			if (other.mydisk != null)
				return false;
		} else if (!mydisk.equals(other.mydisk))
			return false;
		if (r != other.r)
			return false;
		return true;
	}


	/**
	 * Prida dalsi pole v danem smeru
	 * @param dirs smer
	 * @param field pole
     */
	@Override
	public void addNextField(Field.Direction dirs, Field field) {
		
		switch (dirs) {
			case D:
				neighbors[0] = field;
				break;
			case L:
				neighbors[1] = field;
				break;
			case LD:
				neighbors[2] = field;
				break;
			case LU:
				neighbors[3] = field;
				break;
			case R:
				neighbors[4] = field;
				break;
			case RD:
				neighbors[5] = field;
				break;
			case RU:
				neighbors[6] = field;
				break;
			case U:
				neighbors[7] = field;
				break;
		}
	}

	/**
	 * Vraci okolni pole
	 * @param field pole
	 * @return Pole sousedu
     */
	@Override
	public Field nextField(Field.Direction field) {
		Field result;
		switch (field) {
			case D:
				if (r == s+1) result = null;
				else {
					result = neighbors[0];
				}
				break;
			case L:
				if (c == 0) result = null;
				else {
					result = neighbors[1];
				}
				break;
			case LD:
				if ((r == s+1) || (c == 0)) result = null;
				else {
					result = neighbors[2];
				}
				break;
			case LU:
				if ((r == 0) || (c == 0)) result = null;
				else {
					result = neighbors[3];
				}
				break;
			case R:
				if (c == s+1) result = null;
				else {
					result = neighbors[4];
				}
				break;
			case RD:
				if ((r == s+1) || (c == s+1)) result = null;
				else {
					result = neighbors[5];
				}
				break;
			case RU:
				if ((r == 0) || (c == s+1)) result = null;
				else {
					result = neighbors[6];
				}
				break;
			case U:
				if (r == 0) result = null;
				else {
					result = neighbors[7];
				}
				break;
			default:
				result = null;
		}
		return result;
	}

	/**
	 * Vraci informaci, zdali je mozne vlozit kamen
	 * @param disk kamen
	 * @return Hodnota, zdali je mozne vlozit kamen.
     */
	@Override
	public boolean canPutDisk(Disk disk) {
		if (empty == 0) return true;
		else return false;
	}

	/**
	 * Vlozeni kamene
	 * @param disk kamen
	 * @return Hodnota, zdali se provedlo vlozeni kamene
     */
	@Override
	public boolean putDisk(Disk disk) {
		if (canPutDisk(disk) == true) {
			if (disk.color == true) mydisk = disk;
			else if (disk.color == false) mydisk = disk;
			empty = 1;
			return true;
		}
		else {
			//empty = 1;
			return false;
		}
	}

	/**
	 * Ziskani kamene
	 * @return kamen
     */
	@Override
	public Disk getDisk() {
		return mydisk;
	}

	/**
	 * Informace zdali je policko prazdne
	 * @return Hodnota, ktera urcuje jestli jde nebo nejde vlozit kamen
     */
	@Override
	public boolean isEmpty() {
		if (empty == 0) return true;
		else return false;
	}

	/**
	 * Nastavi na prazdne
	 * @param i Cislo pole
     */
	@Override
	public void setEmpty(int i) {
		empty = 0;
	}

	/**
	 * Ziska radek
	 * @return radek
     */
	@Override
	public int getRow() {
		return r;
	}

	/**
	 * Ziska sloupec
	 * @return sloupec
     */
	@Override
	public int getCol() {
		return c;
	}

	/**
	 * Zjisti zdali je zmrazeno
	 * @return Informace, jestli je zmrazeno.
     */
	@Override
	public boolean isFrozen() {
		return frozen;
	}

	/**
	 * Nastavi na zmrazeno
	 */
	@Override
	public void triggerFrozen() {
		if (frozen) frozen = false;
		else frozen = true;
	}

}
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Rozhrani k polim, ktere lze vlozit na hraci desku.
 */
package board;


/**
 * Rozhrani k polim, ktere lze vlozit na hraci desku. Samotne pole jeste ma informaci o polich, ktere ho obklopuji ve vsech
 * smerech.
 */
public interface Field {

	/**
	 * Vycet vsech smeru.
	 */
	public static enum Direction {
		/**
		 * Dolu od pole
		 */
		D,

		/**
		 * Vlevo od pole
		 */
		L,

		/**
		 * Vlevo-dolu od pole
		 */
		LD,

		/**
		 * Vlevo-nahoru od pole
		 */
		LU,

		/**
		 * Vpravo od pole
		 */
		R,

		/**
		 * Vpravo-dolu od pole
		 */
		RD,

		/**
		 * Vpravo-nahoru od pole
		 */
		RU,

		/**
		 * Nahoru od pole
		 */
		U
	}

	/**
	 * Zjistuje zda je prazdny.
	 * @return vraci hodnotu zda je prazdny
     */
	boolean isEmpty();
	/**
	 * Prida dalsi pole v danem smeru
	 * @param dirs smer
	 * @param field pole
	 */
	void addNextField(Field.Direction dirs, Field field);

	/**
	 * Vraci okolni pole
	 * @param dirs Smery
	 * @return pole sousedu
     */
	Field nextField(Field.Direction dirs);

	/**
	 * Informace o tom, zda lze vlozit kamen.
	 * @param disk kamen
	 * @return hodnota, zda lze vlozit kamen
     */
	boolean canPutDisk(board.Disk disk);

	/**
	 * Vlozeni kamene
	 * @param disk kamen
	 * @return vraci vlozeni kamene
     */
	boolean putDisk(board.Disk disk);

	/**
	 * Ziska disk.
	 * @return vraci disk
     */
	board.Disk getDisk();

	/**
	 * Ziska radek
	 * @return vraci radek
     */
	int getRow();

	/**
	 * Ziska sloupec
	 * @return vraci sloupec
     */
	int getCol();

	/**
	 * Nastavi pole na prazdne.
	 * @param i cislo pole
     */
	void setEmpty(int i);

	/**
	 * Vraci hodnotu
	 * @return hodnota
     */
	int ret_value();

	/**
	 * Vraci info o tom, zda je zmrazeno
	 * @return vraci zda je zmrazeno
     */
	boolean isFrozen();

	/**
	 * Nastavi stav na zmrazeno.
	 */
	void triggerFrozen();
		
	
}

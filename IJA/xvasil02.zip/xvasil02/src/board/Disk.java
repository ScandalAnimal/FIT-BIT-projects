/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Trida, reprezentujici jeden kamen.
 */
package board;
import java.io.Serializable;

/**
 * Trida, ktera reprezentuje jeden kamen, ten muze nabyvat bud cerne nebo bile barvy.
 */
public class Disk extends java.lang.Object implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -2570742704518379105L;
	public boolean color;

	/**
	 * Nastavi barvu kamene
	 * @param isWhite priznak, zdali je kamen bily
     */
	public Disk(boolean isWhite) {
		if (isWhite) color = true;
		else color = false;
	}

	/**
	 * Nedela nic
	 */
	public Disk() {
		
	}

	/**
	 * Zjistuje zda je kamen bily
	 * @return Vraci info o barve kamene
     */
	public boolean isWhite() {
		if (color == true) return true;
		else return false;
	}

	/**
	 * Otoceni kamene.
	 */
	public void turn() {
		if (color == true) color = false;
		else if (color == false) color = true;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (color ? 1231 : 1237);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Disk other = (Disk) obj;
		if (color != other.color)
			return false;
		return true;
	}

}
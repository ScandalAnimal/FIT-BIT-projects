/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Trida, ktera reprezentuje hraci desku
 */

package board;

import javax.swing.*;
import java.io.Serializable;

/**
 * Trida, ktera reprezentuje hraci desku. Deska jako takova ma aktivni a neaktivni pole, take
 * je treba nastavovat okoli kazdeho policka. Dale se tato trida pouziva pro nacitani a ukladani stavu hry.
 */

public class Board extends java.lang.Object implements Serializable{

	private static final long serialVersionUID = -3157498149825303322L;

	private int boardsize;
	
	private int serial_white_points;
	private int serial_black_points;
	private boolean serial_current_player;
	private boolean serial_hints;
	private boolean serial_pc;
	private boolean serial_hard;
	public JButton[][] serial_squares;
	
	private Field[][] field;
	private Rules rules;

	/**
	 * Probiha nastaveni policek a okolnich poli.
	 * @param rules  Pravidla
     */
	public Board(Rules rules) {
		
		boardsize = rules.getSize();
		this.rules = rules;

		field = new Field[boardsize+2][boardsize+2];
		
		for (int i = 0; i <= boardsize+1; i++) {
			for (int j = 0; j <= boardsize+1; j++) {
				field[i][j] = rules.createField(i,j);			
			}
		}
		for (int i = 1; i <= boardsize; i++) {
			for (int j = 1; j <= boardsize; j++) {
				field[i][j].addNextField(Field.Direction.D,field[i+1][j]);
				field[i][j].addNextField(Field.Direction.L,field[i][j-1]);
				field[i][j].addNextField(Field.Direction.LD,field[i+1][j-1]);
				field[i][j].addNextField(Field.Direction.LU,field[i-1][j-1]);
				field[i][j].addNextField(Field.Direction.R,field[i][j+1]);
				field[i][j].addNextField(Field.Direction.RD,field[i+1][j+1]);
				field[i][j].addNextField(Field.Direction.RU,field[i-1][j+1]);
				field[i][j].addNextField(Field.Direction.U,field[i-1][j]);
			}
		}
	}

	/**
	 * Vraci pole na zadanych indexech
	 * @param row radek
	 * @param col sloupec
	 * @return vraci hodnotu na danych indexech
	 */
	public Field getField(int row, int col) {
		return field[row][col];
	}

	/**
	 * Vraci velikost desky
	 * @return  Velikost desky
     */
	public int getSize() {
		return boardsize;
	}

	/**
	 * Vraci pravidla
	 * @return  Pravidla
     */
	public Rules getRules() {
		return rules;
	}
	public void print() {
		for (int i = 1; i <= boardsize; i++) {
			System.out.println("******************************************************************");
			for (int j = 1; j <= boardsize; j++) {
				//System.out.print(" * " + i + "/" + j);
				
				if (field[i][j].isEmpty() == true)
					System.out.print(" * -----");
				else if (field[i][j].isFrozen() == true)
					System.out.print(" * -ice-");
				else if (field[i][j].getDisk().color == true)
					System.out.print(" * white");
				else if (field[i][j].getDisk().color == false)
					System.out.print(" * black");
			}
			System.out.println(" *");
		}
		System.out.println("******************************************************************");
	}

	/**
	 * Nastavi potrebna data
	 * @param white_points   body bileho
	 * @param black_points  body cerneho
	 * @param current_player soucasny hrac
	 * @param hints Napoveda pri dalsim tahu
	 * @param pc Umela inteligence
     * @param hard Tezky mod
     * @param squares tlacitka na doske
     */
	public void set_serial_data(int white_points, int black_points, boolean current_player, boolean hints, boolean pc, boolean hard, JButton[][] squares) {
		this.serial_white_points = white_points;
		this.serial_black_points = black_points;
		this.serial_current_player = current_player;
		this.serial_hints = hints;
		this.serial_pc = pc;
		this.serial_hard = hard;
		this.serial_squares = squares;
	}

	/**
	 * Vraci bile body pri save
	 * @return bile body
     */
	public  int ret_serial_white_points (){
		return serial_white_points;
	}

	/**
	 * Vraci cerne body pri save
	 * @return cerne body
     */
	public int ret_serial_black_points() {
		return serial_black_points;
	}

	/**
	 * Vraci aktualniho hrace na tahu
	 * @return Aktualni hrac
     */
	public boolean ret_serial_current_player(){
		return serial_current_player;
	}

	/**
	 * Vraci aktualni napovedy na dalsi mozny tah
	 * @return napovedy
     */
	public boolean ret_serial_hints(){
		return serial_hints;
	}

	/**
	 * Vraci stav umele inteligence
	 * @return umela inteligence
     */
	public boolean ret_serial_pc(){
		return serial_pc;
	}

	/**
	 * Tezky mod
	 * @return tezky mod
     */
	public boolean ret_serial_hard() {
		return serial_hard;
	}
	

}
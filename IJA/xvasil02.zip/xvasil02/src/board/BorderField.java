/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Trida, ktera reprezentuje neaktivni pole
 */
package board;

import java.io.Serializable;

/**
 * Trida, ktera reprezentuje neaktivni pole tzn. okrajova policka, na ktere nelze v zadnem pripade vlozit kameny.
 */
public class BorderField extends java.lang.Object implements Field,Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7399460665502968405L;

	/**
	 * Nedela nic
	 * @param dirs Smer, ve kterem se pridava pole
	 * @param field dane pole
     */
	@Override
	public void addNextField(Field.Direction dirs, Field field) {
		
	}

	/**
	 * Nedela nic
	 * @param i cislo pole
     */
	@Override
	public void setEmpty(int i) {
		
	}

	/**
	 * Vraci pokazde 0
	 * @return vraci 0
     */
	@Override
	public int ret_value(){
		return 0;
	}

	/**
	 * Vraci vzdy null
	 * @param dirs smer ve kterem se pridava
	 * @return vraci null
     */
	@Override
	public Field nextField(Field.Direction dirs) {
		return null;
	}

	/**
	 * Pouze vraci false
	 * @param disk kamen
	 * @return vraci false
     */
	@Override
	public boolean putDisk(Disk disk) {
		return false;
	}

	/**
	 * Pouze vraci null
	 * @return vraci null
     */
	@Override
	public Disk getDisk() {
		return null;
	}

	/**
	 * Zjistuje zda je prazdne pole, vraci vzdy false
	 * @return vraci false
     */
	@Override
	public boolean isEmpty() {
		return false;
	}

	/**
	 * Vzdy jen vraci false
	 * @param disk kamen
	 * @return vraci false
     */
	@Override
	public boolean canPutDisk(board.Disk disk) {
		return false;
	}

	/**
	 * Vzdy jen vraci nulu
	 * @return vraci nulu
     */
	@Override
	public int getRow() {
		return 0;
	}

	/**
	 * Vzdy jen vraci nulu
	 * @return vraci nulu
	 */
	@Override
	public int getCol() {
		return 0;
	}

	/**
	 * Zjistuje zda je zmrazeno
	 * @return Vraci false
     */
	@Override
	public boolean isFrozen() {
		return false;
	}

	/**
	 * Nedela nic
	 */
	@Override
	public void triggerFrozen() {
	}
		


}
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Rozhrani k pravidlum
 */
package board;


/**
 * Rozhrani k pravidlum
 */

public interface Rules {

	/**
	 * Informace o velikosti desky
	 * @return velikost desky
     */
	int getSize();

	/**
	 * Informace o poctu disku
	 * @return pocet disku
     */
	int numberDisks();

	/**
	 * Vytvori pole na danych souradnicich.
	 * @param row radek
	 * @param col sloupec
     * @return pole
     */
	Field createField(int row,int col);

}

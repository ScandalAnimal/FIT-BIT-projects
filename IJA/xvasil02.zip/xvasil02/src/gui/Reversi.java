package gui;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Hlavni trida.
 */
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import board.Board;
/**
 * Hlavni trida, probiha zde napriklad inicilizace menu, nacteni hry, vytvoreni hry, samotne plneni ikon, labelu,
 * uvodni obrazovky etc..
 */
public class Reversi implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -9103157031557410083L;
	JFrame frame = new JFrame("Reversi © Maroš Vasilišin, Martin Urbanczyk");
	JTabbedPane tabbedPane = new JTabbedPane();
	
	private int boardsize = 8;
	
	boolean hints = true;
	boolean pc = false;
	boolean hard = false;
	boolean end = false;
	boolean freezing = false;
	int a = 0;
	int b = 0;
	int c = 0;
	private int game_no = 1;
	int bound = 100;
	
	
	Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
	double width = screenSize.getWidth();
	double height = screenSize.getHeight();
	
	ImageIcon icons[];

	/**
	 * Nastavuje se zde layout, velikost okna
	 */
	public Reversi() {
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        frame.setVisible(true);
		frame.setLayout(new BorderLayout());
        
        
        if (width > height) {
    		//frame.setBounds(20, 20, (int)height-bound, (int)height-bound);
			frame.setMaximumSize(new Dimension((int)height-bound,(int)height-bound));
			frame.setMinimumSize(new Dimension((int)height-bound,(int)height-bound));
			frame.setSize(new Dimension((int) height-bound, (int) height-bound));
    	}
    	else {
    		//frame.setBounds(20, 20, (int)width-bound, (int)width-bound);
			frame.setMaximumSize(new Dimension((int)height-bound,(int)height-bound));
			frame.setMinimumSize(new Dimension((int)height-bound,(int)height-bound));
			frame.setSize(new Dimension((int) width-bound, (int) width-bound));
    	}
        icons = createIcons();
	}

	/**
	 * Vytvori ikony
	 * @return ikony
     */
	private ImageIcon[] createIcons() {
		icons = new ImageIcon[5];
    	
    	icons[0] = new ImageIcon("src/img/white.png");
    	icons[1] = new ImageIcon("src/img/black.png");
    	icons[2] = new ImageIcon("src/img/trans.png");
    	icons[3] = new ImageIcon("src/img/small.png");
    	icons[4] = new ImageIcon("src/img/frozen.png");
    	
    	return icons;
	}

	/**
	 * Vytvori hru a nastavi vse potrebne.
	 */
	private void createGame() {
		if (freezing) {
			if ((a == 0 ) || (b == 0) || (c == 0)) { 
				System.err.println("Not all values for freezing were set.");
				return;
			}
		}
		
		
		GameTab gameTab = new GameTab(boardsize,icons,hints,pc,hard,end,freezing,tabbedPane,a,b,c);
		gameTab.ret_gameboard().ret_gameplay().set_end(false);
        gameTab.ret_gameinfo().ret_lb_message().setText("Na tahu je : ");
        gameTab.ret_gameinfo().ret_lb_player().setText("" + gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer() + "");
        gameTab.ret_gameinfo().ret_lb_player().setOpaque(true);
        
        gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
        
        gameTab.ret_gameinfo().ret_lb_cnt_w().setText("WHITE: " + 2);
    	gameTab.ret_gameinfo().ret_lb_cnt_b().setText(2 + " :BLACK");
    	
    	if (gameTab.ret_gameboard().ret_gameplay().ret_pc()) {
    		gameTab.ret_gameinfo().ret_lb_cnt_w().setText("(PC) WHITE: " + 2);
        	gameTab.ret_gameinfo().ret_lb_cnt_b().setText(2 + " :BLACK (YOU)");
    	}
    	
    	gameTab.ret_game_panel().add(gameTab.ret_gameboard().ret_board_panel());
        
        GridBagConstraints gbc = new GridBagConstraints();

        int s = (int)(height/(gameTab.ret_gameboard().ret_size()*5));
        
        for (int ii = 0; ii < gameTab.ret_gameboard().ret_boardsquares().length; ii++) {
        	gbc.fill = GridBagConstraints.BOTH;
            for (int jj = 0; jj < gameTab.ret_gameboard().ret_boardsquares().length; jj++) {
            	gbc.gridx = jj;
                gbc.gridy = ii;
                gbc.ipadx = 25;
                gbc.ipady = 25;
                
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setPreferredSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setMinimumSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setMaximumSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_board_panel().add(gameTab.ret_gameboard().ret_boardsquares()[ii][jj],gbc);     
            }
        }
        tabbedPane.addTab("Game " + game_no, gameTab.ret_game_panel());
        game_no++;
        
        gameTab.ret_gameinfo().ret_save_button().addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
            	 
            	gameTab.ret_gameboard().ret_gameplay().ret_board().set_serial_data(
            			gameTab.ret_gameboard().ret_gameplay().ret_whites(),
            			gameTab.ret_gameboard().ret_gameplay().ret_blacks(),
            			gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer().isWhite(),
            			gameTab.ret_gameboard().ret_gameplay().ret_hints(),
            			gameTab.ret_gameboard().ret_gameplay().ret_pc(),
            			gameTab.ret_gameboard().ret_gameplay().ret_hard(),
            			gameTab.ret_gameboard().ret_boardsquares());
            	
            	try {
            		Date date = new Date();
            		
       		        SimpleDateFormat format =
       		        	new SimpleDateFormat("MMddyyyyHHmm");

       		        String game_name = "" + format.format(date);
        			FileOutputStream fout = new FileOutputStream("examples/" + game_name);
        			ObjectOutputStream oos = new ObjectOutputStream(fout);   
        			oos.writeObject(gameTab.ret_gameboard().ret_gameplay().ret_board());
        			oos.close();
        			   
        		 }
            	 catch(Exception ex){
            		 ex.printStackTrace();
        		 }
            }
		});
        
        //frame.pack();
        tabbedPane.setSelectedComponent(gameTab.ret_game_panel());
	}

	/**
	 * Nacte ulozenou hru
	 * @param recovered obnovena data
	 * @param name jmeno
     */
	private void loadGame(Board recovered, String name) {
		GameTab gameTab = new GameTab(recovered.getSize(),
									  icons,
									  recovered.ret_serial_hints(),
									  recovered.ret_serial_pc(),
									  recovered.ret_serial_hard(),
									  end,
									  freezing,
									  tabbedPane,a,b,c);
		
		gameTab.ret_gameboard().ret_gameplay().set_end(false);
        gameTab.ret_gameinfo().ret_lb_message().setText("Na tahu je : ");
        if (recovered.ret_serial_current_player()) {
        	gameTab.ret_gameinfo().ret_lb_player().setText("white");
        }
        else {
        	gameTab.ret_gameinfo().ret_lb_player().setText("black");
        }
        gameTab.ret_gameinfo().ret_lb_player().setOpaque(true);
        
        if (recovered.ret_serial_current_player()) {
        	gameTab.ret_gameinfo().ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.WHITE, 10));
        	gameTab.ret_gameinfo().ret_lb_player().setBackground(Color.WHITE);
        	gameTab.ret_gameinfo().ret_lb_player().setForeground(Color.BLACK);	
        }
        else {
        	gameTab.ret_gameinfo().ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
        	gameTab.ret_gameinfo().ret_lb_player().setBackground(Color.BLACK);
        	gameTab.ret_gameinfo().ret_lb_player().setForeground(Color.WHITE);	
        }
        
        gameTab.ret_gameinfo().ret_lb_cnt_w().setText("WHITE: " + recovered.ret_serial_white_points());
    	gameTab.ret_gameinfo().ret_lb_cnt_b().setText(recovered.ret_serial_black_points() + " :BLACK");
    	
    	if (recovered.ret_serial_pc()) {
    		gameTab.ret_gameinfo().ret_lb_cnt_w().setText("(PC) WHITE: " + recovered.ret_serial_white_points());
        	gameTab.ret_gameinfo().ret_lb_cnt_b().setText(recovered.ret_serial_black_points() + " :BLACK (YOU)");
    	}
    	
    	gameTab.ret_gameboard().ret_gameplay().serial_set_board(recovered);
    	
    	
    	
    	for (int i = 0; i <= gameTab.ret_gameboard().ret_size()-1; i++) {
			for (int j = 0; j <= gameTab.ret_gameboard().ret_size()-1; j++) {
				
				if (gameTab.ret_gameboard().ret_gameplay().ret_board().getField(i+1, j+1).isEmpty() == true)
					gameTab.ret_gameboard().ret_boardsquares()[i+2][j+2].setIcon(icons[2]);
				else if (gameTab.ret_gameboard().ret_gameplay().ret_board().getField(i+1, j+1).getDisk().isWhite() == true)
					gameTab.ret_gameboard().ret_boardsquares()[i+2][j+2].setIcon(icons[0]);
				else if (gameTab.ret_gameboard().ret_gameplay().ret_board().getField(i+1, j+1).getDisk().isWhite() == false)
					gameTab.ret_gameboard().ret_boardsquares()[i+2][j+2].setIcon(icons[1]);
			}
		}
    	int x = 0;
    	x = gameTab.ret_gameboard().ret_gameplay().changeHints(icons, x);
		
    	//for (int a = 0; a < gameTab.ret_gameboard().ret_size(); a++) {
    		//for (int b = 0; b < gameTab.ret_gameboard().ret_size(); b++) {
        		/*if (gameTab.ret_gameboard().ret_gameplay().ret_board().getField(a, b).isEmpty()) {
        			gameTab.ret_gameboard().ret_boardsquares()[a+2][b+2].setIcon(icons[0]);
        		}*/
    			/*if (!gameTab.ret_gameboard().ret_gameplay().ret_board().getField(a, b).isEmpty()){
	    			if (gameTab.ret_gameboard().ret_gameplay().ret_board().getField(a, b).getDisk().isWhite()){
	    				gameTab.ret_gameboard().ret_boardsquares()[a+2][b+2].setIcon(icons[0]);
	    			}
    			}*/
        	//}
    	//}
    	
    	for (int ii = 0; ii < gameTab.ret_gameboard().ret_boardsquares().length; ii++) {
            for (int jj = 0; jj < gameTab.ret_gameboard().ret_boardsquares().length; jj++) {
            	int new_ii = ii;
                int new_jj = jj;
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].addActionListener(new ActionListener() {
                    @Override
					public void actionPerformed(ActionEvent e) {
                    	if (gameTab.ret_gameboard().ret_gameplay().ret_end()) return;
                    	if (gameTab.ret_gameboard().ret_gameplay().ret_ignore() == true) {
                    		return;
                    	}
                    	gameTab.ret_gameboard().ret_gameplay().set_available_moves(0);
                        if (!gameTab.ret_gameboard().ret_gameplay().ret_pc()) {
                        	if (gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj].getIcon().equals(gameTab.ret_gameinfo().ret_icons()[2]) || gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj].getIcon().equals(gameTab.ret_gameinfo().ret_icons()[3])) {
                        		if (!gameTab.ret_gameboard().perform_loaded_move(gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj],new_ii,new_jj,recovered.ret_serial_current_player())) {
                        			return;
                        		};
                        		
                            }
                        	else {
                        		return;
                        	}
                            if (gameTab.ret_gameboard().ret_gameplay().ret_hints()) {
                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

                            	
                            	if (gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) {
	                            	gameTab.ret_gameboard().ret_gameplay().ret_game().nextPlayer();
	                            	gameTab.ret_gameinfo().ret_lb_player().setText("" + gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer() + "");
	                            	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
	                            	
	                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));
	                            	
                                    if ((gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) && (gameTab.ret_gameboard().ret_gameplay().ret_end() == false)){
                                    	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
                                    	gameTab.ret_gameboard().ret_gameplay().changeScoreBoard(gameTab.ret_gameboard().ret_gameplay().ret_pc());
                                    	
                                    	gameTab.ret_gameboard().ret_gameplay().set_end(true);
                                    	String winner = (gameTab.ret_gameboard().ret_gameplay().ret_whites() > gameTab.ret_gameboard().ret_gameplay().ret_blacks()) ? "white" : "black"; 
                                    	gameTab.ret_gameinfo().nullLabels(winner);
                                    	if (gameTab.ret_gameboard().ret_gameplay().ret_whites() == gameTab.ret_gameboard().ret_gameplay().ret_blacks()) {
                                    		gameTab.ret_gameinfo().ret_lb_message().setText("Hra skoncila remizou.");
                                    	}
                                    	   		
                                    }
                                }
	                            /*else {
	                            	gameTab.ret_gameboard().ret_gameplay().ret_game().nextPlayer();
	                            }*/
                            }
                            else {
                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().countMoves(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

	                            
	                            if (gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) {
	                            	gameTab.ret_gameboard().ret_gameplay().ret_game().nextPlayer();
	                            	gameTab.ret_gameinfo().ret_lb_player().setText("" + gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer() + "");
	                            	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
	                            	
	                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

                                    if ((gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) && (gameTab.ret_gameboard().ret_gameplay().ret_end() == false)){
                                    	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
                                    	gameTab.ret_gameboard().ret_gameplay().changeScoreBoard(gameTab.ret_gameboard().ret_gameplay().ret_pc());
                                    	
                                    	gameTab.ret_gameboard().ret_gameplay().set_end(true);
                                    	String winner = (gameTab.ret_gameboard().ret_gameplay().ret_whites() > gameTab.ret_gameboard().ret_gameplay().ret_blacks()) ? "white" : "black"; 
                                    	gameTab.ret_gameinfo().nullLabels(winner);
                                    	if (gameTab.ret_gameboard().ret_gameplay().ret_whites() == gameTab.ret_gameboard().ret_gameplay().ret_blacks()) {
                                    		gameTab.ret_gameinfo().ret_lb_message().setText("Hra skoncila remizou.");
                                    	}
                                    	   		
                                    }
                                }
                            }
                        }
                        else if (gameTab.ret_gameboard().ret_gameplay().ret_pc()) {
                        	if (gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj].getIcon().equals(gameTab.ret_gameinfo().ret_icons()[2]) || gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj].getIcon().equals(gameTab.ret_gameinfo().ret_icons()[3])) {
                        		if (!gameTab.ret_gameboard().perform_move(gameTab.ret_gameboard().ret_boardsquares()[new_ii][new_jj],new_ii,new_jj)) {
                        			return;
                        		};
                            }
                        	else {
                        		return;
                        	}
                            if (gameTab.ret_gameboard().ret_gameplay().ret_hints()) {
                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

	                            
	                            if (gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) {
	                            	gameTab.ret_gameboard().ret_gameplay().ret_game().nextPlayer();
	                            	gameTab.ret_gameinfo().ret_lb_player().setText("" + gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer() + "");
	                            	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
	                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

                                    if ((gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) && (gameTab.ret_gameboard().ret_gameplay().ret_end() == false)){
                                    	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
                                    	gameTab.ret_gameboard().ret_gameplay().changeScoreBoard(gameTab.ret_gameboard().ret_gameplay().ret_pc());
                                    	gameTab.ret_gameboard().ret_gameplay().set_end(true);
                                    	String winner = (gameTab.ret_gameboard().ret_gameplay().ret_whites() > gameTab.ret_gameboard().ret_gameplay().ret_blacks()) ? "white" : "black"; 
                                    	gameTab.ret_gameinfo().nullLabels(winner);
                                    	if (gameTab.ret_gameboard().ret_gameplay().ret_whites() == gameTab.ret_gameboard().ret_gameplay().ret_blacks()) {
                                    		gameTab.ret_gameinfo().ret_lb_message().setText("Hra skoncila remizou.");
                                    	}
                                    	   		
                                    }
                                }
	                            else {
	                            	gameTab.ret_gameboard().ret_gameplay().trigger_ignore();
                            		int moves = gameTab.ret_gameboard().ret_gameplay().ret_available_moves();
	                            	int delay = 2000;
	                            	Timer timer = new Timer();
	                            	timer.schedule(new TimerTask() {
	                            		@Override
										public void run() {
	                                      	gameTab.ret_gameboard().ret_gameplay().pc_action(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_hints(), moves);
	                                      	gameTab.ret_gameboard().ret_gameplay().trigger_ignore();
	                            		}
	                            	}, delay);
	                            	
	                            }
                            }
                            else {
                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().countMoves(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

	                            
	                            if (gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) {
	                            	gameTab.ret_gameboard().ret_gameplay().ret_game().nextPlayer();
	                            	gameTab.ret_gameinfo().ret_lb_player().setText("" + gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer() + "");
	                            	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
	                            	gameTab.ret_gameboard().ret_gameplay().set_available_moves(gameTab.ret_gameboard().ret_gameplay().changeHints(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_available_moves()));

                                    if ((gameTab.ret_gameboard().ret_gameplay().ret_available_moves() == 0) && (gameTab.ret_gameboard().ret_gameplay().ret_end() == false)){
                                    	gameTab.ret_gameboard().ret_gameplay().changeCurrentPlayerLabel();
                                    	gameTab.ret_gameboard().ret_gameplay().changeScoreBoard(gameTab.ret_gameboard().ret_gameplay().ret_pc());
                                    	gameTab.ret_gameboard().ret_gameplay().set_end(true);
                                    	String winner = (gameTab.ret_gameboard().ret_gameplay().ret_whites() > gameTab.ret_gameboard().ret_gameplay().ret_blacks()) ? "white" : "black"; 
                                    	gameTab.ret_gameinfo().nullLabels(winner);
                                    	if (gameTab.ret_gameboard().ret_gameplay().ret_whites() == gameTab.ret_gameboard().ret_gameplay().ret_blacks()) {
                                    		gameTab.ret_gameinfo().ret_lb_message().setText("Hra skoncila remizou.");
                                    	}
                                    	   		
                                    }
                                }
	                            else {
	                            	gameTab.ret_gameboard().ret_gameplay().trigger_ignore();
                            		int moves = gameTab.ret_gameboard().ret_gameplay().ret_available_moves();
	                            	int delay = 2000;
	                            	Timer timer = new Timer();
	                            	timer.schedule(new TimerTask() {
	                            		@Override
										public void run() {
	                                      	gameTab.ret_gameboard().ret_gameplay().pc_action(gameTab.ret_gameinfo().ret_icons(), gameTab.ret_gameboard().ret_gameplay().ret_hints(), moves);
	                                      	gameTab.ret_gameboard().ret_gameplay().trigger_ignore();
	                            		}
	                            	}, delay);
	                            	
	                            }
                            }

                        }
                        
                        gameTab.ret_gameinfo().ret_undo_button().setEnabled(true);
                    }
                });

            }
    	}
        
            	
    	
    	
    	gameTab.ret_game_panel().add(gameTab.ret_gameboard().ret_board_panel());
        
        GridBagConstraints gbc = new GridBagConstraints();

        int s = (int)(height/(gameTab.ret_gameboard().ret_size()*5));
        
        for (int ii = 0; ii < gameTab.ret_gameboard().ret_boardsquares().length; ii++) {
        	gbc.fill = GridBagConstraints.BOTH;
            for (int jj = 0; jj < gameTab.ret_gameboard().ret_boardsquares().length; jj++) {
            	gbc.gridx = jj;
                gbc.gridy = ii;
                gbc.ipadx = 25;
                gbc.ipady = 25;
                
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setPreferredSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setMinimumSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_boardsquares()[ii][jj].setMaximumSize(new Dimension(s,s));
                gameTab.ret_gameboard().ret_board_panel().add(gameTab.ret_gameboard().ret_boardsquares()[ii][jj],gbc);     
            }
        }
        tabbedPane.addTab(name , gameTab.ret_game_panel());
        //game_no++;
        
        gameTab.ret_gameinfo().ret_save_button().addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
            	 
            	gameTab.ret_gameboard().ret_gameplay().ret_board().set_serial_data(
            			gameTab.ret_gameboard().ret_gameplay().ret_whites(),
            			gameTab.ret_gameboard().ret_gameplay().ret_blacks(),
            			gameTab.ret_gameboard().ret_gameplay().ret_game().currentPlayer().isWhite(),
            			gameTab.ret_gameboard().ret_gameplay().ret_hints(),
            			gameTab.ret_gameboard().ret_gameplay().ret_pc(),
            			gameTab.ret_gameboard().ret_gameplay().ret_hard(),
            			gameTab.ret_gameboard().ret_boardsquares());
            	try {
            		Date date = new Date();
            		
       		        SimpleDateFormat format =
       		        	new SimpleDateFormat("MMddyyyyHHmm");

       		        String game_name = "" + format.format(date);
        			FileOutputStream fout = new FileOutputStream("examples/" + game_name);
        			ObjectOutputStream oos = new ObjectOutputStream(fout);   
        			oos.writeObject(gameTab.ret_gameboard().ret_gameplay().ret_board());
        			oos.close();
        			   
        		 }
            	 catch(Exception ex){
            		 ex.printStackTrace();
        		 }
            }
		});
        
        //frame.pack();
        tabbedPane.setSelectedComponent(gameTab.ret_game_panel());

	}

	/**
	 * Inicializuje menu, nastaveni grafiky, nastaveni designu a polohy tlacitek a labelu
	 */
	public void initializeMenu() {
		
		ImageIcon play_icon = new ImageIcon("src/img/play.png");
    	ImageIcon header_icon = new ImageIcon("src/img/header.png");
    
    	JPanel Menu_panel = new JPanel() {
    		/**
			 * 
			 */
			private static final long serialVersionUID = -2482584872364225485L;

			@Override
			public Dimension getPreferredSize() {
        		Dimension size = super.getPreferredSize();
        		size.width += 100;
        		return size;
        	}
        };
        //BorderLayout layout = new BorderLayout();
        //Menu_panel.setLayout(layout);     
        GridBagLayout layout = new GridBagLayout();

        Menu_panel.setLayout(layout);   
        
        tabbedPane.addTab("Menu", Menu_panel);
        Menu_panel.setBackground(new Color(250,250,250));
        Menu_panel.setOpaque(true);
        frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);
        
        JLabel lb_header = new JLabel();
        lb_header.setIcon(header_icon);
        lb_header.setBackground(new Color(203,0,0));
        
        
        JComboBox<Object> Size_chooser = new JComboBox<Object>();
        Size_chooser.setModel(new DefaultComboBoxModel<Object>(new String[] {"8", "6", "10", "12"}));
        Size_chooser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String x = Size_chooser.getSelectedItem().toString();
				boardsize = Integer.parseInt(x);
				
			}
		});
        JComboBox<Object> Game_chooser = new JComboBox<Object>();
        Game_chooser.setModel(new DefaultComboBoxModel<Object>(new String[] {"none"}));
        Game_chooser.setSelectedIndex(0);
        Game_chooser.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String x = Game_chooser.getSelectedItem().toString();
			}
		});   
        
        JCheckBox disable_cb = new JCheckBox();
        disable_cb.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		if (hints) hints = false;
        		else hints = true;
        	}
        });
        
    	JLabel lb_a = new JLabel("I (s)");
		lb_a.setBackground(new Color(0,0,0));
		lb_a.setForeground(new Color(200,200,200));
		lb_a.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		JLabel lb_b = new JLabel("B (s)");
		lb_b.setBackground(new Color(0,0,0));
		lb_b.setForeground(new Color(200,200,200));
		lb_b.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		JLabel lb_c = new JLabel("C (pcs)");
		lb_c.setBackground(new Color(0,0,0));
		lb_c.setForeground(new Color(200,200,200));
		lb_c.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		JTextField a_tf = new JTextField("",4);
		a_tf.setEnabled(false);
		JTextField b_tf = new JTextField("",4);
		b_tf.setEnabled(false);
		JTextField c_tf = new JTextField("",4);
		c_tf.setEnabled(false);
		
        JCheckBox freeze_cb = new JCheckBox();
        freeze_cb.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		a = 0;
    			b = 0;
    			c = 0;
        		if (freezing) {
        			freezing = false;
        			lb_a.setForeground(new Color(200,200,200));
        			lb_b.setForeground(new Color(200,200,200));
        			lb_c.setForeground(new Color(200,200,200));
        			a_tf.setEnabled(false);
        			b_tf.setEnabled(false);
        			c_tf.setEnabled(false);
        		}
        		else {
        			freezing = true;
        			lb_a.setForeground(new Color(203,0,0));
        			lb_b.setForeground(new Color(203,0,0));
        			lb_c.setForeground(new Color(203,0,0));
        			a_tf.setEnabled(true);
        			b_tf.setEnabled(true);
        			c_tf.setEnabled(true);
        		}
          	}
        });
        
        JLabel lb_freeze = new JLabel("Disc Freezing");
		lb_freeze.setForeground(new Color(203,0,0));
        lb_freeze.setBackground(new Color(0,0,0));
		lb_freeze.setFont(new Font("Tahoma",Font.PLAIN,12));
        
        
        JLabel lb_hard = new JLabel("Hard mode");
		lb_hard.setForeground(new Color(200,200,200));
        lb_hard.setBackground(new Color(0,0,0));
		lb_hard.setFont(new Font("Tahoma",Font.PLAIN,12));
        
        
        JCheckBox diff_cb = new JCheckBox();
        diff_cb.setEnabled(false);
        diff_cb.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		if (hard) hard = false;
        		else hard = true;
        	}
        });
        
        JCheckBox pc_cb = new JCheckBox();
        pc_cb.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		if (pc) {
        			pc = false;
        			lb_hard.setForeground(new Color(200,200,200));
        			diff_cb.setEnabled(false);
        		}
        		else {
        			pc = true;
        			lb_hard.setForeground(new Color(203,0,0));
        			diff_cb.setEnabled(true);
        		}
        	}
        });
        
        JButton Play_button = new JButton();
        Play_button.setIcon(play_icon);
        Play_button.setOpaque(false);
        Play_button.setBackground(new Color(250,250,250));
        Play_button.setBorder(null);
        Play_button.addActionListener(new ActionListener() {
        	@Override
			public void actionPerformed(ActionEvent e) {
        		if (!Game_chooser.getSelectedItem().toString().equals("none")) {
		        	try {
		        		InputStream file = new FileInputStream("examples/" + Game_chooser.getSelectedItem().toString());
				        InputStream buffer = new BufferedInputStream(file); 	
				        ObjectInput input = new ObjectInputStream (buffer);
				  
		        		Board recovered = (Board)input.readObject();
		        		input.close();
		        		loadGame(recovered,Game_chooser.getSelectedItem().toString());
				    }
				    catch(ClassNotFoundException ex){
				      System.err.println("Cannot perform input. Class not found.");
				    }
				    catch(IOException ex){
					      System.err.println("Cannot perform input.");
				    }
		        	
		        }
        		else {
        			if (freezing) {
        				try
        			    {
        			      a = Integer.parseInt(a_tf.getText().trim());
        			      b = Integer.parseInt(b_tf.getText().trim());
        			      c = Integer.parseInt(c_tf.getText().trim());
        			      
        			     
        			    }
        			    catch (NumberFormatException nfe)
        			    {
        			      System.err.println("NumberFormatException");
        			    }
        				
        			}
        			createGame();
        		}
        	}
        });
        
        
        /*JPanel bottom = new JPanel() {

			public Dimension getPreferredSize() {
				return new Dimension((int)width, 300);
			};
        };*/
        
        //JLabel disable_lb = new JLabel("disable hints");
        //JLabel pc_lb = new JLabel("play vs PC");
        //pc_lb.setFont(new Font("Tahoma",Font.PLAIN,12));
        //JLabel diff_lb = new JLabel("hard difficulty");
        //diff_lb.setFont(new Font("Tahoma",Font.PLAIN,12));
        Game_chooser.setFont(new Font("Tahoma",Font.PLAIN,12));
        Size_chooser.setFont(new Font("Tahoma",Font.PLAIN,12));
        
        JLabel lb_size_heading = new JLabel("Choose size:");
		lb_size_heading.setBackground(new Color(0,0,0));
		lb_size_heading.setForeground(new Color(203,0,0));
		lb_size_heading.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		
		JLabel lb_game_heading = new JLabel("Choose game:");
		lb_game_heading.setBackground(new Color(0,0,0));
		lb_game_heading.setForeground(new Color(203,0,0));
		lb_game_heading.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		
		JLabel lb_vspc = new JLabel("Play vs Computer");
		lb_vspc.setBackground(new Color(0,0,0));
		lb_vspc.setForeground(new Color(203,0,0));
		lb_vspc.setFont(new Font("Tahoma",Font.PLAIN,12));
        
		JLabel lb_disable = new JLabel("Disable hints");
		lb_disable.setBackground(new Color(0,0,0));
		lb_disable.setForeground(new Color(203,0,0));
		lb_disable.setFont(new Font("Tahoma",Font.PLAIN,12));
        
	
        
		
		GridBagConstraints gbc = new GridBagConstraints();
        
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridwidth = 13;
        gbc.gridx = 13;
        gbc.gridy = 0;
        gbc.insets = new Insets(-500,0,0,0);
        Menu_panel.add(lb_header,gbc);
        
        gbc.fill = GridBagConstraints.NONE;
        
        gbc.gridy = 3;
		gbc.insets = new Insets(0,0,0,0);
        Menu_panel.add(Play_button,gbc);

        gbc.gridy = 3;
        gbc.insets = new Insets(0,0,-40,-800);
        Menu_panel.add(Size_chooser,gbc);
        
        gbc.gridy = 3;
        gbc.insets = new Insets(0,0,-40,800);
        Menu_panel.add(Game_chooser,gbc);
       
		gbc.gridy = 2;
		gbc.insets = new Insets(0,0,-90,-800);
		Menu_panel.add(lb_size_heading,gbc);
		
		gbc.gridy = 2;
		gbc.insets = new Insets(0,0,-90,800);
		Menu_panel.add(lb_game_heading,gbc);
        
		gbc.gridy = 5;
		gbc.insets = new Insets(0,0,-200,-300);
		Menu_panel.add(lb_vspc,gbc);

		gbc.gridy = 5;
		gbc.insets = new Insets(0,0,-200,0);
		Menu_panel.add(lb_hard,gbc);

		gbc.gridy = 5;
		gbc.insets = new Insets(0,-300,-200,0);
		Menu_panel.add(lb_disable,gbc);

		gbc.gridy = 7;
        gbc.insets = new Insets(0,0,-300,-300);
        Menu_panel.add(pc_cb,gbc);

        gbc.gridy = 7;
        gbc.insets = new Insets(0,0,-300,0);
        Menu_panel.add(diff_cb,gbc);

        gbc.gridy = 7;
        gbc.insets = new Insets(0,-300,-300,0);
        Menu_panel.add(disable_cb,gbc);
        
        gbc.gridy = 9;
		gbc.insets = new Insets(0,0,-400,0);
		Menu_panel.add(lb_freeze,gbc);

		gbc.gridy = 11;
		gbc.insets = new Insets(0,0,-500,0);
		Menu_panel.add(freeze_cb,gbc);

		gbc.gridy = 13;
		gbc.insets = new Insets(0,-300,-600,0);
		Menu_panel.add(lb_a,gbc);

		gbc.gridy = 13;
		gbc.insets = new Insets(0,0,-600,0);
		Menu_panel.add(lb_b,gbc);

		gbc.gridy = 13;
		gbc.insets = new Insets(0,0,-600,-300);
		Menu_panel.add(lb_c,gbc);
		
		gbc.gridy = 15;
		gbc.insets = new Insets(0,-300,-700,0);
		Menu_panel.add(a_tf,gbc);

		gbc.gridy = 15;
		gbc.insets = new Insets(0,0,-700,0);
		Menu_panel.add(b_tf,gbc);

		gbc.gridy = 15;
		gbc.insets = new Insets(0,0,-700,-300);
		Menu_panel.add(c_tf,gbc);

		
        /*
        bottom.setLayout(new BoxLayout(bottom,BoxLayout.X_AXIS));
        bottom.add(diff_cb);
        bottom.add(diff_lb);
        bottom.add(pc_cb);
        bottom.add(pc_lb);
        bottom.add(disable_cb);
        bottom.add(disable_lb);
        bottom.setBorder(BorderFactory.createEmptyBorder(0, 400, 0, 500));
        pc_cb.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 0));
        pc_lb.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 50));
        disable_lb.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        diff_lb.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 0));
        */
        freeze_cb.setIcon(new ImageIcon("src/img/unchecked.png"));
        freeze_cb.setSelectedIcon(new ImageIcon("src/img/checkbox.png"));
        diff_cb.setIcon(new ImageIcon("src/img/unchecked.png"));
        diff_cb.setSelectedIcon(new ImageIcon("src/img/checkbox.png"));
        pc_cb.setIcon(new ImageIcon("src/img/unchecked.png"));
        pc_cb.setSelectedIcon(new ImageIcon("src/img/checkbox.png"));
        disable_cb.setIcon(new ImageIcon("src/img/unchecked.png"));
        disable_cb.setSelectedIcon(new ImageIcon("src/img/checkbox.png"));
        disable_cb.setFocusable(false);
        diff_cb.setFocusable(false);
        pc_cb.setFocusable(false);
        freeze_cb.setFocusable(false);
        diff_cb.setBackground(new Color(250,250,250));
        pc_cb.setBackground(new Color(250,250,250));
        disable_cb.setBackground(new Color(250,250,250));
        freeze_cb.setBackground(new Color(250,250,250));
    	/*
             
        JLabel size_lb = new JLabel("pick board size:");
        size_lb.setFont(new Font("Tahoma",Font.PLAIN,12));
        
        JLabel load_lb = new JLabel("pick saved game:");
        load_lb.setFont(new Font("Tahoma",Font.PLAIN,12));
        
        JPanel center = new JPanel();
        center.setLayout(new BoxLayout(center,BoxLayout.X_AXIS));
        center.add(load_lb);
        center.add(Game_chooser);
        center.add(Play_button);
        center.add(size_lb);
        center.add(Size_chooser);
        center.setBorder(BorderFactory.createEmptyBorder(0, 0, 200, 0));     
        
        load_lb.setBorder(BorderFactory.createEmptyBorder(100, 20, 100, 0));
        Game_chooser.setBorder(BorderFactory.createEmptyBorder(100, 30, 100, 30));
        size_lb.setBorder(BorderFactory.createEmptyBorder(100, 30, 100, 30));
        Size_chooser.setBorder(BorderFactory.createEmptyBorder(100, 0, 100, 100));
        Play_button.setBorder(BorderFactory.createEmptyBorder(100, 0, 100, 0));
        Play_button.setBackground(new Color(237,237,237));
        
        
        Menu_panel.add(lb_header, BorderLayout.NORTH);
        Menu_panel.setBackground(new Color(203,0,0));
        
        Menu_panel.add(center, BorderLayout.CENTER);
        Menu_panel.add(bottom, BorderLayout.PAGE_END);
		*/
	
        File directory = new File("examples");
        File[] fList = directory.listFiles();
        for (File file : fList){
            if (file.isFile()){
            	Game_chooser.addItem(file.getName());
            }
        }

	}


	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					Reversi window = new Reversi();
					window.frame.setVisible(true);
					window.initializeMenu();
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}


}
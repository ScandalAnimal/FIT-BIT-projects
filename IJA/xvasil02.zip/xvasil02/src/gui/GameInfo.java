package gui;
/**
 * @author Maroš Vasilišin, Marrtin Urbanczyk
 * Informace o dane konkretni hre
 */

import java.io.Serializable;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JToolBar;

/**
 * Obsahuje informace o dane konkretni hre
 */
public class GameInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JToolBar tools;
	private JToolBar scoreboard;

	private JButton save_button;
	private JButton undo_button;
	private JButton quit_button;
	
	private JLabel lb_message;
	private JLabel lb_player;
	private JLabel lb_cnt_w;
	private JLabel lb_cnt_b;
	
	private ImageIcon[] icons;
	private boolean pc;

	/**
	 * Informace o dane hre
	 * @param icons ikony
	 * @param pc umela inteligence
     */
	public GameInfo(ImageIcon[] icons, boolean pc) {
		
		this.icons = icons;
		this.pc = pc;
		initializeInfoBoard();
		createButtons();
		createLabels();
		addButtons();
		addScoreBoardLabels();
		
	}

	/**
	 * Nainicializuje informacni desku
	 */
	private void initializeInfoBoard() {
		tools = new JToolBar();
		tools.setLayout(new BoxLayout(tools,BoxLayout.X_AXIS));
		tools.setFloatable(false);

		scoreboard = new JToolBar();
		scoreboard.setLayout(new BoxLayout(scoreboard,BoxLayout.X_AXIS));
		scoreboard.setFloatable(false);
		
	}

	/**
	 * Vytvori tlacitka na ulozeni, ukonceni a operaci undo.
	 */
	private void createButtons() {
		save_button = new JButton("Save");
		undo_button = new JButton("Undo");
		undo_button.setEnabled(false);
		quit_button = new JButton("Quit");
	}

	/**
	 * Vytvori dalsi neaktivni tlacitka, ktere predevsim informuji o stavu hry.
	 */
	private void createLabels() {
		lb_cnt_w = new JLabel();
		lb_cnt_b = new JLabel();
		lb_message = new JLabel();
		lb_player = new JLabel();
	}

	/**
	 * Prida tlacitka
	 */
	private void addButtons() {
		tools.add(save_button);
        tools.addSeparator();
        tools.add(lb_message);
        tools.add(lb_player);
        tools.addSeparator();
        tools.add(undo_button);
        tools.addSeparator();
        tools.add(quit_button);
	}

	/**
	 * Prida labely s informacemi o skore
	 */
	private void addScoreBoardLabels() {
        scoreboard.add(lb_cnt_w);
        scoreboard.addSeparator();
        scoreboard.add(lb_cnt_b);
	}
	
	public JToolBar ret_tools(){
		return tools;
	}

	/**
	 * Informace o skore
	 * @return tabulka se skore
     */
	public JToolBar ret_scoreboard() {
		return scoreboard;
	}

	/**
	 * Pocitadlo bilych
	 * @return pocitadlo bilych
     */
	public JLabel ret_lb_cnt_w() {
		return lb_cnt_w;
	}
	/**
	 * Pocitadlo bilych
	 * @return pocitadlo cernych
	 */
	public JLabel ret_lb_cnt_b() {
		return lb_cnt_b;
	}

	/**
	 * Zprava o hre
	 * @return label zpravy o hre
     */
	public JLabel ret_lb_message() {
		return lb_message;
	}

	/**
	 * Info o hraci
	 * @return label hrace
     */
	public JLabel ret_lb_player() {
		return lb_player;
	}

	/**
	 * Tlacitko ulozeni
	 * @return tlacitko ulozeni
     */
	public JButton ret_save_button() {
		return save_button;
	}
	/**
	 * Tlacitko operace undo
	 * @return tlacitko operace undo
	 */
	public JButton ret_undo_button() {
		return undo_button;
	}

	/**
	 * Tlacitko ukonceni
	 * @return vraci tlacitko ukonceni
	 */
	public JButton ret_quit_button() {
		return quit_button;
	}

	/**
	 * Vraci ikony
	 * @return ikony
     */
	public ImageIcon[] ret_icons() {
		return icons;
	}

	/**
	 * Vraci umelou inteligenci
	 * @return umela inteligence
     */
	public boolean ret_pc() {
		return pc;
	}

	/**
	 * Nuluje labely po konci hry
	 * @param winner vitez
     */
	public void nullLabels(String winner) {
		lb_player.setText(null);
    	lb_player.setBackground(null);
    	lb_player.setForeground(null);
    	lb_player.setBorder(null);
    	lb_message.setText("Vyhral hrac: " + winner);
    	
	}
}
package gui;
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Zalozka hry.
 */

import java.io.Serializable;

import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.border.EmptyBorder;


/**
 * Zalozka hry, tzn. kdyz je vytvorena nova hra, tak se vytvori zalozka a na ni probiha cela hra.
 */
public class GameTab implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4929335682044760702L;
	private GameBoard game_board;
	private GameInfo game_info;
	private JPanel game_panel;
	public int test = 19;

	/**
	 * Vytvoreni hraci plochy a infa o hre.
	 * @param size velikost
	 * @param icons ikony
	 * @param hints napovedy
	 * @param pc umela inteligence
	 * @param hard tezky mod
	 * @param end konec hry
	 * @param freezing zamrzani
	 * @param tabbedPane fungovani pres zalozky
     * @param a hodnota pole a
	 * @param b hodnota pole b
     * @param c hodnota pole c
     */
	public GameTab(int size, ImageIcon[] icons, boolean hints, boolean pc ,boolean hard, boolean end, boolean freezing,JTabbedPane tabbedPane, int a, int b, int c) {
		
		game_panel = new JPanel();
		game_panel.setLayout(new BoxLayout(game_panel,BoxLayout.Y_AXIS));
		game_panel.setBorder(new EmptyBorder(5,5,5,5));
		
		game_info = new GameInfo(icons,pc);
		game_board = new GameBoard(tabbedPane,game_info,size,hints,pc,hard,end,freezing,a,b,c);
		
		game_panel.add(game_info.ret_tools());
		game_panel.add(game_info.ret_scoreboard());
        
		
	}

	/**
	 * Vraci hraci desku
	 * @return hraci deska
     */
	public GameBoard ret_gameboard() {
		return game_board;
	}

	/**
	 * Vraci info o hre
	 * @return info o hre
     */
	public GameInfo ret_gameinfo() {
		return game_info;
	}

	/**
	 * Vraci jPanel, ktery obsahuje hraci desku.
	 * @return vraci panel desky
	 */
	public JPanel ret_game_panel() {
		return game_panel;
	}
}
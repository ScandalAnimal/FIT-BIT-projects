package gui;
/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Dalsi trida implementujici grafickou hraci desku
 */

import java.awt.Color;
import java.awt.Cursor;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ThreadLocalRandom;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

import board.Board;
import board.Disk;
import gui.GameInfo;

/**
 * Dalsi trida implementujici grafickou hraci desku
 */

public class GameBoard implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 7510233530694173719L;
	private int size;
	private JButton[][] BoardSquares;
	private JPanel board_panel;
	private GamePlay game_play;
	
	private int[][] undo_array;
	
	private GameInfo game_info;
	private JTabbedPane tabbedPane;
	
	private Color color;
	private Color color2;
	
	private boolean made_move = false;

	/**
	 * Inicializuje hraci desku
	 * @param tabbedPane JPanel typu JTabbedPane
	 * @param game_info info o hre
	 * @param size velikost
	 * @param hints napovedy
	 * @param pc umela inteligence
	 * @param hard tezky moc
	 * @param end konec hry
	 * @param freezing zamrzani kamenu
     * @param a hodnota pole a
     * @param b hodnota pole b
     * @param c hodnota pole c
     */
	public GameBoard(JTabbedPane tabbedPane, GameInfo game_info, int size, boolean hints, boolean pc, boolean hard, boolean end,boolean freezing,int a, int b, int c) {
		
		this.tabbedPane = tabbedPane;
		this.size = size;
		
		color = new Color(255,55,55);
		color2 = new Color(0,64,95);
		initializeBoard();
		this.game_info = game_info; 
		addListeners();
		
		game_play = new GamePlay(this, game_info);
		game_play.setRules(hints,pc,hard,end,freezing,a,b,c);
		
		undo_array = new int[size+2][size*2];
		gameEngine();
	}

	/**
	 * Inicializuje desku
	 */
	private void initializeBoard() {
		BoardSquares = new JButton[size+4][size+4];
		board_panel = new JPanel(new GridBagLayout());
	}

	/**
	 * Vraci tlacitka na hraci plose
	 * @return tlacitka
     */
	public JButton[][] ret_boardsquares() {
		return BoardSquares;
	}

	/**
	 * Vrati velikost
	 * @return velikost
     */
	public int ret_size() {
		return size;
	}

	/**
	 * Vraci jPanel, ktery obsahuje hraci desku.
	 * @return vraci panel desky
     */
	public JPanel ret_board_panel() {
		return board_panel;
	}

	/**
	 * Informace o samotne hre, udaje o stavu hry a pravidelch
	 * @return gameplay
     */
	public GamePlay ret_gameplay() {
		return game_play;
	}

	/**
	 * Provede zpetnou operaci undo
	 * @param icons ikony
     */
	public void perform_undo(ImageIcon[] icons) {
		for (int a = 0; a < size+2; a++) {
        	for (int b = 0; b < size+2; b++) {
        		if (a > 0 && b > 0 && a < size+1 && b < size+1) {
        			switch (undo_array[a][b]){
	        			case 0: {
	        				BoardSquares[a+1][b+1].setIcon(icons[2]);
	        				break;
	        			}
	        			case 1: {
	        				game_play.ret_game().getBoard().getField(a, b).setEmpty(0);
	        				game_play.ret_game().getBoard().getField(a, b).putDisk(new Disk(true));
	        				BoardSquares[a+1][b+1].setIcon(icons[0]);
	        				break;
	        			}
	        			case 2: {
	        				game_play.ret_game().getBoard().getField(a, b).setEmpty(0);
	        				game_play.ret_game().getBoard().getField(a, b).putDisk(new Disk(false));
	        				BoardSquares[a+1][b+1].setIcon(icons[1]);
	        				break;
	        			}
	        			case 3: {
	        				game_play.ret_game().getBoard().getField(a, b).setEmpty(0);
	        				BoardSquares[a+1][b+1].setIcon(icons[2]);
	        				break;
	        			}
	        			default: {
	        				return;
	        			}
        			}	
        		}
        	}
        }
	}

	/**
	 * Vraci pole po provedeni undo
	 * @return pole po undo
     */
	public int[][] ret_undo_array() {
		return undo_array;
	}

	/**
	 * Nastavi pole pri undo
	 * @param x index x
	 * @param y index y
	 * @param value hodnota pole
     */
	public void set_undo_array(int x, int y, int value){
		undo_array[x][y] = value; // 0-border, 1-white, 2-black, 3-empty
	}

	/**
	 * Prida listenery
	 */
	private void addListeners() {
		game_info.ret_undo_button().addActionListener(new ActionListener() {
            @Override
			public void actionPerformed(ActionEvent e) {
            	perform_undo(game_info.ret_icons());
            	game_info.ret_undo_button().setEnabled(false);
            	if (!game_info.ret_pc()) {
	            	game_play.ret_game().nextPlayer();
	            	game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
	                if (game_play.ret_game().currentPlayer().isWhite()) {
	                	game_info.ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.WHITE, 10));
	                	game_info.ret_lb_player().setBackground(Color.WHITE);
	                	game_info.ret_lb_player().setForeground(Color.BLACK);	
	                }
	                else {
	                	game_info.ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
	                	game_info.ret_lb_player().setBackground(Color.BLACK);
	                	game_info.ret_lb_player().setForeground(Color.WHITE);	
	                }
            	}
                int whites = 0;
            	int blacks = 0;
            	for (int it = 0; it < BoardSquares.length; it++) {
                    for (int ix = 0; ix < BoardSquares.length; ix++) {
                    	if ((it > 1) && (ix > 1) && (it < BoardSquares.length-2) && (ix < BoardSquares.length-2)) {
                        	if(game_play.ret_game().getBoard().getField(it-1, ix-1).isEmpty() == false) {
                        		if (game_play.ret_game().getBoard().getField(it-1, ix-1).getDisk().isWhite()) {
                        			whites++;
                        		}
                        		else blacks++;
                        	}
                        }
                    }
                }
            	game_info.ret_lb_cnt_w().setText("WHITE: " + whites);
            	game_info.ret_lb_cnt_b().setText(blacks + " :BLACK");
            	if (game_play.ret_hints()) {
                    for (int it = 0; it < BoardSquares.length; it++) {
                        for (int ix = 0; ix < BoardSquares.length; ix++) {
                        	if (BoardSquares[it][ix].getIcon().equals(game_info.ret_icons()[3])) {
                        		BoardSquares[it][ix].setIcon(game_info.ret_icons()[2]);
                        	}
                        	if ((it > 1) && (ix > 1) && (it < BoardSquares.length-2) && (ix < BoardSquares.length-2)) {
                            	if (game_play.ret_game().currentPlayer().canPutDisk(game_play.ret_game().getBoard().getField(it - 1, ix - 1))) {
                            		BoardSquares[it][ix].setIcon(game_info.ret_icons()[3]);
                            	}
                            }
                        }
                    }
            	}
            }
		});

		/**
		 * Vrati ukoncovaci tlacitko
		 */
		game_info.ret_quit_button().addActionListener(new ActionListener() {
			/**
			 * Provedena akce
			 * @param e udalost
             */
            @Override
			public void actionPerformed(ActionEvent e) {
            	Object[] options = {"Yes, please",
                        "No, thanks"};
			    int n = JOptionPane.showOptionDialog(board_panel,
			        "Would you like to save the game before quitting?",
			        "Quit",
			        JOptionPane.YES_NO_CANCEL_OPTION,
			        JOptionPane.INFORMATION_MESSAGE,
			        null,
			        options,
			        options[1]);
			    if (n == 0) {
			    	game_play.ret_board().set_serial_data(
	            			game_play.ret_whites(),
	            			game_play.ret_blacks(),
	            			game_play.ret_game().currentPlayer().isWhite(),
	            			game_play.ret_hints(),
	            			game_play.ret_pc(),
	            			game_play.ret_hard(),
	            			BoardSquares);
	            			
	            	try {
	            		Date date = new Date();
	            		
	       		        SimpleDateFormat format =
	       		        	new SimpleDateFormat("MMddyyyyHHmm");

	       		        String game_name = "" + format.format(date);
	        			FileOutputStream fout = new FileOutputStream("examples/" + game_name);
	        			ObjectOutputStream oos = new ObjectOutputStream(fout);   
	        			oos.writeObject(game_play.ret_board());
	        			oos.close();
	        			   
	        		 }
	            	 catch(Exception ex){
	            		 ex.printStackTrace();
	        		 }
			    	
	            	int index = tabbedPane.getSelectedIndex();
			    	tabbedPane.removeTabAt(index);

			    }
			    else if (n == 1) {
			    	int index = tabbedPane.getSelectedIndex();
			    	tabbedPane.removeTabAt(index);
			    	game_play.set_end(true);
			    }
            }
		});

	}

	/**
	 * Vytvori tlacitko
	 * @return tlacitko
     */
	private JButton createButton() {
		JButton b = new JButton();
		b.setFocusable(false);
    	b.setRolloverEnabled(false);
    	b.setIcon(game_info.ret_icons()[2]);

		return b;
	}

	/**
	 * Nastavi operaci undo
	 */
	private void set_undo() {
		for (int a = 0; a < size+2; a++) {
        	for (int b = 0; b < size+2; b++) {
        		if (a > 0 && b > 0 && a < size+1 && b < size+1) {
            		if (game_play.ret_game().getBoard().getField(a, b).isEmpty() == true) {
            			set_undo_array(a, b, 3);
            		}
            		else {
            			if (game_play.ret_game().getBoard().getField(a, b).getDisk().isWhite()) {
                			set_undo_array(a, b, 1);
                		}
            			else set_undo_array(a, b, 2);
            		}
        		}
        	}
        }
	}

	/**
	 * Provede zmrazeni kamenu
	 * @param count
     */
	private void freeze(int count) {
		int local_count = count;
		int[] possibleX = new int[144];
		int indexX = 0;
		for (int i = 0; i < possibleX.length; i++) {
			possibleX[i] = 0;
		}
		int[] possibleY = new int[144];
		int indexY = 0;
		for (int i = 0; i < possibleY.length; i++) {
			possibleY[i] = 0;
		}
		
		for (int i = 1; i < game_play.ret_board().getSize()-1; i++) {
			for (int j = 1; j < game_play.ret_board().getSize()-1; j++) {
				if (local_count > 0) {
					if (!game_play.ret_board().getField(i, j).isEmpty()) {
						possibleX[indexX] = i;
						possibleY[indexY] = j;
						indexX++;
						indexY++;
					}
				}
			}
		}
		
		int cnt = 0;
		for (int pos: possibleX) {
			if (pos != 0) {
				cnt++;
			}
		}
		
		while (local_count > 0) {
			int move = new Random().nextInt(cnt-1);
			if (!game_play.ret_board().getField(possibleX[move], possibleY[move]).isFrozen()) {
				game_play.ret_board().getField(possibleX[move], possibleY[move]).triggerFrozen();
				BoardSquares[possibleX[move]+1][possibleY[move]+1].setIcon(game_info.ret_icons()[4]);
				local_count--;
			}
			else {
				continue;
			}
		}
		
		
	}

	/**
	 * Provede "odmrazeni" kamenu
	 */
	private void unfreeze() {
		for (int i = 1; i < game_play.ret_board().getSize()-1; i++) {
			for (int j = 1; j < game_play.ret_board().getSize()-1; j++) {
				if (game_play.ret_board().getField(i,j).isFrozen()) {
					if (game_play.ret_board().getField(i, j).getDisk().isWhite()) {
						game_play.ret_board().getField(i,j).triggerFrozen();
						BoardSquares[i+1][j+1].setIcon(game_info.ret_icons()[0]);
					}
					else {
						game_play.ret_board().getField(i,j).triggerFrozen();
						BoardSquares[i+1][j+1].setIcon(game_info.ret_icons()[1]);
					}
				}
					
			}
		}
	}

	/**
	 * Interval po kterem kameny odmrznou.
	 */
	private void callTimerB() {
		long randomB = (long)(ThreadLocalRandom.current().nextDouble(0, game_play.ret_b() + 1)) * 1000;
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask() {
    		@Override
			public void run() {
    			boolean no_moves_flag = false;
    			while(!made_move) {
    				try {
        		        Thread.sleep(1000);
        		        boolean found = false;
        				for (int i = 1; i < game_play.ret_board().getSize()-1; i++) {
        					for (int j = 1; j < game_play.ret_board().getSize()-1; j++) {
        						if (game_play.ret_game().currentPlayer().isWhite()){
        							if (BoardSquares[i+1][j+1].getIcon().equals(game_info.ret_icons()[0])) {
        								found = true;
        							}
        						}
        						else {
        							if (BoardSquares[i+1][j+1].getIcon().equals(game_info.ret_icons()[1])) {
        								found = true;
        							}
        						}
        					}
        				}
        				
        				if (found == false) {
        					game_info.ret_lb_player().setText(null);
        					game_info.ret_lb_player().setBackground(null);
        					game_info.ret_lb_player().setForeground(null);
        					game_info.ret_lb_player().setBorder(null);
        					game_info.ret_lb_message().setText("Ziaden dalsi tah nie je mozny");
        					no_moves_flag = true;
        					break;
        				}
        				
        		    } catch (InterruptedException e) {
        		        System.err.println("Thread interrupted.");
        		    }
    			}
    			if (!no_moves_flag) {
	    			made_move = false;
	    			if (!game_play.ret_end()) {
	              		callTimerI();
	              	}
    			}
    		}
    	}, randomB);
	}

	/**
	 * Interval, po kterem kameny zamrznou.
	 */
	private void callTimerI() {
		long randomI = (long)(ThreadLocalRandom.current().nextDouble(0, game_play.ret_a() + 1)) * 1000;
    	Timer timer = new Timer();
    	timer.schedule(new TimerTask() {
    		@Override
			public void run() {
    			freeze(game_play.ret_c());
              	callTimerB();
    		}
    	}, randomI);
	}

	/**
	 * Provede tah
	 * @param b tlacitko
	 * @param new_ii nove souradnice ii
	 * @param new_jj nove sourdanice jj
     * @return vrati uspesnost akce
     */
	public boolean perform_move(JButton b, int new_ii, int new_jj) {
		
		if (game_play.ret_game().currentPlayer().canPutDisk(game_play.ret_game().getBoard().getField(new_ii - 1, new_jj - 1))) {
            if (game_play.ret_game().currentPlayer().isWhite() == true) {
                b.setIcon(game_info.ret_icons()[0]);

            } else {
                b.setIcon(game_info.ret_icons()[1]);
            }
            set_undo();
            
            game_play.ret_game().currentPlayer().putDisk(game_play.ret_game().getBoard().getField(new_ii - 1, new_jj - 1));
            game_play.turnIcons(game_info.ret_icons());
            game_play.ret_game().nextPlayer();
            game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
            
            
            game_play.changeCurrentPlayerLabel();
            
            game_play.changeScoreBoard(game_play.ret_pc());
            made_move = true;
            unfreeze();
            return true;
        }
		else {
			return false;
		}
	}
	
	public boolean perform_loaded_move(JButton b, int new_ii, int new_jj, boolean player) {
		
		if (game_play.ret_game().currentPlayer().canPutDisk(game_play.ret_game().getBoard().getField(new_ii - 1, new_jj - 1))) {
            if (game_play.ret_game().currentPlayer().isWhite() == true) {
                b.setIcon(game_info.ret_icons()[0]);

            } else {
                b.setIcon(game_info.ret_icons()[1]);
            }
            set_undo();
            
            game_play.ret_game().currentPlayer().putDisk(game_play.ret_game().getBoard().getField(new_ii - 1, new_jj - 1));
            game_play.turnIcons(game_info.ret_icons());
            game_play.ret_game().nextPlayer();
            game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
            
            
            game_play.changeCurrentPlayerLabel();
            
            game_play.changeScoreBoard(game_play.ret_pc());
            made_move = true;
            unfreeze();
            return true;
        }
		else {
			return false;
		}
	}

	/**
	 * Samotny herni engine, srdce celeho programu, vetsina akci spojena se samotnou hrou se provadi prave zde.
	 */
	private void gameEngine() {
		for (int ii = 0; ii < BoardSquares.length; ii++) {
            for (int jj = 0; jj < BoardSquares.length; jj++) {
                
            	JButton b = createButton();
          
                if ((ii <= 1) || (jj <= 1) || (ii >= BoardSquares.length-2) || (jj >= BoardSquares.length-2)) {
                	b.setBackground(color);
                	b.setBorderPainted(false);
                    b.setEnabled(false);
                }
                
                if ((ii > 1) && (jj > 1) && (ii < BoardSquares.length-2) && (jj < BoardSquares.length-2)) {
                    if (game_play.ret_game().getBoard().getField(ii - 1, jj - 1).isEmpty() == false) {
                        if (game_play.ret_game().getBoard().getField(ii - 1, jj - 1).getDisk().color == true) {
                            b.setIcon(game_info.ret_icons()[0]);
                        } else if (game_play.ret_game().getBoard().getField(ii - 1, jj - 1).getDisk().color == false) {
                            b.setIcon(game_info.ret_icons()[1]);
                        }
                    }
                    b.setBackground(color2);
                    b.setForeground(Color.GRAY);
                    b.setCursor(new Cursor(Cursor.HAND_CURSOR));
                    int new_ii = ii;
                    int new_jj = jj;
                    b.addActionListener(new ActionListener() {
                        @Override
						public void actionPerformed(ActionEvent e) {
                        	game_info.ret_undo_button().setEnabled(true);
                        	if (game_play.ret_end()) return;
                        	if (game_play.ret_ignore() == true) {
                        		return;
                        	}
                        	game_play.set_available_moves(0);
                            if (!game_play.ret_pc()) {
	                        	if (b.getIcon().equals(game_info.ret_icons()[2]) || b.getIcon().equals(game_info.ret_icons()[3])) {
	                        		if (!perform_move(b,new_ii,new_jj)) {
                            			return;
                            		};
	                            }
	                        	else {
                            		return;
                            	}
	                            if (game_play.ret_hints()) {
	                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

		                            
		                            if (game_play.ret_available_moves() == 0) {
		                            	game_play.ret_game().nextPlayer();
		                            	game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
		                            	game_play.changeCurrentPlayerLabel();
		                            	
		                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

	                                    if ((game_play.ret_available_moves() == 0) && (game_play.ret_end() == false)){
	                                    	game_play.changeCurrentPlayerLabel();
	                                    	game_play.changeScoreBoard(game_play.ret_pc());
	                                    	
	                                    	game_play.set_end(true);
	                                    	String winner = (game_play.ret_whites() > game_play.ret_blacks()) ? "white" : "black"; 
	                                    	game_info.nullLabels(winner);
	                                    	if (game_play.ret_whites() == game_play.ret_blacks()) {
	                                    		game_info.ret_lb_message().setText("Hra skoncila remizou.");
	                                    	}
	                                    	   		
	                                    }
	                                }
	                            }
	                            else {
	                            	game_play.set_available_moves(game_play.countMoves(game_info.ret_icons(), game_play.ret_available_moves()));

		                            
		                            if (game_play.ret_available_moves() == 0) {
		                            	game_play.ret_game().nextPlayer();
		                            	game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
		                            	game_play.changeCurrentPlayerLabel();
		                            	
		                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

	                                    if ((game_play.ret_available_moves() == 0) && (game_play.ret_end() == false)){
	                                    	game_play.changeCurrentPlayerLabel();
	                                    	game_play.changeScoreBoard(game_play.ret_pc());
	                                    	
	                                    	game_play.set_end(true);
	                                    	String winner = (game_play.ret_whites() > game_play.ret_blacks()) ? "white" : "black"; 
	                                    	game_info.nullLabels(winner);
	                                    	if (game_play.ret_whites() == game_play.ret_blacks()) {
	                                    		game_info.ret_lb_message().setText("Hra skoncila remizou.");
	                                    	}
	                                    	   		
	                                    }
	                                }
	                            }
                            }
                            else if (game_play.ret_pc()) {
                            	if (b.getIcon().equals(game_info.ret_icons()[2]) || b.getIcon().equals(game_info.ret_icons()[3])) {
                            		if (!perform_move(b,new_ii,new_jj)) {
                            			return;
                            		};
	                            }
                            	else {
                            		return;
                            	}
	                            if (game_play.ret_hints()) {
	                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

		                            
		                            if (game_play.ret_available_moves() == 0) {
		                            	game_play.ret_game().nextPlayer();
		                            	game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
		                            	game_play.changeCurrentPlayerLabel();
		                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

	                                    if ((game_play.ret_available_moves() == 0) && (game_play.ret_end() == false)){
	                                    	game_play.changeCurrentPlayerLabel();
	                                    	game_play.changeScoreBoard(game_play.ret_pc());
	                                    	game_play.set_end(true);
	                                    	String winner = (game_play.ret_whites() > game_play.ret_blacks()) ? "white" : "black"; 
	                                    	game_info.nullLabels(winner);
	                                    	if (game_play.ret_whites() == game_play.ret_blacks()) {
	                                    		game_info.ret_lb_message().setText("Hra skoncila remizou.");
	                                    	}
	                                    	   		
	                                    }
	                                }
		                            else {
		                            	game_play.trigger_ignore();
	                            		int moves = game_play.ret_available_moves();
		                            	int delay = 2000;
		                            	Timer timer = new Timer();
		                            	timer.schedule(new TimerTask() {
		                            		@Override
											public void run() {
		                                      	game_play.pc_action(game_info.ret_icons(), game_play.ret_hints(), moves);
		                                      	game_play.trigger_ignore();
		                            		}
		                            	}, delay);
		                            	
		                            }
	                            }
	                            else {
	                            	game_play.set_available_moves(game_play.countMoves(game_info.ret_icons(), game_play.ret_available_moves()));

		                            
		                            if (game_play.ret_available_moves() == 0) {
		                            	game_play.ret_game().nextPlayer();
		                            	game_info.ret_lb_player().setText("" + game_play.ret_game().currentPlayer() + "");
		                            	game_play.changeCurrentPlayerLabel();
		                            	game_play.set_available_moves(game_play.changeHints(game_info.ret_icons(), game_play.ret_available_moves()));

	                                    if ((game_play.ret_available_moves() == 0) && (game_play.ret_end() == false)){
	                                    	game_play.changeCurrentPlayerLabel();
	                                    	game_play.changeScoreBoard(game_play.ret_pc());
	                                    	game_play.set_end(true);
	                                    	String winner = (game_play.ret_whites() > game_play.ret_blacks()) ? "white" : "black"; 
	                                    	game_info.nullLabels(winner);
	                                    	if (game_play.ret_whites() == game_play.ret_blacks()) {
	                                    		game_info.ret_lb_message().setText("Hra skoncila remizou.");
	                                    	}
	                                    	   		
	                                    }
	                                }
		                            else {
		                            	game_play.trigger_ignore();
	                            		int moves = game_play.ret_available_moves();
		                            	int delay = 2000;
		                            	Timer timer = new Timer();
		                            	timer.schedule(new TimerTask() {
		                            		@Override
											public void run() {
		                                      	game_play.pc_action(game_info.ret_icons(), game_play.ret_hints(), moves);
		                                      	game_play.trigger_ignore();
		                            		}
		                            	}, delay);
		                            	
		                            }
	                            }
    
                            }
                            
                            game_info.ret_undo_button().setEnabled(true);
                        }
                    });
                }
                if (game_play.ret_hints()) {
                	if (b.getIcon().equals(game_info.ret_icons()[3])) {
                		b.setIcon(game_info.ret_icons()[2]);
                	}
                    if ((ii > 1) && (jj > 1) && (ii < BoardSquares.length-2) && (jj < BoardSquares.length-2)) {
                       	if (game_play.ret_game().currentPlayer().canPutDisk(game_play.ret_game().getBoard().getField(ii - 1, jj - 1))) {
                       		b.setIcon(game_info.ret_icons()[3]);
                       	}
                    }
                }
                
                BoardSquares[ii][jj] = b;
                if ((size > 8) && ((ii <=1) || (jj <=1) || (ii >= size+2) || (jj >= size+2))){
                	BoardSquares[ii][jj].setSize(BoardSquares[ii][jj].getWidth(), 2);
                }
            }
        }
		if (game_play.ret_freezing()) {
			
			callTimerI();
		}
	}
	
	public void change(Board board) {
		this.BoardSquares = board.serial_squares;
	}
}
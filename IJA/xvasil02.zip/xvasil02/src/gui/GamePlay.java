package gui;

/**
 * @author Maroš Vasilišin, Martin Urbanczyk
 * Trida, ktera realizuje hlavni vyvoj hry.
 */

import java.awt.Color;
import java.io.Serializable;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

import board.Board;
import game.Game;
import game.Player;
import game.ReversiRules;

/**
 * Trida, ktera realizuje hlavni vyvoj hry. Obsahuje veskere udaje o stavu hry a velke mnozstvi pravidel
 * hry.
 */

public class GamePlay implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private ReversiRules rules;
	public Board board;
	private Game game;
	private Player p1;
	private Player p2;
	
	private boolean game_hints;
	private boolean game_pc;
	private boolean game_hard;
	private boolean game_end;
	private boolean game_freezing;
	
	private int game_a;
	private int game_b;
	private int game_c;
	
	private boolean ignore = false;
	
	private int[] pc_moves_x;
	private int[] pc_moves_y;
	
	private int best_move = 0;
	
	private GameBoard game_board;
	private GameInfo game_info;
	
	private int[] availables;
	private int index;
	private int max;
	
	private int blacks;
	private int whites;
	
	private int available_moves;

	/**
	 * Inicializace hry
	 * @param game_board hraci deska
	 * @param game_info herni info
     */
	public GamePlay(GameBoard game_board, GameInfo game_info) {
		
		this.game_board = game_board;
		this.game_info = game_info;
		rules = new ReversiRules(game_board.ret_size());
        board = new Board(rules);
        game = new Game(board);
        
        p1 = new Player(true,game_board.ret_size());
        p2 = new Player(false,game_board.ret_size());
        
        game.addPlayer(p1);
        game.addPlayer(p2);
        
        pc_moves_x = new int[144];
		pc_moves_y = new int[144];
		
		availables = new int[144];
		index = 0;
		max = -25;
		
	}

	/**
	 * Nastaveni pravidel
	 * @param hints napovedy
	 * @param pc umela inteligence
	 * @param hard tezky mod
	 * @param end konec hry
	 * @param freezing zamrzani
	 * @param a prvni cislo pro zamrzani
     * @param b druhe cislo pro zamrzani
     * @param c treti cislo pro zamrzani
     */
	public void setRules(boolean hints, boolean pc, boolean hard, boolean end,boolean freezing,int a, int b, int c) {
		game_hints = hints;
		game_pc = pc;
		game_hard = hard;
		game_end = end;
		game_freezing = freezing;
		game_a = a;
		game_b = b;
		game_c = c;
	}

	/**
	 * Vraci pravidla
	 * @return pravidla
     */
	public ReversiRules ret_rules() {
		return rules;
	}

	/**
	 * Vraci desku
	 * @return deska
     */
	public Board ret_board() {
		return board;
	}

	/**
	 * Vrati hru
	 * @return hra
     */
	public Game ret_game() {
		return game;
	}

	/**
	 * Nastavi mozne tahy
	 * @param param parametr pro tahy
     */
	public void set_available_moves(int param) {
		available_moves = param;
	}

	/**
	 * Vraci mozne tahy
 	 * @return mozne tahy
     */
	public int ret_available_moves() {
		return available_moves;
	}

	/**
	 * Vraci bile
	 * @return bili
     */
	public int ret_whites() {
		return whites;
	}

	/**
	 * Vraci cerne
	 * @return cerni
     */
	public int ret_blacks() {
		return blacks;
	}

	/**
	 * Vrati prvniho hrace
	 * @return prvni hrac
     */
	public Player ret_p1() {
		return p1;
	}

	/**
	 * Vraci druheho hrace
	 * @return druhy hrac
     */
	public Player ret_p2() {
		return p2;
	}

	/**
	 * Vrati umelou inteligenci
	 * @return umela inteligence
     */
	public boolean ret_pc() {
		return game_pc;
	}

	/**
	 * Vrati tezky mod
	 * @return tezky mod
     */
	public boolean ret_hard() {
		return game_hard;
	}

	/**
	 * Vrati konec hry
	 * @return konec hry
     */
	public boolean ret_end() {
		return game_end;
	}

	/**
	 * Vrati napovedy na dalsi tah
	 * @return napovedy
     */
	public boolean ret_hints() {
		return game_hints;
	}

	/**
	 * Vrati zamrzani kamenu
	 * @return zamrzani
     */
	public boolean ret_freezing() {
		return game_freezing;
	}

	/**
	 * Vraci hodnotu pole a
	 * @return pole a
     */
	public int ret_a() {
		return game_a;
	}

	/**
	 * Vraci hodnotu pole b
	 * @return pole b
	 */
	public int ret_b() {
		return game_b;
	}

	/**
	 * Vraci hodnotu pole c
	 * @return pole c
	 */
	public int ret_c() {
		return game_c;
	}

	/**
	 * Nastavi konec
	 * @param param priznak pro end
     */
	public void set_end(boolean param) {
		game_end = param;
	}

	/**
	 * Vrati tahy umele inteligence
	 * @return tahy
     */
	public int[] ret_pc_moves_x() {
		return pc_moves_x;
	}

	/**
	 * Vrati tahy umele inteligence
	 * @return tahy
	 */
	public int[] ret_pc_moves_y() {
		return pc_moves_y;
	}
	public void trigger_ignore() {
		if (ignore) {
			ignore = false;
		}
		else ignore = true;
	}
	public boolean ret_ignore() {
		return ignore;
	}

	/**
	 * Nulove pole
	 * @param array pole
	 * @return
     */
	private int[] nullArray(int[] array) {
		for (int i = 0; i < array.length; i++) {
    		array[i] = -1;
    	}
		return array;
	}

	/**
	 * V teto metode probiha urceni tahu
	 * @param iterator Iterator
     */
	private void determineMoves(int iterator) {
		for (int it = 0; it < game_board.ret_boardsquares().length; it++) {
            for (int ix = 0; ix < game_board.ret_boardsquares().length; ix++) {
            	
            	if ((it > 1) && (ix > 1) && (it < game_board.ret_boardsquares().length-2) && (ix < game_board.ret_boardsquares().length-2)) {
                	if (game_board.ret_gameplay().ret_game().currentPlayer().canPutDisk(game_board.ret_gameplay().ret_game().getBoard().getField(it - 1, ix - 1))) {
                		pc_moves_x[iterator] = it;
                		pc_moves_y[iterator] = ix;
                		iterator++;
                	}
                }
            }
        }
	}

	/**
	 * Vybere tah s nejvetsi hodnotou -> nejvyhodnejsi pro oponenta.
	 */
	private void chooseMax() {
		index = 0;
		max = -25;
		for (int i = 0; i < pc_moves_x.length; i++) {
			if (pc_moves_x[i] != -1) {
    			int value = game_board.ret_gameplay().ret_game().getBoard().getField(pc_moves_x[i]-1, pc_moves_y[i]-1).ret_value();
    			if (value > max) {
    				max = value;
    				best_move = i;
    				index = 0;
    				for (int x = 0; x < availables.length;x++) {
    					availables[x] = -1;
    				}
    				availables[index] = i;
    				index++;
    			}
    			else if (value == max) {
    				availables[index] = i;
    				index++;
    			}
			}
		}
	}

	/**
	 * Vybere tah s hodnotou, ktera neni maximalni -> neni to nejvyhodnejsi dalsi tah pro oponenta.
	 * @return hodnota
     */
	private boolean chooseNotMax() {
		index = 0;
		max = -25;
		boolean some = false;
		for (int i = 0; i < pc_moves_x.length; i++) {
			if (pc_moves_x[i] != -1) {
    			int value = game_board.ret_gameplay().ret_game().getBoard().getField(pc_moves_x[i]-1, pc_moves_y[i]-1).ret_value();
    			if (value > max) {
    				max = value;
    			}
			}
		}
		for (int i = 0; i < pc_moves_x.length; i++) {
			if (pc_moves_x[i] != -1) {
    			int value = game_board.ret_gameplay().ret_game().getBoard().getField(pc_moves_x[i]-1, pc_moves_y[i]-1).ret_value();
    			
    			if (value < max) {
    				availables[index] = i;
    				index++;
    			}
    			else {
    				some = true;
    			}
			}
		}
		return some;
	}

	/**
	 * Nastavi ikony
	 * @param icons ikony
     */
	private void setIcons(ImageIcon[] icons) {
		if (game_board.ret_gameplay().ret_game().currentPlayer().isWhite() == true) {
			game_board.ret_boardsquares()[pc_moves_x[best_move]][pc_moves_y[best_move]].setIcon(icons[0]);
        } 
		else {
        	game_board.ret_boardsquares()[pc_moves_x[best_move]][pc_moves_y[best_move]].setIcon(icons[1]); 
        }
		game_board.ret_gameplay().ret_game().currentPlayer().putDisk(game_board.ret_gameplay().ret_game().getBoard().getField(pc_moves_x[best_move]-1, pc_moves_y[best_move]-1));
	}


	/**
	 * Zmeni ikony
	 * @param icons ikony
     */
	public void turnIcons(ImageIcon[] icons) {
		int[] abcd = game_board.ret_gameplay().ret_game().currentPlayer().returnTurned();
        for (int i : abcd) {
            if (i != 0) {
                int col = i / game_board.ret_size();
                int row = i % game_board.ret_size();
                if (row == 0) {
                    row = game_board.ret_size();
                    col--;
                }
                if (game_board.ret_gameplay().ret_game().currentPlayer().isWhite()) {
                	game_board.ret_boardsquares()[col + 1][row + 1].setIcon(icons[0]);
                } else {
                	game_board.ret_boardsquares()[col + 1][row + 1].setIcon(icons[1]);
                }
            }
        }
	}

	/**
	 * Zmeni label hrace, ktery je na tahu.
	 */
	public void changeCurrentPlayerLabel() {
		if (game_board.ret_gameplay().ret_game().currentPlayer().isWhite()) {
        	game_info.ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.WHITE, 10));
        	game_info.ret_lb_player().setBackground(Color.WHITE);
        	game_info.ret_lb_player().setForeground(Color.BLACK);	
        }
        else {
        	game_info.ret_lb_player().setBorder(BorderFactory.createLineBorder(Color.BLACK, 10));
        	game_info.ret_lb_player().setBackground(Color.BLACK);
        	game_info.ret_lb_player().setForeground(Color.WHITE);	
        }
	}

	/**
	 * Zmeni tabulku se skore
	 * @param pc umela inteligence
     */
	public void changeScoreBoard(boolean pc) {
		whites = 0;
    	blacks = 0;
    	for (int it = 0; it < game_board.ret_boardsquares().length; it++) {
            for (int ix = 0; ix < game_board.ret_boardsquares().length; ix++) {
            	if ((it > 1) && (ix > 1) && (it < game_board.ret_boardsquares().length-2) && (ix < game_board.ret_boardsquares().length-2)) {
                	if(game_board.ret_gameplay().ret_game().getBoard().getField(it-1, ix-1).isEmpty() == false) {
                		if (game_board.ret_gameplay().ret_game().getBoard().getField(it-1, ix-1).getDisk().isWhite()) {
                			whites++;
                		}
                		else blacks++;
                	}
                }
            }
        }
    	if (pc) {
    		game_info.ret_lb_cnt_w().setText("(PC) WHITE: " + whites);
    		game_info.ret_lb_cnt_b().setText(blacks + " :BLACK (YOU)");
    	}
    	else  {
    		game_info.ret_lb_cnt_w().setText("WHITE: " + whites);
    		game_info.ret_lb_cnt_b().setText(blacks + " :BLACK");
    	}
    	
	}

	/**
	 * Zmeni napovedy na dalsi tah
	 * @param icons ikony
	 * @param available_moves mozne tahy
     * @return vraci mozne tahy
     */
	public int changeHints(ImageIcon[] icons, int available_moves) {
		for (int it = 0; it < game_board.ret_boardsquares().length; it++) {
            for (int ix = 0; ix < game_board.ret_boardsquares().length; ix++) {
            	if (game_board.ret_boardsquares()[it][ix].getIcon().equals(icons[3])) {
            		game_board.ret_boardsquares()[it][ix].setIcon(icons[2]);
            	}
            	if ((it > 1) && (ix > 1) && (it < game_board.ret_boardsquares().length-2) && (ix < game_board.ret_boardsquares().length-2)) {
            		if (game_board.ret_gameplay().ret_game().currentPlayer().canPutDisk(board.getField(it - 1, ix - 1))) {
                		game_board.ret_boardsquares()[it][ix].setIcon(icons[3]);
                		game_board.ret_boardsquares()[it][ix].setEnabled(true);
                		available_moves++;
                	}
                }
            }
        }
		return available_moves;
	}
	/**
	 * Spocita tahy
	 * @param icons ikony
	 * @param available_moves mozne tahy
     * @return vraci mozne tahy
     */
	public int countMoves(ImageIcon[] icons, int available_moves) {
		for (int it = 0; it < game_board.ret_boardsquares().length; it++) {
            for (int ix = 0; ix < game_board.ret_boardsquares().length; ix++) {
            	if (game_board.ret_boardsquares()[it][ix].getIcon().equals(icons[3])) {
            		game_board.ret_boardsquares()[it][ix].setIcon(icons[2]);
            	}
            	if ((it > 1) && (ix > 1) && (it < game_board.ret_boardsquares().length-2) && (ix < game_board.ret_boardsquares().length-2)) {
                	if (game_board.ret_gameplay().ret_game().currentPlayer().canPutDisk(game_board.ret_gameplay().ret_game().getBoard().getField(it - 1, ix - 1))) {

                		//game_board.ret_boardsquares()[it][ix].setIcon(icons[3]);
                		available_moves++;
                	}
                }
            }
        }
		return available_moves;
	}

	/**
	 * Probiha akce, kterou vykonava pocitac(umela inteligence)
	 * @param icons ikony
	 * @param hints napovedy na dalsi tah
	 * @param available_moves mozne tahy
     */
	public void pc_action(ImageIcon[] icons, boolean hints, int available_moves) {
		
		
		
		pc_moves_x = nullArray(pc_moves_x);
		pc_moves_y = nullArray(pc_moves_y);
		
		int iterator = 0;
		determineMoves(iterator);
		
		boolean some = true;
		
    	if (game_board.ret_gameplay().ret_hard()) {
    		chooseMax();
    		if (index == 0) {
    			String winner = (whites > blacks) ? "white" : "black";
    			game_info.nullLabels(winner);
            	if (whites == blacks) {
            		game_info.ret_lb_message().setText("Hra skoncila remizou.");
            	}
    			return;
    		}
    		best_move = availables[new Random().nextInt(index)];
    	}
    	else {
    		some = chooseNotMax();
    		if (some) {
    			best_move = 0;
    		}
    		else {
    			if (index == 0) {
    				String winner = (whites > blacks) ? "white" : "black"; 
    				game_info.nullLabels(winner);
                	if (whites == blacks) {
                		game_info.ret_lb_message().setText("Hra skoncila remizou.");
                	}
        			return;
        		}
    			best_move = availables[new Random().nextInt(index)];
    		}
    	}
    	
    	if (pc_moves_x[best_move] != 0) {
    		
    		setIcons(icons);
    		turnIcons(icons);
            
    		game_board.ret_gameplay().ret_game().nextPlayer();
            game_info.ret_lb_player().setText("" + game_board.ret_gameplay().ret_game().currentPlayer() + "");
            
            changeCurrentPlayerLabel();

    	}
    	
    	changeScoreBoard(game_pc);
    	
    	available_moves = 0;
    	if (hints) {
    		available_moves = changeHints(icons,available_moves);
        }
    	else {
    		available_moves = countMoves(icons,available_moves);
    	}
    	if ((available_moves == 0) && (game_end == false)){
    		game_board.ret_gameplay().ret_game().nextPlayer();
    		
    		trigger_ignore();
    		int moves = available_moves;
    		int delay = 2000;
        	Timer timer2 = new Timer();
        	timer2.schedule(new TimerTask() {
        		@Override
				public void run() {
        			pc_action(icons, hints, moves);
                  	trigger_ignore();
        		}
        	}, delay);	
    	}
	}

	/**
	 * Nastavi desku
	 * @param new_board nova deska
     */
	public void serial_set_board(Board new_board) {
		this.board = new_board;
		this.game_board.change(new_board);
		this.game.setBoard(new_board);
		this.game.setPlayer(new_board.ret_serial_current_player());
	}
}
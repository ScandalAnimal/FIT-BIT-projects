<?php

function getFriends($customer, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('Relation.RelationId', 'Relation.CustomerName', 'Relation.DonorName', 'Relation.Status');

    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT Relation.RelationId, Relation.DonorName, U.FirstName, U.LastName, U.Age, U.Email, U.Phone, U.Address, Relation.Status
        FROM Relation INNER JOIN User AS U ON U.Username = Relation.DonorName
        WHERE Relation.CustomerName = '$customer'
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    return sql_rows($sql);
}

function getFriendCount($customer) {
    $sql = "SELECT * FROM Relation WHERE CustomerName = '$customer'";
    sql_query($sql);
    return sql_affected_rows();
}

function addFriend($customer, $donor) {
    $newid = sql_insert("
        INSERT INTO Relation(DonorName, CustomerName, Status) VALUES ('$donor', '$customer', 'Friends');
    ");
    return $newid;
}

function delFriend($customer, $relation) {
    return sql_exec("
        DELETE FROM Relation
        WHERE CustomerName = '$customer' AND RelationId = $relation
    ");
}
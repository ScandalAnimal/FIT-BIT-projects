<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

if(isset($_POST["register-branch"])) {
    $branch = $_POST["register-branch"];
}
else {
    $branch = "test";
}
if(isset($_POST["register-first-name"])) {
    $firstName = $_POST["register-first-name"];
}
else {
    $firstName = "test";
}
if(isset($_POST["register-last-name"])) {
    $lastName = $_POST["register-last-name"];
}
else {
    $lastName = "test";
}
if(isset($_POST["register-age"])) {
    $age = $_POST["register-age"];
}
else {
    $age = "40";
}
if(isset($_POST["register-email"])) {
    $email = $_POST["register-email"];
}
else {
    $email = "example@example.com";
}
if(isset($_POST["register-phone"])) {
    $phone = $_POST["register-phone"];
}
else {
    $phone = "00421111111111";
}
if(isset($_POST["register-username"])) {
    $username = $_POST["register-username"];
}
else {
    $username = "username";
}
if(isset($_POST["register-password"])) {
    $password = $_POST["register-password"];
}
else {
    $password = "password";
}
if(isset($_POST["register-address"])) {
    $address = $_POST["register-address"];
}
else {
    $address = "test";
}
if(isset($_POST["register-type"])) {
    $type = $_POST["register-type"];
}
else {
    $type = "Donor";
}

$query = "INSERT INTO `User`(`Username`,`Password`, `FirstName`, `LastName`, `Age`, `Email`,
                                        `Phone`, `Address`, `Role`)
                            VALUES ('".$username."', '".md5($password)."', '".$firstName."', '".$lastName."', '".$age."', '".
    $email."', '".$phone."', '".$address."', '".$type."')";

$sql = mysql_query($query, $database);

if ($type == 'Customer') {
    $query = "INSERT INTO `Customer`(`CustomerName`,`PreferredBranch`)
                            VALUES ('".$username."', '".$branch."')";

    $sql = mysql_query($query, $database);

}
else {
    $query = "INSERT INTO `Donor`(`DonorName`,`BloodType`)
                            VALUES ('".$username."', 'undefined')";

    $sql = mysql_query($query, $database);
}

$userRole = $_POST["register-type"];

if ($userRole == "Administrator") {
    $_SESSION['role'] = 'admin';
}
else if ($userRole == "Customer") {
    $_SESSION['role'] = 'customer';
}
else if ($userRole == "Donor") {
    $_SESSION['role'] = 'donor';
}
// TODO pridat employee
else {
    $_SESSION['role'] = 'none';
}

$_SESSION['username'] = $username;
header('location: welcome.php');


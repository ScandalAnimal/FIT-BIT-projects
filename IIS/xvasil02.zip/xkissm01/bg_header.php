<?php

header('Content-Type: text/html; charset=utf-8');
session_start();

function sessionvar($key) {
    return (isset($_SESSION[$key]) ? $_SESSION[$key] : null);
}

function postvar($key) {
    return (isset($_POST[$key]) ? $_POST[$key] : null);
}

// Global session username
$session_username = (isset($_SESSION['username']) ? $_SESSION['username'] : null);
// Global session role
$session_role = (isset($_SESSION['role']) ? $_SESSION['role'] : null);

// Include mysql
require_once("bg_database.php");
// Include menu generator
require_once("bg_menu_tabs.php");

require_once("bg_user_manager.php");
require_once("bg_order_manager.php");


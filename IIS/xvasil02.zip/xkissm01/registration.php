<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

mysql_query("set names 'utf8'");
$sql = "SELECT `City` FROM `Branch`";
$result = mysql_query($sql);
$index = 0;
while ($row = mysql_fetch_assoc($result)) {
    $branch[$index] = $row['City'];
    $index++;
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(1); ?>
    </ul>

    <div id="register" class="register">
        <div class="register-title">
            <h1>Registrácia</h1>
        </div>
        <form class="register-form" id="register-form" method="POST" action="bg_register.php" onsubmit="return validateForm()">
            <div class="control-group">
                <label for="register-username">* Prihlasovacie meno</label>
                <input id="register-username" type="text" name="register-username" class="register-field required-text">
                <div id="availability"></div>
            </div>
            <div class="control-group">
                <label for="register-password">* Heslo</label>
                <input id="register-password" type="password" name="register-password" class="register-field required-text">
            </div>
            <div class="control-group">
                <label for="register-password">* Zopakovať heslo</label>
                <input id="register-password-repeat" type="password" name="register-password-repeat" class="register-field required-text">
            </div>
            <p id="validate-status" class="text-danger"></p>
            <div class="control-group">
                <label for="register-first-name">Meno</label>
                <input id="register-first-name" type="text" name="register-first-name" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-last-name">Priezvisko</label>
                <input id="register-last-name" type="text" name="register-last-name" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-age">Vek</label>
                <input id="register-age" type="text" name="register-age" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-email">Email</label>
                <input id="register-email" type="email" name="register-email" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-phone">Telefón</label>
                <input id="register-phone" type="text" name="register-phone" placeholder="00421" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-address">Adresa</label>
                <input id="register-address" type="text" name="register-address" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-type">* Typ užívateľa</label>
                <select id="register-type" name="register-type" class="register-field required-text">
                    <option value="Donor">Darca</option>
                    <option value="Customer">Zákazník</option>
                </select>
            </div>
            <div id="branch" class="control-group hidden">
                <label for="register-branch">* Preferovaná pobočka</label>
                <select id="register-branch" name="register-branch" class="register-field required-text">
                    <?php
                    if (isset($branch)) {
                        foreach ($branch as $value) {
                            echo "<option value='".$value."'>".$value."</option>";
                        }
                    }
                    ?>
<!--                    <option value="Customer">Zákazník</option>-->
                </select>
            </div>
            <div class="control-group">
                <input class="register-submit" type="submit" id="register-submit" value="Registrovať">
            </div>
        </form>
</div>

</body>
</html>

<script>
    $("#register-type").change(function() {
        if ($( "#register-type option:selected" ).val() == "Customer") {
            $("#branch").removeClass("hidden");
        }
        else {
            $("#branch").addClass("hidden");
        }
    });

    $(document).ready(function(){
        $('#register-username').blur(function(){
            var username = $(this).val();
            if (username != "") {
                $.ajax({
                    url:"checkUserName.php",
                    method:"POST",
                    data:{username:username},
                    dataType:"text",
                    success:function(html)
                    {
                        isUsedName = (html == 'true');
                        if (isUsedName) {
                            $('#availability').html("<span class='text-danger'>Prihlasovacie meno je obsadené.</span>");
                        }
                        else {
                            $('#availability').html("<span class='text-success'>Prihlasovacie meno je dostupné.</span>");
                        }
                        validateUserName();
                    }
                });
            }
        });
    });

    $(document).ready(function() {
        $("#register-password-repeat").keyup(validate);
    });


    function validate() {
        var password1 = $("#register-password").val();
        var password2 = $("#register-password-repeat").val();

        if(password1 == password2) {
            $("#validate-status").text("");
        }
        else {
            $("#validate-status").text("Heslá sa nezhodujú.");
        }

    }


</script>
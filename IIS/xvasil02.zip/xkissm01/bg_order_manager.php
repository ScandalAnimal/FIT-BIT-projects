<?php

require_once('bg_database.php');

define('STATUS_PREPARING', 'Preparing');
define('STATUS_PREPARED', 'Prepared');
define('STATUS_COMPLETE', 'Complete');

// Create new order for customer and returns
function createNewOrder($customer, $branch, $dose_count) {
    $newid = sql_insert("
        INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	    VALUES ('$customer', '$branch', NOW(), $dose_count, '".STATUS_PREPARING."')
    ");
    return $newid;
}

function deleteOrder($order_id) {
    sql_exec("
        UPDATE Dose
        SET OrderId = 0
        WHERE OrderId = $order_id
    ");
    return sql_exec("
        DELETE FROM BloodOrder
        WHERE BloodOrderId = $order_id
    ");
}

// Set order with status
function setOrderStatus($order_id, $status) {
    return sql_exec("
        UPDATE BloodOrder
        SET Status = '$status'
        WHERE BloodOrderId = $order_id
    ");
}

// Fill order with friends' doses
function fillOrderWithFirends($customer, $order_id, $count) {
    return $count - sql_exec("
        UPDATE Dose
        SET Dose.OrderId = $order_id
        WHERE Dose.OrderId = 0 AND Dose.DonorName IN (
            SELECT Relation.DonorName
            FROM User INNER JOIN Relation ON User.Username = Relation.CustomerName
            WHERE User.Username = '$customer'
        )
        ORDER BY RAND()  
        LIMIT $count
    ");
}

// Fill order with others' doses
function fillOrder($order_id, $count) {
    return $count - sql_exec("
        UPDATE Dose
        SET Dose.OrderId = $order_id
        WHERE Dose.OrderId = 0
        ORDER BY RAND()  
        LIMIT $count
    ");
}

// Create, fill and return new order
function createAndFillOrder($customer, $branch, $dose_count) {
    $order_id = createNewOrder($customer, $branch, $dose_count);
    fillAndCheckOrder($customer, $order_id, $dose_count);
    return $order_id;
}

// Fill and check order
function fillAndCheckOrder($customer, $order_id, $dose_count) {
    $remains = fillOrderWithFirends($customer, $order_id, $dose_count);
    fillOrder($order_id, $remains);
    checkOrder($order_id);
    return $remains;
}

// Check order
function checkOrder($order_id) {
    $result = sql_query("
        SELECT DoseCount
        FROM BloodOrder
        WHERE BloodOrderId = $order_id
    ");
    if ($result) {
        $row = $result->fetch_assoc();
        $count = $row['DoseCount'];
        sql_query("
            SELECT DoseId
            FROM Dose
            WHERE OrderId = $order_id            
        ");
        $rows = sql_affected_rows();
        if ($count == $rows) {
            setOrderStatus($order_id, STATUS_PREPARED);
        } else {
            setOrderStatus($order_id, STATUS_PREPARING);
        }
    }
}

function ordersFill() {
    $result = sql_query("
        SELECT BloodOrderId, DoseCount, CustomerName, COUNT(Dose.OrderId) AS fill_count
        FROM BloodOrder LEFT JOIN Dose ON Dose.OrderId = BloodOrder.BloodOrderId
        GROUP BY BloodOrderId, DoseCount, CustomerName
    ");
    if ($result) {
        while ($row = $result->fetch_assoc()) {
            $id = $row['BloodOrderId'];
            $doseCount = $row['DoseCount'];
            $customer = $row['CustomerName'];
            $fill_count = $row['fill_count'];
            fillAndCheckOrder($customer, $id, $doseCount - $fill_count);
        }
    }
}

function getAllOrders($pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('BloodOrder.BloodOrderId', 'BloodOrder.CustomerName', 'User.FirstName', 'User.LastName', 'BloodOrder.Branch', 'BloodOrder.DoseCount', 'fill_count', 'BloodOrder.CreationDate', 'BloodOrder.Status');

    //$columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT BloodOrder.BloodOrderId, BloodOrder.CustomerName, User.FirstName, User.LastName, BloodOrder.Branch, BloodOrder.DoseCount, COUNT(Dose.OrderId) AS fill_count, BloodOrder.CreationDate, BloodOrder.Status
        FROM BloodOrder LEFT JOIN User ON BloodOrder.CustomerName = User.Username
        LEFT JOIN Dose ON Dose.OrderId = BloodOrder.BloodOrderId
        GROUP BY BloodOrder.BloodOrderId
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    $result = sql_query($sql);
    echo sharedDatabase()->error;
    $rows = array();
    if ($result) {
        while($row = $result->fetch_array(MYSQLI_NUM)) {
            array_push($rows, $row);
        }
    }
    return $rows;
}

function getAllOrderCount() {
    $sql = "SELECT * FROM BloodOrder";
    sql_query($sql);
    return sql_affected_rows();
}

function getAllPreparedOrders($pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('BloodOrder.BloodOrderId', 'BloodOrder.CustomerName', 'User.FirstName', 'User.LastName', 'BloodOrder.Branch', 'BloodOrder.DoseCount', 'fill_count', 'BloodOrder.CreationDate', 'BloodOrder.Status');

    $columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT BloodOrder.BloodOrderId, BloodOrder.CustomerName, User.FirstName, User.LastName, BloodOrder.Branch, BloodOrder.DoseCount, COUNT(Dose.OrderId) AS fill_count, BloodOrder.CreationDate, BloodOrder.Status
        FROM BloodOrder LEFT JOIN User ON BloodOrder.CustomerName = User.Username
        LEFT JOIN Dose ON Dose.OrderId = BloodOrder.BloodOrderId
        WHERE Status = '".STATUS_PREPARED."'
        GROUP BY BloodOrder.BloodOrderId
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    echo sql_err();
    return sql_rows($sql);
}

function getAllPreparedOrderCount() {
    $sql = "SELECT * FROM BloodOrder WHERE Status = '".STATUS_PREPARED."'";
    sql_query($sql);
    return sql_affected_rows();
}

function getCustomerOrders($customer, $page_index, $per_page, $order_index, $desc) {

    $columns = array('BloodOrder.BloodOrderId', 'BloodOrder.Branch', 'BloodOrder.DoseCount', 'BloodOrder.CreationDate', 'BloodOrder.Status');

    $column_string = implode(', ', $columns);
    $row_index = $page_index * $per_page;
    $desc_string = (!is_null($desc) && $desc == 'true' ? "DESC" : "ASC");
    $order_string = (!is_null($order_index) && $order_index != '' ? "ORDER BY ".$columns[$order_index]." $desc_string" : "");
    $sql = "
        SELECT $column_string
        FROM BloodOrder
        WHERE CustomerName = '$customer'
        $order_string
        LIMIT $per_page
        OFFSET $row_index
    ";
    $result = sql_query($sql);
    $rows = array();
    if ($result) {
        while($row = $result->fetch_array(MYSQLI_NUM)) {
            array_push($rows, $row);
        }
    }
    return $rows;
}

function getCustomerOrderCount($customer) {
    if (is_null($customer)) return null;

    $sql = "
        SELECT *
        FROM BloodOrder
        WHERE CustomerName = '$customer'
    ";
    sql_query($sql);
    return sql_affected_rows();
}

function deleteCustomerOrder($customer, $order_id) {
    if (is_null($customer)) return null;
    $success = sql_exec("
        DELETE FROM BloodOrder
        WHERE BloodOrderId = $order_id AND CustomerName = '$customer'
    ");
    if ($success) {
        sql_exec("
            UPDATE Dose
            SET OrderId = 0
            WHERE OrderId = $order_id
        ");
    }
    return $success;
}
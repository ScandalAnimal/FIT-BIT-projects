<?php

require_once('bg_header.php');
require_once('bg_order_manager.php');
require_once('bg_user_manager.php');
require_once('bg_dose_manager.php');
require_once('bg_donation_manager.php');
require_once('bg_friend_manager.php');

// TODO: Session security

$session_username = sessionvar('username');
$session_role = sessionvar('role');

function getRequestData($request, $username, $role) {
    $pageIndex = postvar('page_index');
    $rowsPerPage = postvar('rows_per_page');
    $orderColumnIndex = postvar('order_column_index');
    $orderDesc = postvar('order_desc');
    switch ($role) {
        case 'administrator': {
            switch ($request) {
                case 'get_users': {
                    // Return all users
                    return getAllUsers($pageIndex, $orderColumnIndex, $orderDesc, $rowsPerPage);
                } break;
                case 'get_user_count': {
                    // Return user count
                    return getAllUserCount();
                } break;
                case 'add_user': {
                    // Add new user, return success
                    // TODO: Add user
                    //return addUser();
                } break;
                case 'del_user': {
                    // Remove user, return success
                    return delUser(postvar('username'));
                } break;
                case 'sug_customer': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_CUSTOMER);
                } break;
                case 'sug_donor': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_DONOR);
                } break;
                case 'sug_branch': {
                    // Returns array of hints
                    return getBranchSuggestion(postvar('hint'), postvar('hint_count'));
                } break;
            }
        } break;
        case 'employee': {
            switch ($request) {
                case 'get_doses': {
                    // Return all doses
                    // TODO: set branch for employee?
                    return getAllDoses(null, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_dose_count': {
                    // Return dose count
                    // TODO: set branch for employee?
                    return getAllDoseCount(null);
                } break;
                case 'add_dose': {
                    // Add new dose
                    return createDose(postvar('branch'), postvar('donor'));
                } break;
                case 'del_dose': {
                    // Remove dose
                    return deleteDose(postvar('dose'));
                } break;
                case 'get_donations': {
                    // Return all doses
                    // TODO: set branch for employee?
                    return getAllDonations(null, null, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_donation_count': {
                    // Return dose count
                    // TODO: set branch for employee?
                    return getAllDonationCount(null, null);
                } break;
                case 'add_donation': {
                    // Add new dose
                    return addDonation(postvar('donor'), postvar('branch'), postvar('donationDate'));
                } break;
                case 'del_donation': {
                    // Remove dose
                    return delDonation(postvar('dose'));
                } break;
                case 'get_orders': {
                    // Return all orders
                    return getAllOrders($pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_order_count': {
                    // Return order count
                    return getAllOrderCount();
                } break;
                case 'get_ready_orders': {
                    // Return all prepared orders
                    return getAllPreparedOrders($pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_ready_order_count': {
                    return getAllPreparedOrderCount();
                } break;
                case 'set_complete_order': {
                    // Set order as complete
                    return setOrderStatus(postvar('order'), 'Complete');
                } break;
                case 'add_order': {
                    // Add new order
                    return createAndFillOrder(postvar('customer'), postvar('branch'), postvar('dose_count'));
                } break;
                case 'del_order': {
                    // Remove order
                    return deleteOrder(postvar('order'));
                } break;
                case 'sug_customer': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_CUSTOMER);
                } break;
                case 'sug_donor': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_DONOR);
                } break;
                case 'sug_branch': {
                    // Returns array of hints
                    return getBranchSuggestion(postvar('hint'), postvar('hint_count'));
                } break;
            }
        } break;
        case 'customer': {
            switch ($request) {
                case 'get_friends': {
                    // Return all donors for customer
                    return getFriends($username, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_friend_count': {
                    // Return donor count
                    return getFriendCount($username);
                } break;
                case 'add_friend': {
                    // Add donor
                    return addFriend($username, postvar('donor'));
                } break;
                case 'del_friend': {
                    // Remove donor
                    return delFriend($username, postvar('relation'));
                } break;
                case 'get_orders': {
                    // Return all customer orders
                    return getCustomerOrders($username, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_order_count': {
                    return getCustomerOrderCount($username);
                } break;
                case 'add_order': {
                    // Add new order
                    return createAndFillOrder($username, postvar('branch'), postvar('dose_count'));
                } break;
                case 'del_order': {
                    // Del order
                    return deleteCustomerOrder($username, postvar('order'));
                } break;
                case 'sug_donor': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_DONOR);
                } break;
                case 'sug_branch': {
                    // Returns array of hints
                    return getBranchSuggestion(postvar('hint'), postvar('hint_count'));
                } break;
            }
        } break;
        case 'donor': {
            switch ($request) {
                case 'get_doses': {
                    // Return all doses
                    return getDonorDoses($username, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_dose_count': {
                    // Return dose count
                    return getDonorDoseCount($username);
                } break;
                case 'get_donations': {
                    // Return all doses
                    return getAllDonations($username, null, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc);
                } break;
                case 'get_donation_count': {
                    // Return dose count
                    return getAllDonationCount($username, null);
                } break;
                case 'add_donation': {
                    addDonation($username, postvar('branch'), postvar('date'));
                } break;
                case 'del_donation': {
                    delDonation(postvar('donation'));
                } break;
                case 'get_friends': {
                    // Return friends
                } break;
                case 'get_friend_count': {
                    // Return friend count
                } break;
                /*
                case 'add_friend': {
                    // Add donor
                } break;
                case 'del_friend': {
                    // Remove donor
                } break;
                */
                /*
                case 'sug_customer': {
                    // Returns array of hints
                    return getUsernameSuggestions(postvar('hint'), postvar('hint_count'), ROLE_CUSTOMER);
                } break;
                */
                case 'sug_branch': {
                    // Returns array of hints
                    return getBranchSuggestion(postvar('hint'), postvar('hint_count'));
                } break;
            }
        } break;
        default: {
            // Unknown role or null
        } break;
    }
    return null;
}

if ($request = postvar('request')) {
    $arrays = getRequestData($request, $session_username, $session_role);
    if ($arrays) {
        echo json_encode($arrays);
    } else {
        // Arrays are null
    }
} else {
    // Invalid request
}

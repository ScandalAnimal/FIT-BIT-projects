<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete si zmazať daného darcu?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(1); ?>
    </ul>
    <hr>


    <div style="margin: auto; display: table">
        <h3>Pridať nového priateľa</h3>
        <div class="control-group">
            <div id="suggestionContainer"></div>
        </div>
        <div class="control-group">
            <input class="fdonor-submit" type="submit" value="Registrovať" onclick="addFriend()">
        </div>
    </div>
    <h3>Priatelia</h3>
    <div id="table-container"></div>

</div>
</body>
</html>

<script>

    function addFriend() {
        addFriend_Customer($("#fdonor").val(), function (data) {
            if (data) {
                document.gtable.refresh();
            } else {
                alert("Nieje možné pridať darcu");
            }
        })
    }

    $(function() {
        new GSearch($('#suggestionContainer'), suggestDonor, 'fdonor', 'Donor', []);
    });

    $(function () {
        var customerName = '<?php echo $_SESSION['username'] ?>';

        var container = $('#table-container');
        var columns = ['ID', 'Donor', 'Meno', 'Priezvisko', 'Vek', 'Email', 'Tel. číslo', 'Adresa', 'Stav'];
        var rowsPerPage = 15;
        var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getFriendCount_Customer, getFriend_Customer);
        gtable.rowAction('Akcia', 'Odstrániť', function (row) {
            if (confirm('Naozaj si prajete si zmazať prietela?')) {
                var relationID = row[0];
                delFriend_Customer(relationID, null);
                gtable.refresh();
            }
        });
        gtable.hiddenColumnIndices = [0];
        gtable.showIndexColumn = true;
        //gtable.conditionalFormatingFunc = orderFormattingFunc;
        gtable.noItemsMessage = 'Nemáte žiadnych priateľov';
        document.gtable = gtable;

        gtable.refresh();
    });

</script>
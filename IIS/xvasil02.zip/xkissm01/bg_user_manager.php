<?php

// Include shared header file
require_once("bg_header.php");

define('ROLE_ADMIN', 'Administrator');
define('ROLE_EMPLOYEE', 'Employee');
define('ROLE_CUSTOMER', 'Customer');
define('ROLE_DONOR', 'Donor');

function getAllUsers($pageIndex, $orderColumnIndex, $orderDesc, $rowsPerPage) {

    $tableColumns = array('Username', 'Password', 'FirstName', 'LastName', 'Age', 'Email', 'Phone', 'Address', 'Role');

    $columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT $columnsString
        FROM User
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    $result = sql_query($sql);
    $rows = array();
    if ($result) {
        while($row = $result->fetch_array(MYSQLI_NUM)) {
            array_push($rows, $row);
        }
    }
    return $rows;
}

function getAllUserCount() {
    $sql = "SELECT * FROM User";
    sql_query($sql);
    return sql_affected_rows();
}

function addUser() {
    // TODO: Add user
}

function delUser($username) {
    return sql_exec("
        DELETE FROM User
        WHERE Username = '$username'
    ");
}

// Returns boolean if username exists
function isUserExist($username, $role = null) {
    $db = sharedDatabase();
    if (is_null($role)) {
        $sql = "SELECT * FROM User WHERE Username LIKE '".$username."'";
    } else {
        $sql = "SELECT * FROM User WHERE Username LIKE '".$username."' AND Role = '" . $role . "'";
    }
    if (!$result = $db->query($sql)) {
        die("Couldn't get result [" . $db->error . "]");
    }
    return ($db->affected_rows > 0);
}

// Suggest max number of usernames from incomplete search
function getUsernameSuggestions($hint, $hint_count, $role) {
    $roleString = (!is_null($role) ? " AND Role = '$role'" : '');
    $sql = "
        SELECT Username
        FROM User
        WHERE Username LIKE '%" . $hint . "%' $roleString
        ORDER BY
        CASE
            WHEN Username LIKE '" . $hint . "%' THEN 1
            WHEN Username LIKE '%" . $hint . "' THEN 3
            ELSE 2
        END
        LIMIT $hint_count
    ";
    return sql_rows($sql);
}

// Suggest max number of usernames from incomplete search
function getBranchSuggestion($hint, $hint_count) {
    $sql = "
        SELECT City
        FROM Branch
        WHERE City LIKE '%" . $hint . "%'
        ORDER BY
        CASE
            WHEN City LIKE '" . $hint . "%' THEN 1
            WHEN City LIKE '%" . $hint . "' THEN 3
            ELSE 2
        END
        LIMIT $hint_count
    ";
    return sql_rows($sql);
}

// Returns user type
function getUserType($username) {
    $db = sharedDatabase();
    $sql = "SELECT * FROM User WHERE Username = '".$username."'";
    if (!$result = $db->query($sql)) {
        die("Couldn't get result [" . $db->error . "]");
    }
    if ($db->affected_rows > 0) {
        if ($row = $result->fetch_assoc()) {
            return $row['Role'];
        }
    }
    return null;
}

if (isset($_POST['request_type'])) {
    $request_type = $_POST['request_type'];
    switch ($request_type) {
        case 'suggest_user': {
            $hint = ($_POST['hint'] ? $_POST['hint'] : null);
            $hint_count = ($_POST['hint_count'] ? $_POST['hint_count'] : 1);
            $role = ($_POST['role'] ? $_POST['role'] : null);
            echo json_encode(getUsernameSuggestions($_POST['hint'], $_POST['hint_count'], $_POST['role']));
        } break;
        case 'user_exist': {
            echo json_encode(isUserExist($_POST['username'], $_POST['role']));
        } break;
        case 'user_type': {
            echo json_encode(userType($_POST['username']));
        } break;
    }
} else {

}
<?php

// Include shared header file
include("bg_header.php");

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

    <div>
        <b style="color: #660000">
            <h3>File "<?php echo "sql/iis.sql" ?>"</h3>
        </b>
        <hr>
        <?php
        if ($file = file_get_contents("sql/iis.sql")) {
            sql_multi_query($file);

            if ($err = sql_err()) {
                echo nl2br($err);
            } else {
                echo 'OK';
            }
        }
        ?>
        <hr>
    </div>

    <div align="center">
        <input type="button" value="Continue" onclick="window.location = '<?php echo "index.php"; ?>'">
    </div>
<body>
</html>

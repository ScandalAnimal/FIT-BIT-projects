<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

if(!isset($_SESSION['username'])) {
    header('location: index.php');
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete si zmazať danú rezerváciu?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(2); ?>
    </ul>


    <div class='container-full'>

        <hr>
        <div style="margin: auto; display: table">
            <h3>Vytvoriť novú objednávku</h3>
            <input id="doseCountID" class="form-component" type="text" placeholder="Počet dávok" />
            <br>
            <div id="suggestionContainer" class="form-component"></div>
            <br>
            <input id="newOrderButtonID" class="form-component createOrder" type="button" value="Objednať" onclick="submitCreateOrder()"/>
            <br>
        </div>

        <hr>
        <h3>Objednávky</h3>
        <div id="table-container"></div>

        <script type="text/javascript">

            function submitCreateOrder() {
                var doseCount = $('#doseCountID').val();
                var branch = $('#branchID').val();
                addOrder_Customer(branch, doseCount, function (data) {
                    if (data) {
                        $('#doseCountID').val('');
                        $('#branchID').val('');
                        document.gtable.refresh();
                    }
                });
            }

            $(function () {
                var customerName = '<?php echo $_SESSION['username'] ?>';

                var container = $('#table-container');
                var columns = ['ID', 'Pobočka', 'Počet dávok', 'Dátum', 'Stav'];
                var rowsPerPage = 10;
                var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getOrderCount_Customer, getOrders_Customer);
                gtable.rowAction('Akcia', 'Odstrániť', function (row) {
                    if (confirm('Naozaj si prajete si zmazať objednávku?')) {
                        var orderId = row[0];
                        delOrder_Customer(orderId, null);
                        gtable.refresh();
                    }
                });
                gtable.actionEnableFunc = orderActionEnableFuncCustomer;
                gtable.hiddenColumnIndices = [0];
                gtable.showIndexColumn = true;
                gtable.conditionalFormatingFunc = orderFormattingFunc;
                gtable.noItemsMessage = "Nemáte žiadne objednávky";
                document.gtable = gtable;

                gtable.refresh();
            });

        </script>
    </div>
</body>
</html>

<script>

    //$('a[href*="doseManagement.php"]').addClass("menu-active");

    $(function() {
        new GSearch($('#suggestionContainer'), suggestBranch, 'branchID', 'Pobočka', []);
    });

    function showDialog(param) {
        var confirmDialog = document.getElementById('confirm-dialog');
        confirmDialog.style.display = "block";

        var confirmOk = document.getElementById('confirm-ok');
        var confirmCancel = document.getElementById('confirm-cancel');

        confirmCancel.onclick = function() {
            confirmDialog.style.display = "none";
        };

        confirmOk.onclick = function() {
            window.location.href = "removeBloodOrder.php?id=" + param;
        };

        window.onclick = function(event) {
            if (event.target == confirmDialog) {
                confirmDialog.style.display = "none";
            }
        }
    }
</script>


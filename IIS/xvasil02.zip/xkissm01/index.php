<?php

// Include shared header file
include("bg_header.php");

// Redirect to home page if user is logged in
if (!is_null($session_username) && !is_null($session_role)) {
    header('location: home.php');
}

?>

<!DOCTYPE html>
<html>
    <head>
        <!-- Include global header -->
        <?php include_once('bg_meta_header.php'); ?>
        <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
    </head>
    <body>
        <div class="container box">

			<div class="splash-image">
				<img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
			</div>

            <ul class="menu">
                <?php generateMenuList(0); ?>
            </ul>

            <h2 class="text-center">Vitajte na stránke našej krvnej banky.</h2>

            <div id="login" class="login">
                <div class="login-title">
                    <h1>Prihlásenie</h1>
                </div>
                <form id="login-form" class="login-form" method="POST" action="bg_login.php">
                    <div class="control-group">

                        <label for="login-username"></label>
                        <input id="login-username" type="text" name="username" placeholder="Prihlasovacie meno" size="40" class="login-field required-text">
                    </div>
                    <div class="control-group">
                        <label for="login-password"></label>
                        <input id="login-password" type="password" name="pass" placeholder="Heslo" size="40" class="login-field required-text">
                    </div>
                    <div class="control-group">
                        <label for="submit"></label>
                        <input class="login-submit" type="submit" id="submit" value="Prihlásiť sa">

                        <div id="login-validation">
                            <?php
                            if (isset($_GET['invalidLogin'])) {
                                echo "<span class='text-danger'>Prihlasovacie meno alebo heslo je nesprávne</span>";
                            }
                            ?>
                        </div>
                    </div>
                </form>

            </div>

            <p class="text-center">Ak ešte nie ste našim klientom, prosím <a href="registration.php">zaregistrujte sa</a></p>
        </div>
    </body>
</html>

<script>
    $('#db-reset').click(function() {

        window.location.href = "bg_resetdb.php";

    });
</script>
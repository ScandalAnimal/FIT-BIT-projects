<?php

// Include shared header file
include("bg_header.php");

$sql = "SELECT * FROM `User` WHERE Username = '".$_GET['id']."'";
$database = connectToDatabase();

$result = mysql_query($sql,$database);

if (mysql_num_rows($result) == 1) {
    while ($row = mysql_fetch_array($result)) {
        $username = $row['Username'];
        $password = $row['Password'];
        $firstname = $row['FirstName'];
        $lastname = $row['LastName'];
        $age = $row['Age'];
        $email = $row['Email'];
        $phone = $row['Phone'];
        $address = $row['Address'];
        $role = $row['Role'];
        $username = trim($username);
        $password = trim($password);
        $firstname = trim($firstname);
        $lastname = trim($lastname);
        $age = trim($age);
        $email = trim($email);
        $phone = trim($phone);
        $address = trim($address);
    }
}
else {
    echo "Error in database - no user found.";
}

if (is_null($session_username)) {
    header('location: index.php');
    die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Prajete si uložiť zmeny?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>
<div id="delete-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete zmazať svoje konto?</p>
        <button id="delete-ok">Áno</button>
        <button id="delete-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(-2); ?>
    </ul>

<div id="wrapper">
    <div id="content">
        <h1>Osobné informácie</h1>

        <section id="settings">
            <form id="profile-form" method="post" action="bg_profile_update.php?form=profile">

                <p class="setting">
                    <span id="profile-username" class="profile-field required-text">Prihlasovacie meno</span>
                    <?php
                        if (isset($username)) {
                            echo $username;
                        }
                    ?>
                    <input id="profile-username"<?php
                    if (isset($username)) {
                        echo 'value="'.$username.'"';} ?> type="hidden" name="profile-username">

                </p>
                <div class="setting">
                    <label for="profile-password">Heslo</label>
                    <input id="profile-password"<?php
                    if (isset($password)) {
                        echo 'value="'.$password.'"';} ?> type="text" name="profile-password" class="profile-field required-text">
                </div>
                <div class="setting">
                    <label for="profile-first-name">Meno</label>
                    <input id="profile-first-name" <?php
                    if (isset($firstname)) {
                        echo 'value="'.$firstname.'"';} ?> type="text" name="profile-first-name" class="profile-field">
                </div>
                <div class="setting">
                    <label for="profile-last-name">Priezvisko</label>
                    <input id="profile-last-name" <?php
                    if (isset($lastname)) {
                        echo 'value="'.$lastname.'"';} ?> type="text" name="profile-last-name" class="profile-field">
                </div>
                <div class="setting">
                    <label for="profile-age">Vek</label>
                    <input id="profile-age" <?php
                    if (isset($age)) {
                        echo 'value="'.$age.'"';} ?> type="text" name="profile-age" class="profile-field">
                </div>
                <div class="setting">
                    <label for="profile-email">Email</label>
                    <input id="profile-email" <?php
                    if (isset($email)) {
                        echo 'value="'.$email.'"';} ?> type="text" name="profile-email" class="profile-field">
                </div>
                <div class="setting">
                    <label for="profile-phone">Telefón</label>
                    <input id="profile-phone" <?php
                    if (isset($phone)) {
                        echo 'value="'.$phone.'"';} ?> type="text" name="profile-phone" placeholder="00421" class="profile-field">
                </div>
                <div class="setting">
                    <label for="profile-address">Adresa</label>
                    <input id="profile-address" <?php
                    if (isset($address)) {
                        echo 'value="'.$address.'"';} ?> type="text" name="profile-address" class="profile-field">
                </div>
                <p class="setting">
                    <span id="profile-type" class="profile-field required-text">Typ užívateľa</span>
                    <?php
                    if (isset($role)) {
                        if ($role == "Donor") {
                            echo "darca";
                        }
                        else if ($role == "Customer") {
                            echo "upír";
                        }
                        else if ($role == "Administrator") {
                            echo "admin";
                        }
                        else {
                            echo "zamestnanec";
                        }
                    }
                    ?>
                </p>
                <div class="control-group">
                    <label for="profile-submit"></label>
                    <input readonly class="profile-submit" id="profile-submit" onclick="return validateProfileForm()" value="Potvrdiť zmeny">
                </div>

            </form>
        </section>
        <hr>
        <h1>Zmazanie konta</h1>
        <label for="account-delete"></label>
        <button class="account-delete" id="account-delete" onclick="return deleteAccount('<?php
            echo $_SESSION['username'];
        ?>')">Zmazať</button>
    </div>
</div>
</body>
</html>

<script type="text/javascript">

    function showDialog() {

        var confirmDialog = document.getElementById('confirm-dialog');
        confirmDialog.style.display = "block";

        var confirmOk = document.getElementById('confirm-ok');
        var confirmCancel = document.getElementById('confirm-cancel');

        confirmCancel.onclick = function() {
            confirmDialog.style.display = "none";
        };

        confirmOk.onclick = function() {
            $("#profile-form").submit();
        };

        window.onclick = function(event) {
            if (event.target == confirmDialog) {
                confirmDialog.style.display = "none";
            }
        }
    }

    function deleteAccount(param) {
        var deleteDialog = document.getElementById('delete-dialog');
        deleteDialog.style.display = "block";

        var deleteOk = document.getElementById('delete-ok');
        var deleteCancel = document.getElementById('delete-cancel');

        deleteCancel.onclick = function() {
            deleteDialog.style.display = "none";
        };

        deleteOk.onclick = function() {
            window.location.href = "removeUser.php?id[]=" + param;
        };

        window.onclick = function(event) {
            if (event.target == deleteDialog) {
                deleteDialog.style.display = "none";
            }
        }
    }

    $('a[href*="updateProfile"]').addClass("menu-active");

</script>
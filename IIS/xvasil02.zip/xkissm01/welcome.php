<?php

// Include shared header file
include("bg_header.php");

//$_SESSION['role'] = $_GET['role'];

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <h1 class="text-center">Upíria krvná banka</h1>
    <ul class="menu">
        <li class="menu-li">
            <a class="menu-active" href="#">Domov</a>
        </li>
        <li class="menu-li">
            <a href="#">Registrácia</a>
        </li>
        <li class="menu-li">
            <a href="#">Contact</a>
        </li>
        <li class="menu-li">
            <a href="#">About</a>
        </li>
    </ul>

    <h2 class="text-center">Boli ste úspešne registrovaný.</h2>
    <form method="post" action="home.php">
        <input type="submit" class="register-submit" value="Vstup do systému">
    </form>

</div>
</body>
</html>
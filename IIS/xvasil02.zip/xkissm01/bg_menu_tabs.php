<?php

$_menuTabIndex = 0;
function createTab($name, $href) {
    $tabIndex = $GLOBALS["_menuTabIndex"];
    $onclick = "onclick='return selectTab($tabIndex)'";
    echo "<li class='menu-li'><a $onclick href='$href'>$name</a></li>";
    $GLOBALS['_menuTabIndex'] = $tabIndex + 1;
}

function generateMenuList($selectedIndex) {
    $role = (isset($_SESSION['role']) ? $_SESSION['role'] : null);
    $username = (isset($_SESSION['username']) ? $_SESSION['username'] : null);
    if (isset($role)) {
        createTab("Domov", "home.php");
        switch ($role) {
            case "admin": {
                createTab("Užívatelia", "admin_users.php");
            } break;
            case "employee": {
                createTab("Darovania", "emp_donations.php");
                createTab("Dávky", "emp_doses.php");
                createTab("Objednávky", "emp_orders.php");
                createTab("Profil", "profile.php?id=$username");
            } break;
            case "customer": {
                createTab("Darcovia", "cust_donors.php");
                createTab("Objednávky", "cust_orders.php");
                createTab("Profil", "profile.php?id=$username");
            } break;
            case "donor": {
                createTab("Darovania", "donor_donations.php");
                createTab("Darované dávky", "donor_doses.php");
                createTab("Profil", "profile.php?id=$username");
            } break;
        }
        createTab("Odhlásenie", "bg_logout.php");
    } else {
        createTab("Domov", "index.php");
        createTab("Registrácia", "registration.php");
        createTab("O nás", "about.php");
    }
    $tabIndex = ($selectedIndex < 0 ? $GLOBALS['_menuTabIndex'] + $selectedIndex : $selectedIndex);
    echo "
    <script type='text/javascript'>
        function selectTab(index) {
            var list = $(\".menu-li a\");
                // Remove class from all hrefs
                list.each(function () {
                $(this).removeClass(\"menu-active\");
            });
            // Set active menu item
            if (index >= 0 && index < list.length) {
                $(list[index]).addClass(\"menu-active\");
            }
            return true;
        }
        selectTab($tabIndex);
    </script>
    ";
}

?>

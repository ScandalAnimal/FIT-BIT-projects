<?php

// Include shared header file
include("bg_header.php");

if (is_null($session_username)) {
    header('location: index.php');
    die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">

        <?php
        // Generate menu list for specific role and username
        // Last argument is selected index of tab
        generateMenuList(3);
        ?>

    </ul>

    <div class='container-full'>

        <hr>
        <div style="margin: auto; display: table">
            <div id="suggestionContainerCustomer" class="form-component"></div>
            <div id="suggestionContainerBranch" class="form-component"></div>
            <input id="newOrderDoseCount" class="form-component" type="text" placeholder="Počet dávok"/>
            <br>
            <p style="padding-top: 20px"></p>
            <input class="form-component" type="submit" value="Pridať odbjednávku" style="background-color: #990000; color: #ffffff;" onclick="addNewOrder()">
        </div>

        <hr>

        <h3>Objednávky na prípravu</h3>
        <div id="table-content-orders-prepared"></div>

        <h3>Všetky Objednávky</h3>
        <div id="table-content-orders"></div>

        <script type="text/javascript">

            function addNewOrder() {
                var customer = $('#newOrderCustomer').val();
                var branch = $('#newOrderBranch').val();
                var doseCount = $('#newOrderDoseCount').val();

                addOrder_Employee(customer, branch, doseCount, function(data) {
                    if (data) {
                        $('#newOrderCustomer').val('');
                        $('#newOrderBranch').val('');
                        $('#newOrderDoseCount').val('');
                        document.allOrders.refresh();
                        document.preparedOrders.refresh();
                    } else {
                        alert("Zadali ste zlé údaje!");
                    }
                });
            }

            $(function () {

                var container = $('#table-content-orders-prepared');
                var columns = ['ID', 'Login', 'Meno', 'Priezvisko', 'Pobočka', 'Počet dávok', 'Počet položiek', 'Dátum', 'Stav'];
                var rowsPerPage = 15;
                var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getPreparedOrderCount_Employee, getPreparedOrders_Employee);
                gtable.rowAction('Akcia', 'Pripraviť', function (row) {
                    var orderId = row[0];
                    setOrderComplete_Employee(orderId, null);
                    document.preparedOrders.refresh();
                    document.allOrders.refresh();
                });
                gtable.hiddenColumnIndices = [0];
                gtable.showIndexColumn = true;
                gtable.conditionalFormatingFunc = orderFormattingFunc;
                gtable.noItemsMessage = "Nie sú žiadne objednávky na zobrazenie";
                document.preparedOrders = gtable;

                gtable.refresh();
            });

            $(function () {

                var container = $('#table-content-orders');
                var columns = ['ID', 'Login', 'Meno', 'Priezvisko', 'Pobočka', 'Počet dávok', 'Počet položiek', 'Dátum', 'Stav'];
                var rowsPerPage = 15;
                var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getOrderCount_Employee, getOrders_Employee);
                gtable.rowAction('Akcia', 'Odstrániť', function (row) {
                    if (confirm('Naozaj si prajete si zmazať objednávku?')) {
                        var orderId = row[0];
                        delOrder_Customer(orderId, null);
                        document.preparedOrders.refresh();
                        document.allOrders.refresh();
                    }
                });
                gtable.actionEnableFunc = orderActionEnableFunc;
                gtable.hiddenColumnIndices = [0];
                gtable.showIndexColumn = true;
                gtable.conditionalFormatingFunc = orderFormattingFunc;
                gtable.noItemsMessage = "Nie sú žiadne objednávky na zobrazenie";
                document.allOrders = gtable;

                gtable.refresh();
            });

            $(function() {
                new GSearch($('#suggestionContainerCustomer'), suggestCustomer, 'newOrderCustomer', 'Zákazník', []);
            });

            $(function() {
                new GSearch($('#suggestionContainerBranch'), suggestBranch, 'newOrderBranch', 'Pobočka', []);
            });

        </script>

    </div>
</div>
</body>
</html>

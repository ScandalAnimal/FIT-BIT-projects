<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

if(!isset($_SESSION['username'])) {
    header('location: index.php');
    exit();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete si zmazať daného užívateľa?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>

<div id="mult-confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete si zmazať označených užívateľov?</p>
        <button id="mult-confirm-ok">Áno</button>
        <button id="mult-confirm-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(1); ?>
    </ul>

    <form id="user-mgmt-form" method="post">
        <?php
        mysql_query("set names 'utf8'");
        $sql = "SELECT * FROM `User`";
        $result = mysql_query($sql);
        echo "<div class='container-full'>";
        echo "<h3>Správa užívateľov</h3>";
        echo "<table class='table table-striped table-hover'>";
        $index = 0;
        echo "<thead class='thead-default'><td></td><td>Prihlasovacie meno</td><td>Meno</td><td>Priezvisko</td><td>Vek</td><td>Email</td><td>Telefonický kontakt</td>
                <td>Heslo</td><td>Adresa</td><td>Rola</td><td>Operácia</td><td></td></thead>";
        while ($row = mysql_fetch_assoc($result)) {
            if ($row['Username'] != "unknown") {
                $user[$index] = $row['Username'];
                echo "<tr><td>";
                if ($row['Username'] != $_SESSION['username']) {
                    echo "<input class='user-mgmt-chbx' type='checkbox' id='user-mgmt-chbx" . $index . "' value='" . $row['Username'] . "'>";
                }
                echo "</td><td>" . $row['Username'] . "</td><td>" . $row['FirstName'] . "</td><td>" . $row['LastName'] . "</td><td>" .
                    $row['Age'] . "</td><td>" . $row['Email'] . "</td><td>" . $row['Phone'] . "</td><td>" .
                    $row['Password'] . "</td><td>" . $row['Address'] . "</td><td>" .
                    $row['Role'] . "</td>
                    <td>";

                if ($row['Username'] != $_SESSION['username']) {
                    echo "<button type='button' class='delete-link' onclick=showDialog('$user[$index]')>odstrániť</button>";
                }
                echo "</td><td><button type='button' class='update-link' onclick=redirectToUpdate('$user[$index]')>upraviť</button>";
                echo "</td></tr>";
                $index++;
            }
        }

        echo "</table>";
        ?>

        <input id="user-mgmt-submit" class="user-mgmt-submit" onclick="deleteMultipleUsers()"
               value="Zmazať označených užívateľov">
    </form>
</div>
</body>
</html>

<script>
    function showDialog(param) {
        var confirmDialog = document.getElementById('confirm-dialog');
        confirmDialog.style.display = "block";

        var confirmOk = document.getElementById('confirm-ok');
        var confirmCancel = document.getElementById('confirm-cancel');

        confirmCancel.onclick = function() {
            confirmDialog.style.display = "none";
        };

        confirmOk.onclick = function() {
            window.location.href = "removeUser.php?id[]=" + param;
        };

        window.onclick = function(event) {
            if (event.target == confirmDialog) {
                confirmDialog.style.display = "none";
            }
        }
    }

    function redirectToUpdate(param) {
        window.location.href = "updateUser.php?id=" + param;
    }

    function deleteMultipleUsers() {
        var numberOfChbxs = $('.user-mgmt-chbx').length;
        var j = 0;
        var checkArray = [];

        for (var i = 1; i <= numberOfChbxs; i++) {

            if($('#user-mgmt-chbx' + i).is(':checked')) {
                checkArray[j] = $('#user-mgmt-chbx' + i).val();
                j++;
            }
        }

        if (checkArray.length != 0) {
            var array = "";
            for (i = 0; i < checkArray.length; i++) {
                array = array + "id[]=" + checkArray[i];
                if (i != checkArray.length-1) {
                    array = array + "&";
                }
            }
            var confirmDialog = document.getElementById('mult-confirm-dialog');
            confirmDialog.style.display = "block";

            var confirmOk = document.getElementById('mult-confirm-ok');
            var confirmCancel = document.getElementById('mult-confirm-cancel');

            confirmCancel.onclick = function() {
                confirmDialog.style.display = "none";
            };

            confirmOk.onclick = function() {
                $('#user-mgmt-form').attr("action","removeUser.php?" + array);
                window.location.href = "removeUser.php?" + array;

            };

            window.onclick = function(event) {
                if (event.target == confirmDialog) {
                    confirmDialog.style.display = "none";
                }
            }

        }
        else {
            alert("Neoznačili ste žiadneho užívateľa");
        }
    }
</script>

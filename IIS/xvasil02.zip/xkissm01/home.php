<?php

// Include shared header file
include("bg_header.php");

if (is_null($session_username) || is_null($session_role)) {
    header('location: index.php');
    die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(0); ?>
    </ul>

    <h2 class="text-center">Vitajte na stránke našej krvnej banky.</h2>
    <div>
        <div class="container demo-bg">
            <div class="row">
                <div class="col-md-8">
                    <h3>Aktuality</h3>
                    <h4>24.9.2016</h4>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <h4>23.9.2016</h4>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <p>Cupcake ipsum dolor sit. Amet dragée pie tiramisu gummi bears brownie lemon drops dragée. I love fruitcake soufflé lollipop chocolate cake tiramisu tart biscuit lollipop. Jelly-o pastry cake I love sesame snaps cookie. Croissant cheesecake macaroon brownie marshmallow. Brownie liquorice pie cotton candy tiramisu oat cake cookie.</p>
                    <h4>1.9.2016</h4>
                    <p>Upíria krvná banka začala fungovať.</p>
                </div>
                <div class="col-md-4">
                    <div class="business-hours">
                        <h2 class="title">Otváracie hodiny</h2>
                        <ul class="list-unstyled opening-hours">
                            <li>Pondelok <span class="pull-right">8:00-17:00</span></li>
                            <li>Utorok <span class="pull-right">8:00-17:00</span></li>
                            <li>Streda <span class="pull-right">8:00-17:00</span></li>
                            <li>Štvrtok <span class="pull-right">8:00-17:00</span></li>
                            <li>Piatok <span class="pull-right">8:00-17:00</span></li>
                            <li>Sobota <span class="pull-right">8:00-17:00</span></li>
                            <li>Nedeľa <span class="pull-right">Zatvorené</span></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>

        <?php
        if (sessionvar('role') == 'admin') {
            echo "
            <hr>
            <div class='control-group'>
                <button class='db-reset' type='button' id='db-reset' onclick='resetDB()'>
                    Reset databázy
                </button>
            </div>
            
            <script>
            function resetDB() {
                window.location.href = 'bg_resetdb.php';
            }
            </script>
            ";
        }
        ?>
    </div>
</div>
</body>
</html>

<?php

// Include shared header file
include("bg_header.php");

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(3); ?>
    </ul>

    <h2 class="text-center">Niečo o nás.</h2>
    <p class="text-center">
        Táto stránka vznikla ako projekt do predmetu Informačné systémy
        na Fakulte informačmých technológii VUT v Brne v zime 2016.<br>
        Autori: <br>
        <tab>Marcel Kiss - xkissm01@stud.fit.vutbr.cz</tab><br>
        <tab>Maroš Vasilišin - xvasil02@stud.fit.vutbr.cz</tab><br>
        <tab>Tomáš Hrnčiar - xhrnci11@stud.fit.vutbr.cz</tab><br>
    </p>
</div>
</body>
</html>
<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

if (isset($_POST["username"])) {
    $_SESSION["username"] = $_POST["username"];

    $logins = mysql_query("SELECT `Username`, `Password`, `Role` FROM `User` 
            WHERE Username = '" . $_SESSION["username"] . "' 
            AND Password = '" . md5($_POST["pass"]) . "'", $database);

    if (mysql_num_rows($logins) == 1) {
        while ($row = mysql_fetch_array($logins)) {
            $userRole = $row['Role'];

            if ($userRole == "Administrator") {
                $_SESSION['role'] = 'admin';
                header("Location: home.php");
            } else if ($userRole == "Customer") {
                $_SESSION['role'] = 'customer';
                header("Location: home.php");
            } else if ($userRole == "Donor") {
                $_SESSION['role'] = 'donor';
                header("Location: home.php");
            } else if ($userRole == "Employee") {
                $_SESSION['role'] = 'employee';
                header("Location: home.php");
            } else {
                $_SESSION['role'] = 'none';
                header("Location: home.php");
            }
        }
        exit();
    } else if (mysql_num_rows($logins) == 0) {
        header("Location: index.php?invalidLogin=true");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}

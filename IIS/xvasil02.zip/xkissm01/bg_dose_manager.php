<?php

include_once("bg_order_manager.php");

function createDose($branch, $donor) {
    $newid = sql_insert("
        INSERT INTO Dose(Branch, DonorName, CreationDate, OrderId)
	    VALUES ('$branch','$donor', NOW(), 0);
    ");

    ordersFill();
    return $newid;
}

function deleteDose($dose_id) {
    return sql_exec("
        DELETE FROM Dose
        WHERE DoseId = $dose_id
    ");
}

function getAllDoses($branch, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('Dose.DoseId', 'Dose.DonorName', 'U.FirstName', 'U.LastName', 'Dose.Branch', 'Dose.CreationDate', 'expire_in', 'Dose.OrderId', 'B.CustomerName', 'orderName', 'Dose.Tested');

    $cond = (!is_null($branch));
    $condBranch = (!is_null($branch) ? 'Dose.Branch = \''.$branch.'\'' : '');
    $condString = ($cond ? 'WHERE '.$condBranch : '');

    //$columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT Dose.DoseId, Dose.DonorName, U.FirstName, U.LastName, Dose.Branch, Dose.CreationDate, TIMESTAMPDIFF(DAY,Dose.CreationDate,CURDATE()) AS expire_in, Dose.OrderId, B.CustomerName, CONCAT(UU.FirstName, ' ', UU.LastName) AS orderName, Dose.Tested
        FROM Dose INNER JOIN User AS U ON U.Username = Dose.DonorName
        LEFT JOIN BloodOrder AS B ON Dose.OrderId = B.BloodOrderId
        LEFT JOIN User AS UU ON B.CustomerName = UU.Username
        $condString
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    return sql_rows($sql);
}

function getAllDoseCount($branch) {
    $cond = (!is_null($branch));
    $condBranch = (!is_null($branch) ? 'Dose.Branch = \''.$branch.'\'' : '');
    $condString = ($cond ? 'WHERE '.$condBranch : '');

    $sql = "SELECT * FROM Dose $condString";
    sql_query($sql);
    return sql_affected_rows();
}

function getDonorDoses($username, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('Dose.DoseId', 'Dose.Branch', 'Dose.CreationDate', 'expire_in', 'Dose.OrderId', 'orderName');

    $cond = (!is_null($username));
    $condUser = (!is_null($username) ? 'Dose.DonorName = \''.$username.'\'' : '');
    $condString = ($cond ? 'WHERE '.$condUser : '');

    $columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT Dose.DoseId, Dose.Branch, Dose.CreationDate, TIMESTAMPDIFF(DAY,Dose.CreationDate,CURDATE()) AS expire_in, Dose.OrderId, CONCAT(UU.FirstName, ' ', UU.LastName) AS orderName
        FROM Dose INNER JOIN User AS U ON U.Username = Dose.DonorName
        LEFT JOIN BloodOrder AS B ON Dose.OrderId = B.BloodOrderId
        LEFT JOIN User AS UU ON B.CustomerName = UU.Username
        $condString
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    return sql_rows($sql);
}

function getDonorDoseCount($username) {
    $cond = (!is_null($username));
    $condUser = (!is_null($username) ? 'Dose.DonorName = \''.$username.'\'' : '');
    $condString = ($cond ? 'WHERE '.$condUser : '');
    
    $sql = "SELECT * FROM Dose $condString";
    sql_query($sql);
    return sql_affected_rows();
}

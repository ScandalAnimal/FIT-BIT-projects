<?php

// Shared database
$GLOBALS['sharedDatabase'] = null;
// Returns shared database connection
function sharedDatabase() {
    $sharedDatabase = $GLOBALS['sharedDatabase'];
    if (is_null($sharedDatabase)) {
        //$pipeName = '/var/run/mysql/mysql.sock';
        $username = 'xhrnci11';
        $password = 'sopum7ce';
        $address = 'localhost';
        $sharedDatabase = new mysqli($address, $username, $password, 'xhrnci11');
        if ($sharedDatabase->connect_errno > 0) {
            die("Couldn't connect to database");
        }
        $GLOBALS['sharedDatabase'] = $sharedDatabase;
    }
    return $sharedDatabase;
}

// Execute sql statement
function sql_query($sql) {
    $db = sharedDatabase();
    $result = null;
    if (!$result = $db->query($sql)) {
        return null;
    }
    return $result;
}

// Execute sql statement and returns number of affected rows
function sql_exec($sql) {
    $db = sharedDatabase();
    $db->query($sql);
    return sql_affected_rows();
}

function sql_err() {
    return sharedDatabase()->error;
}

// Execute sql statement and returns last generated id
function sql_insert($sql) {
    sql_query($sql);
    return sharedDatabase()->insert_id;
}

// Returns affected rows
function sql_affected_rows() {
    return sharedDatabase()->affected_rows;
}

// Execute query and return array of rows
function sql_rows($sql, $printError = false) {
    $result = sql_query($sql);

    if ($printError) echo sharedDatabase()->error;

    $rows = array();
    if ($result) {
        while($row = $result->fetch_array(MYSQLI_NUM)) {
            array_push($rows, $row);
        }
    }
    return $rows;
}

// Execute multi query
function sql_multi_query($sql) {
    $mysqli = sharedDatabase();
    if ($mysqli->multi_query($sql)) {
        do {
            /* store first result set */
            if ($result = $mysqli->store_result()) {
                while ($row = $result->fetch_row()) {

                }
                $result->free();
            }
            /* print divider */
            if ($mysqli->more_results()) {

            }
        } while ($mysqli->next_result());
    }
}

function getTable($table, $page_index, $per_page, $columns, $order_column) {
    $column_string = (!is_null($columns) && $columns != '' ? $columns : "*");
    $order_string = (!is_null($order_column) && $columns != '' ? "ORDER BY $order_column" : "");
    $row_index = $page_index * $per_page;
    $sql = "
        SELECT $column_string
        FROM $table
        LIMIT $per_page
        OFFSET $row_index
        $order_string
    ";
    $result = sql_query($sql);
    $rows = array();
    if ($result) {
        while($row = $result->fetch_array(MYSQLI_NUM)) {
            array_push($rows, $row);
        }
    }
    return $rows;
}


// OLD
function connectToDatabase() {
    $pipeName = '/var/run/mysql/mysql.sock';
    $username = 'xhrnci11';
    $password = 'sopum7ce';

    $connect = mysql_connect('localhost:' . $pipeName, $username, $password);
    if (!$connect) die('nelze se pripojit ' . mysql_error());
    if (!mysql_select_db($username, $connect)) die('database neni dostupna ' . mysql_error());

    return $connect;
}


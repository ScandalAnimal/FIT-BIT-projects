<?php

// Include shared header file
include("bg_header.php");

if (is_null($session_username)) {
    header('location: index.php');
    die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">

        <?php
        // Generate menu list for specific role and username
        // Last argument is selected index of tab
        generateMenuList(1);
        ?>

    </ul>

    <div class='container-full'>
        <hr>
        <div style="margin: auto; display: table">
            <div id="suggestionContainerDonor" class="form-component"></div>
            <div id="suggestionContainerBranch" class="form-component"></div>
            <input id="newDonationDate" class="form-component" type="text" placeholder="Dátum"/>
            <br>
            <p style="padding-top: 20px"></p>
            <input class="form-component" type="submit" value="Pridať termín" style="background-color: #990000; color: #ffffff;" onclick="addNewDonation()">
        </div>

        <hr>
        <h3>Zoznam darovaní</h3>
        <div id="table-content-doses"></div>
    </div>

    <script type="text/javascript">

        $(function () {

            var container = $('#table-content-doses');
            var columns = ['ID', 'Dátum vytvorenia', 'Login', 'Meno', 'Priezvisko', 'Pobočka', 'Dátum termínu'];
            var rowsPerPage = 15;
            var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getDonationCount_Employee, getDonations_Employee);
            gtable.rowAction('Akcia', 'Odstrániť', function (row) {
                if (confirm('Naozaj si prajete si zmazať dávku?')) {
                    var donationID = row[0];
                    delDonation_Employee(donationID, null);
                    document.gtable.refresh();
                }
            });
            gtable.hiddenColumnIndices = [0];
            gtable.showIndexColumn = true;
            gtable.conditionalFormatingFunc = donationFormattingFunc;
            gtable.noItemsMessage = 'Žiadne darovania';
            document.gtable = gtable;

            gtable.refresh();
        });

        function addNewDonation() {
            var donor = $('#newDonationUsername').val();
            var branch = $('#newDonationBranch').val();
            var date = $('#newDonationDate').val();
            addDonation_Employee(branch, donor, date, function (data) {
                if (data) {
                    $('#newDoseUsername').val('');
                    $('#newDoseBranch').val('');
                    document.gtable.refresh();
                } else {
                    alert("Zadali ste zlé údaje!");
                }
            });
        }

        $(function() {
            new GSearch($('#suggestionContainerDonor'), suggestDonor, 'newDonationUsername', 'Darca', []);
        });

        $(function() {
            new GSearch($('#suggestionContainerBranch'), suggestBranch, 'newDonationBranch', 'Pobočka', []);
        });
    </script>

</div>
</body>
</html>

<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

$params = $_GET['id'];
foreach ($params as $value) {

    mysql_query("set names 'utf8'");
    $sql = "SELECT * FROM `User` WHERE Username ='".$value."'";
    $result = mysql_query($sql);
    while ($row = mysql_fetch_assoc($result)) {
        $userRole = $row['Role'];
    }

    if (isset($userRole)) {
        if ($userRole == 'Customer') {
            $sql = "DELETE FROM `Relation` WHERE CustomerName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }

            $sql = "DELETE FROM `BloodOrder` WHERE CustomerName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }

            $sql = "DELETE FROM `Customer` WHERE CustomerName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }
        }
        else if ($userRole == 'Donor') {
            $sql = "DELETE FROM `Relation` WHERE DonorName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }

            $sql = "UPDATE `Dose` SET DonorName='unknown' WHERE DonorName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }

            $sql = "DELETE FROM `Donation` WHERE DonorName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }
            $sql = "DELETE FROM `Donor` WHERE DonorName = '".$value."'";
            echo $sql;
            if (!mysql_query($sql)) {
                echo "Error deleting record: " . mysql_error($database);
            }
        }
    }

    $sql = "DELETE FROM `User` WHERE Username = '".$value."'";
    if (!mysql_query($sql)) {
        echo "Error deleting record: " . mysql_error($database);
    }
    echo $sql;
//    exit();
}
    if ($_SESSION['role'] == "admin") {
        header("Location: admin_users.php");
    }
    else {
        header(("Location: bg_logout.php"));
    }

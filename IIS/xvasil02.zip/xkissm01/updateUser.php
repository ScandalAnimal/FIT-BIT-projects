<?php

// Include shared header file
include("bg_header.php");

$sql = "SELECT * FROM `User` WHERE Username = '".$_GET['id']."'";
$database = connectToDatabase();

$result = mysql_query($sql,$database);

if (mysql_num_rows($result) == 1) {
    while ($row = mysql_fetch_array($result)) {
        $username = $row['Username'];
        $password = $row['Password'];
        $firstname = $row['FirstName'];
        $lastname = $row['LastName'];
        $age = $row['Age'];
        $email = $row['Email'];
        $phone = $row['Phone'];
        $address = $row['Address'];
        $role = $row['Role'];
        $username = trim($username);
        $password = trim($password);
        $firstname = trim($firstname);
        $lastname = trim($lastname);
        $age = trim($age);
        $email = trim($email);
        $phone = trim($phone);
        $address = trim($address);
    }
}
else {
    echo "Error in database - no user found.";
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Prajete si uložiť zmeny?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(1); ?>
    </ul>

    <div id="register" class="register">
        <div class="register-title">
            <h2>Upraviť užívateľa</h2>
        </div>
        <form class="register-form" id="register-form" method="post" action="bg_profile_update.php?form=register">
            <div class="control-group">
                <label for="register-username">* Prihlasovacie meno</label>
                <input id="register-username" <?php
                if (isset($username)) {
                    echo 'value="'.$username.'"';} ?> type="text" name="register-username" class="register-field required-text">
                <div id="availability"><!--.--></div>
            </div>
            <div class="control-group">
                <label for="register-password">* Heslo</label>
                <input id="register-password" <?php
                if (isset($password)) {
                    echo 'value="'.$password.'"';} ?> type="text" name="register-password" class="register-field required-text">
            </div>
            <div class="control-group">
                <label for="register-password-repeat">* Heslo</label>
                <input id="register-password-repeat" <?php
                if (isset($password)) {
                    echo 'value="'.$password.'"';} ?> type="text" name="register-password-repeat" class="register-field required-text">
            </div>
            <div class="control-group">
                <label for="register-first-name">Meno</label>
                <input id="register-first-name" <?php
                if (isset($firstname)) {
                    echo 'value="'.$firstname.'"';} ?> type="text" name="register-first-name" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-last-name">Priezvisko</label>
                <input id="register-last-name" <?php
                if (isset($lastname)) {
                    echo 'value="'.$lastname.'"';} ?> type="text" name="register-last-name" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-age">Vek</label>
                <input id="register-age" <?php
                if (isset($age)) {
                    echo 'value="'.$age.'"';} ?> type="text" name="register-age" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-email">Email</label>
                <input id="register-email" <?php
                if (isset($email)) {
                    echo 'value="'.$email.'"';} ?> type="email" name="register-email" class="register-field required-text">
            </div>
            <div class="control-group">
                <label for="register-phone">Telefón</label>
                <input id="register-phone" <?php
                if (isset($phone)) {
                    echo 'value="'.$phone.'"';} ?> type="text" name="register-phone" placeholder="00421" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-address">Adresa</label>
                <input id="register-address" <?php
                if (isset($address)) {
                    echo 'value="'.$address.'"';} ?> type="text" name="register-address" class="register-field">
            </div>
            <div class="control-group">
                <label for="register-type">* Typ užívateľa</label>
                <select id="register-type" name="register-type" class="register-field required-text">
                    <option value="Donor" <?php
                    if ((isset($role)) && ($role == "Donor")) {
                        echo 'selected';} ?> >Darca</option>
                    <option value="Customer" <?php
                    if ((isset($role)) && ($role == "Customer")) {
                        echo 'selected';} ?> >Zákazník</option>
                    <?php
                        if (($_SESSION['role'] == 'admin') || ($_SESSION['role'] == 'employee')) {
                            echo "<option value ='Employee'";
                            if ((isset($role)) && ($role == "Employee")) {
                                echo 'selected';
                            }
                            echo ">Zamestnanec</option>";
                        }
                        if ($_SESSION['role'] == 'admin') {
                            echo "<option value ='Administrator'";
                                if ((isset($role)) && ($role == "Administrator")) {
                                    echo 'selected';
                                }
                            echo ">Administrátor</option>";
                        }
                    ?>
                </select>
            </div>
            <input type="hidden" name="nohash">
            <div class="control-group">
<!--                <button class="register-submit" id="register-submit">Potvrdiť</button>-->
                <input readonly class="register-submit" id="register-submit" onclick="return validateForm()" value="Potvrdiť">
            </div>

        </form>
    </div>

</body>
</html>

<script>

    $(document).ready(function(){
        $('#register-username').blur(function(){
            var username = $(this).val();
            if (username != "") {
                $.ajax({
                    url:"checkUserName.php",
                    method:"POST",
                    data:{username:username},
                    dataType:"text",
                    success:function(html)
                    {
                        isUsedName = (html == 'true');
                        if (isUsedName) {
                            $('#availability').html("<span class='text-danger'>Prihlasovacie meno je obsadené.</span>");
                        }
                        else {
                            $('#availability').html("<span class='text-success'>Prihlasovacie meno je dostupné.</span>");
                        }
                        validateUserName();
                    }
                });
            }
        });
    });

    function showDialog() {

        var confirmDialog = document.getElementById('confirm-dialog');
        confirmDialog.style.display = "block";

        var confirmOk = document.getElementById('confirm-ok');
        var confirmCancel = document.getElementById('confirm-cancel');

        confirmCancel.onclick = function() {
            confirmDialog.style.display = "none";
        };

        confirmOk.onclick = function() {
             $("#register-form").submit();
        };

        window.onclick = function(event) {
            if (event.target == confirmDialog) {
                confirmDialog.style.display = "none";
            }
        }
    }

</script>
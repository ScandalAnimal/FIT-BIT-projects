

var GDataCountFunc = function () {};
var GDataFunc = function (tableColumns, orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {};
var GActionEnableFunc = function (row) {};

var GTable = function(tableContainer, tableColumns, orderColumnIndex, orderDesc, pageIndex, rowsPerPage, dataCountFunc, dataFunc) {
    this.tableContainer = tableContainer;
    this.tableColumns = tableColumns;
    this.orderColumnIndex = orderColumnIndex;
    this.pageIndex = pageIndex;
    this.rowsPerPage = rowsPerPage;
    this.dataCountFunc = dataCountFunc;
    this.dataFunc = dataFunc;
    this.orderDesc = orderDesc;
    this.pageCount = 0;
    this.rowCount = 0;
    this.noItemsMessage = '';

    this.rowActionHeaderName = null;
    this.rowActionName = null;
    this.rowActionFunc = null;

    this.showIndexColumn = false;

    this.hiddenColumnIndices = null;

    this.conditionalFormatingFunc = null;
    this.actionEnableFunc = null;

    this.getParentElement = function(columnIndex, value) {
        if (this.conditionalFormatingFunc) {
            return this.conditionalFormatingFunc(columnIndex, value);
        }
        return null;
    };

    this.isRowAction = function() {
        return (this.rowActionHeaderName && this.rowActionName && this.rowActionFunc);
    };

    this.rowAction = function(rowActionHeaderName, rowActionName, rowActionFunc) {
        this.rowActionHeaderName = rowActionHeaderName;
        this.rowActionName = rowActionName;
        this.rowActionFunc = rowActionFunc;
        this.refresh();
    };

    this.isHiddenColumnIndex = function(index) {
        if (this.hiddenColumnIndices) {
            for (var i = 0; i < this.hiddenColumnIndices.length; i++) {
                if (index == this.hiddenColumnIndices[i]) {
                    return true;
                }
            }
        }
        return false;
    };

    this.pageCallback = function (pageIndex) {
        this.pageIndex = pageIndex;
        this.refresh();
    };


    this.orderCallback = function (orderColumnIndex) {
        if (this.orderColumnIndex == orderColumnIndex) {
            this.orderDesc = !this.orderDesc;
        } else {
            this.orderDesc = false;
        }
        this.orderColumnIndex = orderColumnIndex;
        this.refresh();
    };

    this.generateTable = function(data) {
        var gtable = this;

        var children = this.tableContainer.children();

        if (data != null && data.length > 0) {

            var info = document.createElement('label');
            var currentMin = this.pageIndex * this.rowsPerPage;
            var currentMax = Math.min((this.pageIndex + 1) * this.rowsPerPage, this.rowCount);
            info.innerHTML = '' + (currentMin + 1) + '-' + currentMax + '   (' + (this.rowCount) + ')';
            info.style.color = '#888888';
            this.tableContainer.append(info);

            var table = document.createElement('table');
            table.className = 'generated-table';

            var thead = document.createElement('thead');
            $(thead).addClass('thead-default');

            if (gtable.showIndexColumn) {
                var firstColumn = document.createElement('td');
                $(firstColumn).addClass('generated-thead-tr');
                firstColumn.innerHTML = '#';
                $(thead).append(firstColumn);
            }

            for (var theaderIndex = 0; theaderIndex < gtable.tableColumns.length; theaderIndex++) {
                if (!this.isHiddenColumnIndex(theaderIndex)) {
                    var theader_tr = document.createElement('td');
                    $(theader_tr).addClass('generated-thead-tr');
                    (function (theaderIndex) {
                        theader_tr.onclick = function () {
                            gtable.orderCallback(theaderIndex);
                        };
                        theader_tr.innerHTML = gtable.tableColumns[theaderIndex];
                    })(theaderIndex);

                    $(thead).append(theader_tr);
                }
            }

            if (gtable.isRowAction()) {
                var lastColumn = document.createElement('td');
                $(lastColumn).addClass('generated-thead-tr');
                lastColumn.innerHTML = gtable.rowActionHeaderName;
                $(thead).append(lastColumn);
            }

            $(table).append(thead);

            if (data) {
                var data_len = data.length;
                for (var index = 0; index < data.length; index++) {
                    var dataRow = document.createElement('tr');

                    if (gtable.showIndexColumn) {
                        var rowIndex = (Math.floor(this.pageIndex * gtable.rowsPerPage) + index + 1);
                        var firstDataCell = document.createElement('td');
                        $(firstDataCell).addClass('generated-td');
                        firstDataCell.innerHTML = '<b>' + rowIndex + '</b>';
                        $(dataRow).append(firstDataCell);
                    }

                    $(dataRow).addClass('generated-tr');
                    for (var columnIndex = 0; columnIndex < data[index].length; columnIndex++) {
                        if (!this.isHiddenColumnIndex(columnIndex)) {
                            var value = data[index][columnIndex];
                            var dataCell = document.createElement('td');
                            $(dataCell).addClass('generated-td');
                            var element = gtable.getParentElement(columnIndex, value);
                            if (element) {
                                $(dataCell).append(element);
                            } else {
                                dataCell.innerHTML = value;
                            }
                            $(dataRow).append(dataCell);
                        }
                    }

                    if (gtable.isRowAction()) {
                        var lastDataCell = document.createElement('td');
                        $(lastDataCell).addClass('generated-td');

                        if ((!gtable.actionEnableFunc || (gtable.actionEnableFunc && gtable.actionEnableFunc(data[index])))) {
                            var rowActionButton = document.createElement('button');
                            rowActionButton.innerHTML = gtable.rowActionName;
                            rowActionButton.value = gtable.rowActionName;
                            (function (index) {
                                rowActionButton.onclick = function (event) {
                                    gtable.rowActionFunc(data[index]);
                                };
                            })(index);
                            $(lastDataCell).append(rowActionButton);
                        }

                        $(dataRow).append(lastDataCell);
                    }

                    $(table).append(dataRow);
                }
            }
            this.tableContainer.append(table);

            if (gtable.pageCount > 0) {
                var page_container = document.createElement('div');
                page_container.style.display = "table";
                page_container.style.margin = "auto";
                page_container.style.paddingTop = '20px';
                page_container.innerHTML = 'Page: ';
                for (var pageIndex = 0; pageIndex < this.pageCount; pageIndex++) {
                    (function (pageIndex) {
                        var pageLink = document.createElement('label');
                        $(pageLink).addClass('generated-page-link');
                        pageLink.onclick = function () {
                            gtable.pageCallback(pageIndex);
                        };
                        pageLink.innerHTML = pageIndex + 1;
                        pageLink.style.paddingRight = "10px";
                        if (pageIndex == gtable.pageIndex) {
                            pageLink.style.color = "#880000";
                        }
                        $(page_container).append(pageLink);
                    })(pageIndex);
                }
                this.tableContainer.append(page_container);
            }
        } else {
            var noItemsLabel = document.createElement('i');
            noItemsLabel.innerHTML = gtable.noItemsMessage;
            noItemsLabel.style.color = '#AAA';
            gtable.tableContainer.append(noItemsLabel);
        }

        for (var i = 0; i < children.length; i++) {
            children[i].remove();
        }
    };

    this.refresh = function() {
        var gtable = this;
        this.dataCountFunc(function (rowCount) {
            if (rowCount) {
                gtable.rowCount = rowCount;
                gtable.pageCount = Math.ceil(gtable.rowCount / gtable.rowsPerPage);
                gtable.pageIndex = Math.min(gtable.pageIndex, gtable.pageCount - 1);
                gtable.dataFunc(gtable.orderColumnIndex, gtable.orderDesc, gtable.pageIndex, gtable.rowsPerPage, function (data) {
                    gtable.generateTable(data);
                })
            } else {
                gtable.rowCount = 0;
                gtable.pageCount = 0;
                gtable.pageIndex = 0;
                gtable.generateTable(null);
            }
        });
    };
};

var GSearch = function(container, suggestFunc, inputid, placeholder, classes) {
    this.container = container;
    this.suggestFunc = suggestFunc;
    this.selectedItemIndex = -1;
    this.suggestions = [];
    this.showed = false;
    this.placeholder = placeholder;
    this.inputid = inputid;
    this.classes = classes;
    this.lastTyped = "";

    this.inputElement = document.createElement("input");
    this.inputElement.autocomplete = 'off';
    this.inputElement.type = 'text';
    this.inputElement.id = this.inputid;
    $(this.inputElement).addClass('suggestionsinput');

    if (this.placeholder) {
        this.inputElement.placeholder = this.placeholder;
    }

    if (this.classes) {
        for (var i = 0; i < classes.length; i++) {
            $(this.inputElement).addClass(classes[i]);
        }
    }
    this.container.append(this.inputElement);

    //this.suggestionContainer = this.inputElement;
    this.suggestionContainer = document.createElement("div");
    $(this.suggestionContainer).addClass('suggestions');
    this.container.append(this.suggestionContainer);

    var gsearch = this;

    this.show = function(flag) {
        this.showed = flag;
        if (flag) {
            $(gsearch.suggestionContainer).show();
        } else {
            $(gsearch.suggestionContainer).hide();
        }
    };

    this.refresh = function() {
        var children = $(this.suggestionContainer).children();

        var t = document.createElement("table");
        for (var i = 0; i < this.suggestions.length; i++) {
            var row = document.createElement("tr");
            var col = document.createElement("td");
            $(col).addClass('suggestion');
            if (this.selectedItemIndex == i) {
                col.style.backgroundColor = '#400';
                col.style.color = 'white';
            }
            (function(i) {
                $(row).mouseover(function() {
                    if (gsearch.showed) {
                        if (gsearch.selectedItemIndex != i) {
                            gsearch.selectedItemIndex = i;
                            var val = gsearch.suggestions[gsearch.selectedItemIndex];
                            $(gsearch.inputElement).val(val);
                            gsearch.refresh();
                        }
                    }
                });
                $(row).mousedown(function() {
                    if (gsearch.showed) {
                        gsearch.lastTyped = $(gsearch.inputElement).val();
                        gsearch.selectedItemIndex = -1;
                        gsearch.show(false);
                        return false;
                    }
                    return true;
                });
            })(i);

            col.innerHTML = this.suggestions[i];
            row.append(col);
            t.append(row);
        }

        for (var i = 0; i < children.length; i++) {
            if (children[i] != this.inputElement) {
                children[i].remove();
            }
        }

        $(this.suggestionContainer).append(t);
    };

    $(this.inputElement).blur(function(event) {
        gsearch.show(false);
    });

    $(this.inputElement).keydown(function(event) {
        var enable = true;
        switch (event.keyCode) {
            case 38: {
                gsearch.selectedItemIndex -= 1;
                enable = false;
            } break;
            case 40: {
                gsearch.selectedItemIndex += 1;
                enable = false;
            } break;
            case 13: {
                if (gsearch.showed) {
                    gsearch.selectedItemIndex = -1;
                    gsearch.lastTyped = $(gsearch.inputElement).val();
                    gsearch.show(false);
                    enable = false;
                }
            } break;
            case 27: {
                if (gsearch.showed) {
                    gsearch.selectedItemIndex = -1;
                    $(gsearch.inputElement).val(gsearch.lastTyped);
                    gsearch.show(false);
                    enable = false;
                } else {
                    gsearch.show(true);
                }
            } break;
        }
        if (!enable) {
            if (gsearch.selectedItemIndex < 0) gsearch.selectedItemIndex = -1;
            if (gsearch.selectedItemIndex >= gsearch.suggestions.length) gsearch.selectedItemIndex = gsearch.suggestions.length - 1;

            if (gsearch.selectedItemIndex < 0) {
                $(gsearch.inputElement).val(gsearch.lastTyped);
            } else {
                var val = gsearch.suggestions[gsearch.selectedItemIndex];
                $(gsearch.inputElement).val(val);
            }

            gsearch.refresh();
        }
        return enable;
    });

    // check if key has been pressed
    $(this.inputElement).keyup(function(event) {
        if (event.keyCode != 38 && event.keyCode != 40 && event.keyCode != 13 && event.keyCode != 27) {
            var val = $(gsearch.inputElement).val();
            if(val != "") {
                gsearch.lastTyped = val;
                gsearch.suggestFunc(val, 5, function(data) {
                    gsearch.show(false);
                    gsearch.suggestions = data;
                    if (gsearch.suggestions && gsearch.suggestions.length > 0) {
                        gsearch.show(true);
                        gsearch.refresh();
                    }
                });
            } else {
                gsearch.show(false);
            }
        }
    });


};
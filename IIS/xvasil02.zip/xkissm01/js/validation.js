
function validateForm() {

    var username = document.forms["register-form"]["register-username"].value;
    if (username == null ||
        username == "" ) {
        alert("Prihlasovacie meno je zadané v neplatnom formáte.");
        return false;
    }
    var password = document.forms["register-form"]["register-password"].value;
    if (password == null ||
        password == "" ) {
        alert("Heslo je povinné.");
        return false;
    }
    var password_repeat = document.forms["register-form"]["register-password-repeat"].value;
    if (password_repeat == null ||
        password_repeat == "" ) {
        alert("Heslo je potrebné zopakovať.");
        return false;
    }
    var firstName = document.forms["register-form"]["register-first-name"].value;
    if (!firstName.match( /^$|^[a-zA-Zľščťžýáíéúäôňůřě]{3,30}$/)) {
        alert("Meno musí mať 3 až 30 znakov a musí obsahovať znaky abecedy.");
        return false;
    }
    var lastName = document.forms["register-form"]["register-last-name"].value;
    if (!lastName.match( /^$|^[a-zA-Zľščťžýáíéúäôňůřě]{3,30}$/)) {
        alert("Priezvisko musí mať 3 až 30 znakov a musí obsahovať znaky abecedy.");
        return false;
    }
    var age = document.forms["register-form"]["register-age"].value;
    if (!age.match( /^$|^[0-9]{1,3}$/)) {
        alert("Vek je zadaný v nesprávnom formáte.");
        return false;
    }
    var email = document.forms["register-form"]["register-email"].value;
    if (!email.match(/(^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$)|(^$)/)) {
        alert("Email je zadaný v neplatnom formáte.");
        return false;
    }
    var phone = document.forms["register-form"]["register-phone"].value;
    if (!phone.match( /^$|^00421[0-9]{9}$/)) {
        alert("Telefón zadaný v neplatnom formáte.");
        return false;
    }

    showDialog();
}

function validateNewDonationForm() {

    var date = document.forms["register-form"]["datepicker"].value;
    if (date == null || date == "" ) {
        alert("Dátum je povinný.");
        return false;
    }
    var volume = document.forms["register-form"]["register-volume"].value;
    if (!volume.match( /^([0-9]*\.[0-9]+|[0-9]+)$/) || volume == null || volume == "") {
        alert("Objem je zadaný v nesprávnom formáte.");
        return false;
    }

    showDialog();
}

var isUsedName = false;

function validateUserName() {
    var empty = false;
    if ($('#register-username').val() == '') {
        empty = true;
    }
    if (!empty && !isUsedName) {
        $('#availability').html("<span class='text-success'>Prihlasovacie meno je dostupné.</span>");
    }
    else {
        $('#availability').html("<span class='text-danger'>Prihlasovacie meno nie je dostupné.</span>");
    }
}

function validateProfileForm() {

    var firstName = document.forms["profile-form"]["profile-first-name"].value;
    if (!firstName.match( /^$|^[a-zA-Zľščťžýáíéúäôňůřě]{3,30}$/)) {
        alert("Meno musí mať 3 až 30 znakov a musí obsahovať znaky abecedy.");
        return false;
    }
    var password = document.forms["profile-form"]["profile-password"].value;
    if (password == null ||
        password == "" ) {
        alert("Heslo je povinné.");
        return false;
    }
    var lastName = document.forms["profile-form"]["profile-last-name"].value;
    if (!lastName.match( /^$|^[a-zA-Zľščťžýáíéúäôňůřě]{3,30}$/)) {
        alert("Priezvisko musí mať 3 až 30 znakov a musí obsahovať znaky abecedy.");
        return false;
    }
    var age = document.forms["profile-form"]["profile-age"].value;
    if (!age.match( /^$|^[0-9]{1,3}$/)) {
        alert("Vek je zadaný v nesprávnom formáte.");
        return false;
    }
    var phone = document.forms["profile-form"]["profile-phone"].value;
    if (!phone.match( /^$|^00421[0-9]{9}$/)) {
        alert("Telefón zadaný v neplatnom formáte.");
        return false;
    }
    var email = document.forms["profile-form"]["profile-email"].value;
    if (!email.match(/(^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$)|(^$)/)) {
        alert("Email je zadaný v neplatnom formáte.");
        return false;
    }

    showDialog();
}
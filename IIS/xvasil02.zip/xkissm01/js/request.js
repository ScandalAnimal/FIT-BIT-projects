
var requestFilePath = 'bg_table_manager.php';

function sendHintRequest(key, hint, hintCount, callback) {
    postData(requestFilePath, {
        request: key,
        hint: hint,
        hint_count: hintCount
    }, callback);
}

function sendRequest(key, callback) {
    postData(requestFilePath, {
        request: key
    }, callback);
}

function sendTableRequest(key, orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    postData(requestFilePath, {
        request: key,
        page_index: pageIndex,
        rows_per_page: rowsPerPage,
        order_column_index: orderColumnIndex,
        order_desc: orderDesc
    }, callback);
}

//===================================================
// Employee

function getDoses_Employee(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_doses', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getDoseCount_Employee(callback) {
    sendRequest('get_dose_count', callback);
}

function addDose_Employee(branch, donor, callback) {
    postData(requestFilePath, {
        request: 'add_dose',
        branch: branch,
        donor: donor
    }, callback);
}

function delDose_Employee(dose, callback) {
    postData(requestFilePath, {
        request: 'del_dose',
        dose: dose
    }, callback);
}

function setOrderComplete_Employee(order, callback) {
    postData(requestFilePath, {
        request: 'set_complete_order',
        order: order
    }, callback);
}

function getDonations_Employee(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_donations', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getDonationCount_Employee(callback) {
    sendRequest('get_donation_count', callback);
}

function addDonation_Employee(branch, donor, donationDate, callback) {
    postData(requestFilePath, {
        request: 'add_donation',
        donor: donor,
        branch: branch,
        donationDate: donationDate
    }, callback);
}

function delDonation_Employee(dose, callback) {
    postData(requestFilePath, {
        request: 'del_donation',
        dose: dose
    }, callback);
}

function getPreparedOrders_Employee(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_ready_orders', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getPreparedOrderCount_Employee(callback) {
    sendRequest('get_ready_order_count', callback);
}

function addOrder_Employee(customer, branch, dose_count, callback) {
    postData(requestFilePath, {
        request: 'add_order',
        customer: customer,
        branch: branch,
        dose_count: dose_count
    }, callback);
}

function delOrder_Employee(order, callback) {
    postData(requestFilePath, {
        request: 'del_order',
        order: order
    }, callback);
}

function getOrders_Employee(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_orders', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getOrderCount_Employee(callback) {
    sendRequest('get_order_count', callback);
}

//===================================================
// Customer

function getFriend_Customer(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_friends', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getFriendCount_Customer(callback) {
    sendRequest('get_friend_count', callback);
}

function addFriend_Customer(donor, callback) {
    postData(requestFilePath, {
        request: 'add_friend',
        donor: donor
    }, callback);
}

function delFriend_Customer(relation, callback) {
    postData(requestFilePath, {
        request: 'del_friend',
        relation: relation
    }, callback);
}

function getOrders_Customer(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_orders', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getOrderCount_Customer(callback) {
    sendRequest('get_order_count', callback);
}

function addOrder_Customer(branch, dose_count, callback) {
    postData(requestFilePath, {
        request: 'add_order',
        branch: branch,
        dose_count: dose_count
    }, callback);
}

function delOrder_Customer(order, callback) {
    postData(requestFilePath, {
        request: 'del_order',
        order: order
    }, callback);
}

//===================================================
// Donor

function getDoses_Donor(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_doses', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getDoseCount_Donor(callback) {
    sendRequest('get_dose_count', callback);
}

function getDonations_Donor(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_donations', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getDonationCount_Donor(callback) {
    sendRequest('get_donation_count', callback);
}

function addDonation_Donor(branch, date, callback) {
    postData(requestFilePath, {
        request: 'add_donation',
        branch: branch,
        date: date
    }, callback);
}

function delDonation_Donor(donation, callback) {
    postData(requestFilePath, {
        request: 'del_donation',
        donation: donation
    }, callback);
}

function getFriend_Donor(orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback) {
    sendTableRequest('get_friends', orderColumnIndex, orderDesc, pageIndex, rowsPerPage, callback);
}

function getFriendCount_Donor(callback) {
    sendRequest('get_friend_count', callback);
}

function suggestCustomer_Donor(hint, hintCount, callback) {
    sendHintRequest('sug_customer', hint, hintCount, callback);
}


//======================================
// General

function suggestDonor(hint, hintCount, callback) {
    sendHintRequest('sug_donor', hint, hintCount, callback);
}

function suggestCustomer(hint, hintCount, callback) {
    sendHintRequest('sug_customer', hint, hintCount, callback);
}

function suggestBranch(hint, hintCount, callback) {
    sendHintRequest('sug_branch', hint, hintCount, callback);
}
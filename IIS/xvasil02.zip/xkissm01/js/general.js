
function postData(url, data, callback) {
    $.ajax({
        type: 'POST',
        url: url,
        dataType: 'text',
        data: data,
        success: function(data, textStatus, xhr) {
            var jsonData = null;
            if (data) {
                try {
                    jsonData = JSON.parse(data);
                } catch (err) {
                    alert(err)
                    alert(data);
                }
            }
            if (callback) {
                return callback(jsonData, textStatus, xhr);
            }
        },
        error: function(data, textStatus, xhr) {
            alert("Error ('" + url + "'): " + textStatus);
        }
    });
}

function orderFormattingFunc(columnIndex, columnValue) {
    if (columnIndex == 8) {
        var elementName = 'p';
        var color = '#000000';
        var lname = "";
        switch (columnValue) {
            case 'Complete': {
                elementName = 'b';
                color = "#004400";
                lname = "Vybavené";
            } break;
            case 'Preparing': {
                elementName = 'i';
                color = "#888800";
                lname = "Pripravuje sa";
            } break;
            case 'Prepared': {
                elementName = 'p';
                color = "#00AA00";
                lname = "Pripravené";
            } break;
        }
        var element = document.createElement(elementName);
        element.style.color = color;
        element.innerHTML = lname;
        return element;
    }
    return null;
}

function dosesFormattingFunc(columnIndex, columnValue) {
    if (columnIndex == 6) {
        var elementName = 'p';
        var color = '#000000';
        var b = document.createElement('b');
        b.innerText = columnValue;
        if (columnValue > 300) {
            color = '#00BB99';
            b.innerText += ' diamond';
        } else
        if (columnValue > 180) {
            color = '#AA6600';
            b.innerText += ' gold';
        } else
        if (columnValue > 90) {
            color = '#226666';
            b.innerText += ' rare';
        } else
        if (columnValue > 30) {
            color = '#668800';
        } else {
            color = '#666';
        }
        var element = document.createElement(elementName);
        $(element).append(b);
        element.style.color = color;
        return element;
    } else
    if (columnIndex == 2 || columnIndex == 3) {
        var elementName = 'p';
        var color = '#000000';
        var b = document.createElement('b');
        b.innerText = columnValue;
        var element = document.createElement(elementName);
        $(element).append(b);
        element.style.color = color;
        return element;
    }
    return null;
}

function donorDosesFormattingFunc(columnIndex, columnValue) {
    if (columnIndex == 3) {
        var elementName = 'p';
        var color = '#000000';
        var b = document.createElement('b');
        b.innerText = columnValue;
        if (columnValue > 300) {
            color = '#44CCAA';
            b.innerText += ' (Diamond)';
        } else
        if (columnValue > 180) {
            color = '#CC9900';
            b.innerText += ' (Golden)';
        } else
        if (columnValue > 90) {
            color = '#44AACC';
            b.innerText += ' (Rare)';
        } else
        if (columnValue > 30) {
            color = '#88AA22';
        } else {
            color = '#AAAAAA';
        }
        var element = document.createElement(elementName);
        $(element).append(b);
        element.style.color = color;
        return element;
    }
    if (columnIndex == 2 || columnIndex == 3) {
        var elementName = 'p';
        var color = '#000000';
        var b = document.createElement('b');
        b.innerText = columnValue;
        var element = document.createElement(elementName);
        $(element).append(b);
        element.style.color = color;
        return element;
    }
    return null;
}

function donationFormattingFunc(columnIndex, columnValue) {
    if (columnIndex == 6) {
        var elementName = 'p';
        var color = '#000000';
        var d = new Date(columnValue);
        if (d.getTime() < (new Date()).getTime()) {
            color = '#800';
        } else {
            color = '#080';
        }
        var b = document.createElement('b');
        b.innerText = columnValue;
        var element = document.createElement(elementName);
        $(element).append(b);
        element.style.color = color;
        return element;
    }
    return null;
}

function orderActionEnableFunc(data) {
    if (data[8] == 'Complete') {
        return false;
    }
    return true;
}

function orderActionEnableFuncCustomer(data) {
    if (data[4] == 'Complete') {
        return false;
    }
    return true;
}
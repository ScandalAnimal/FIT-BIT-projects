<?php

function getAllDonations($username, $branch, $pageIndex, $rowsPerPage, $orderColumnIndex, $orderDesc) {
    $tableColumns = array('Donations.id', 'Donations.creationDate', 'Donations.donor', 'D.FirstName', 'D.LastName', 'Donations.branch', 'Donations.donationDate');

    $condBranch = (!is_null($branch) ? 'Donations.Branch = \''.$branch.'\'' : null);
    $condUser = (!is_null($username) ? 'Donations.donor = \''.$username.'\'' : null);
    $condArray = array();
    if ($condBranch) array_push($condArray, $condBranch);
    if ($condUser) array_push($condArray, $condUser);
    $condString = (count($condArray) ? 'WHERE '.implode(' AND ', $condArray) : '');

    //$columnsString = implode(', ', $tableColumns);
    $rowIndex = $pageIndex * $rowsPerPage;
    $descString = (!is_null($orderDesc) && $orderDesc == 'true' ? "DESC" : "ASC");
    $orderString = (!is_null($orderColumnIndex) && $orderColumnIndex != '' ? "ORDER BY ".$tableColumns[$orderColumnIndex]." $descString" : "");
    $sql = "
        SELECT Donations.id, Donations.creationDate, Donations.donor, D.FirstName, D.LastName, Donations.branch, Donations.donationDate
        FROM Donations INNER JOIN User AS D ON D.Username = Donations.donor
        $condString
        $orderString
        LIMIT $rowsPerPage
        OFFSET $rowIndex
    ";
    echo sql_err();

    //echo $sql;
    return sql_rows($sql);
}

function getAllDonationCount($username, $branch) {

    $condBranch = (!is_null($branch) ? 'Donations.Branch = \''.$branch.'\'' : null);
    $condUser = (!is_null($username) ? 'Donations.donor = \''.$username.'\'' : null);
    $condArray = array();
    if ($condBranch) array_push($condArray, $condBranch);
    if ($condUser) array_push($condArray, $condUser);
    $condString = (count($condArray) ? 'WHERE '.implode(' AND ', $condArray) : '');

    $sql = "SELECT * FROM Donations $condString";

    sql_query($sql);
    return sql_affected_rows();
}

function addDonation($donor, $branch, $donationDate) {
    $newid = sql_insert("
        INSERT INTO Donations(creationDate, donor, branch, donationDate)
	    VALUES (NOW(), '$donor','$branch', '$donationDate');
    ");
    return $newid;
}

function delDonation($donationID) {
    return sql_exec("
        DELETE FROM Donations
        WHERE id = $donationID
    ");
}
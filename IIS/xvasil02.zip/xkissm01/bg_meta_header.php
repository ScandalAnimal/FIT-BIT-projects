<?php

// Empty

?>

<!-- Meta -->
<meta charset="utf-8">

<!-- Links -->
<link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

<link rel="stylesheet" href="css/generate.css">
<link rel="stylesheet" href="css/home.css">
<link rel="stylesheet" href="css/modalDialog.css">
<link rel="stylesheet" href="css/profileStyle.css">
<link rel="stylesheet" href="css/style.css">

<!-- Scripts -->
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>

<script type="text/javascript" src="js/general.js"></script>
<script type="text/javascript" src="js/gtable.js"></script>
<script type="text/javascript" src="js/gsearch.js"></script>
<script type="text/javascript" src="js/gdate.js"></script>
<script type="text/javascript" src="js/request.js"></script>
<script type="text/javascript" src="js/validation.js"></script>
<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
    <script type="text/javascript" src="js/validation.js"></script>
    <link rel="stylesheet" href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/themes/smoothness/jquery-ui.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.1/jquery-ui.min.js"></script>
</head>
<body>


<div id="confirm-dialog" class="modal">

    <div class="modal-content">
        <p>Naozaj si prajete odhlásiť sa z darovania?</p>
        <button id="confirm-ok">Áno</button>
        <button id="confirm-cancel">Zrušiť</button>
    </div>

</div>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(1); ?>
    </ul>

    <div align="center">
        <div class="register-title">
            <h3>Nový termín darovania</h3>
        </div>

        <div style="margin: auto; display: table">
            <div id="branchTextFieldContainer" class="form-component"></div>
            <input type="text" id="datepicker" placeholder="Dátum" class="form-component">
            <input id="register-date" type="hidden" name="register-date" class="register-field required-text">
            <input type="button" class="register-submit form-component" id="register-submit" value="Potvrdiť" onclick="return addDonation()">
        </div>

    </div>
    <hr>

    <div class='container-full'>
        <h3>Zoznam darovaní</h3>
        <div id="table-content-dontations"></div>
    </div>

    <div id="confirm-dialog" class="modal">

        <div class="modal-content">
            <p>Prajete si vytvoriť objednávku?</p>
            <button id="confirm-ok">Áno</button>
            <button id="confirm-cancel">Zrušiť</button>
        </div>

    </div>

</body>
</html>

<script>

    function addDonation() {
        var branch = $('#newDonationBranch').val();
        var dateString = $('#datepicker').val();
        var date = new Date(getDateFromFormat(dateString, "dd.MM.yyyy"));
        var strDate = 'Y-m-d'
            .replace('Y', date.getFullYear())
            .replace('m', date.getMonth()+1)
            .replace('d', date.getDate());

        addDonation_Donor(branch, strDate, null);
        document.gtable.refresh();
        $('#newDonationBranch').val("");
        $('#datepicker').val("");
        return false;
    }

    $(function () {

        var container = $('#table-content-dontations');
        var columns = ['ID', 'Dátum vytvorenia', 'Login', 'Meno', 'Priezvisko', 'Pobočka', 'Dátum termínu'];
        var rowsPerPage = 15;
        var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getDonationCount_Donor, getDonations_Donor);
        gtable.rowAction('Akcia', 'Odstrániť', function(data) {
            if (confirm("Naozaj chcete zrušiť termín?")) {
                var id = data[0];
                delDonation_Donor(id);
                gtable.refresh();
            }
        });
        gtable.hiddenColumnIndices = [0, 2, 3, 4];
        gtable.showIndexColumn = true;
        gtable.conditionalFormatingFunc = donationFormattingFunc;
        gtable.noItemsMessage = 'Nemáte žiadne darovania';
        document.gtable = gtable;

        gtable.refresh();
    });

    $(function() {
        new GSearch($('#branchTextFieldContainer'), suggestBranch, 'newDonationBranch', 'Pobočka', null);
        new GDate($('#datepicker'));
    });

</script>

-- zmazat vsetky tabulky
SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS BloodOrder;
DROP TABLE IF EXISTS Relation;
DROP TABLE IF EXISTS RelationStatus;
DROP TABLE IF EXISTS BloodOrderStatus;
DROP TABLE IF EXISTS Dose;
DROP TABLE IF EXISTS Donations;
DROP TABLE IF EXISTS Donor;
DROP TABLE IF EXISTS Customer;
DROP TABLE IF EXISTS User;
DROP TABLE IF EXISTS Roles;
DROP TABLE IF EXISTS BloodPrice;
DROP TABLE IF EXISTS Branch;
SET FOREIGN_KEY_CHECKS=1;
 
-- uzivatelske roly
CREATE TABLE Roles
(
Name varchar(255) NOT NULL,
PRIMARY KEY (Name)
);

-- typy krvi a ich cena
CREATE TABLE BloodPrice
(
BloodType varchar(255) NOT NULL,
Price float NOT NULL,
PRIMARY KEY (BloodType)
);

-- stavy objednavok
CREATE TABLE BloodOrderStatus
(
Name varchar(255) NOT NULL,
PRIMARY KEY (Name)
);

-- pobocky
CREATE TABLE Branch
(
City varchar(255) NOT NULL,
Capacity int NOT NULL CHECK (Capacity > 1000),
CurrentFill int NOT NULL CHECK (Capacity > CurrentFill),
PRIMARY KEY (City)
);

-- pouzivatelia
CREATE TABLE User
(
Username varchar(255) NOT NULL,
Password varchar(255) NOT NULL,
FirstName varchar(255),
LastName varchar(255),
Age int CHECK (Age > 0),
Email varchar(255) NOT NULL,
Phone varchar(14),
Address varchar(255),
Role varchar(255) NOT NULL,
PRIMARY KEY (Username),
FOREIGN KEY (Role) REFERENCES Roles(Name)
);

-- darcovia
CREATE TABLE Donor
(
DonorName varchar(255) NOT NULL,
BloodType varchar(255) NOT NULL,
PRIMARY KEY (DonorName),
FOREIGN KEY (DonorName) REFERENCES User(Username),
FOREIGN KEY (BloodType) REFERENCES BloodPrice(BloodType)
);

-- zakaznici
CREATE TABLE Customer
(
CustomerName varchar(255) NOT NULL,
LastDose date,
PreferredBranch varchar(255),
PRIMARY KEY (CustomerName),
FOREIGN KEY (CustomerName) REFERENCES User(Username),
FOREIGN KEY (PreferredBranch) REFERENCES Branch(City)
);

-- darovani krvi
CREATE TABLE Donations (

  id INT AUTO_INCREMENT NOT NULL,
  creationDate DATE NOT NULL,
  donor varchar(255) NOT NULL,
  branch varchar(255) NOT NULL,
  donationDate VARCHAR(255) NOT NULL,

  PRIMARY KEY (id),
  FOREIGN KEY (donor) REFERENCES Donor(DonorName),
  FOREIGN KEY (branch) REFERENCES Branch(City)
);

-- davky
CREATE TABLE Dose(
DoseId int AUTO_INCREMENT NOT NULL,
Branch varchar(255) NOT NULL,
DonorName varchar(255),
CreationDate date NOT NULL,
OrderId int,
Tested tinyint(1),
PRIMARY KEY (DoseId),
FOREIGN KEY (Branch) REFERENCES Branch(City),
FOREIGN KEY (DonorName) REFERENCES Donor(DonorName)
);

-- stavy vztahov
CREATE TABLE RelationStatus
(
Name varchar(255) NOT NULL,
PRIMARY KEY (Name)
);

-- vztahy zakaznik-darca
CREATE TABLE Relation
(
RelationId int AUTO_INCREMENT NOT NULL,
DonorName varchar(255) NOT NULL,
CustomerName varchar(255) NOT NULL,
Status varchar(255) NOT NULL,
PRIMARY KEY (RelationId),
FOREIGN KEY (DonorName) REFERENCES Donor(DonorName),	
FOREIGN KEY (CustomerName) REFERENCES Customer(CustomerName),
FOREIGN KEY (Status) REFERENCES RelationStatus(Name)
);

-- objednavka
CREATE TABLE BloodOrder
(
BloodOrderId int AUTO_INCREMENT NOT NULL,
CustomerName varchar(255) NOT NULL,
Branch varchar(255) NOT NULL,
CreationDate date NOT NULL,
DoseCount int NOT NULL,
Status varchar(255) NOT NULL,
PRIMARY KEY (BloodOrderId),
FOREIGN KEY (CustomerName) REFERENCES Customer(CustomerName),
FOREIGN KEY (Status) REFERENCES BloodOrderStatus(Name),
FOREIGN KEY (Branch) REFERENCES Branch(City)	
);

-- role v systeme
INSERT INTO Roles(Name) VALUES ('Donor');
INSERT INTO Roles(Name) VALUES ('Customer');
INSERT INTO Roles(Name) VALUES ('Employee');
INSERT INTO Roles(Name) VALUES ('Administrator');

-- relation stavy
INSERT INTO RelationStatus(Name) VALUES ('Friends');
INSERT INTO RelationStatus(Name) VALUES ('Blocked');

-- stavy objednavky
INSERT INTO BloodOrderStatus(Name) VALUES ('Preparing');
INSERT INTO BloodOrderStatus(Name) VALUES ('Prepared');
INSERT INTO BloodOrderStatus(Name) VALUES ('Complete');

-- krvne skupiny a ich cena
INSERT INTO BloodPrice(BloodType,Price) VALUES ('A','10');
INSERT INTO BloodPrice(BloodType,Price) VALUES ('B','12');
INSERT INTO BloodPrice(BloodType,Price) VALUES ('AB','15');
INSERT INTO BloodPrice(BloodType,Price) VALUES ('0','16');
INSERT INTO BloodPrice(BloodType,Price) VALUES ('undefined','16');

-- pobocky
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Brno',100000,5000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Praha',200000,25000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Bratislava',150000,25000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Zilina',20000,5000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Nitra',20000,5000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Kosice',30000,5000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Budapest',50000,10000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Vieden',70000,5000);
INSERT INTO Branch(City,Capacity,CurrentFill) VALUES ('Krakov',70000,10000);

-- admini (pass: admin)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('admin','21232f297a57a5a743894a0e4a801fc3','Admin','Adminovic','25','admin@bloodbank.sk','00421000111222','Hlavna 1 Bratislava','Administrator');

-- zamestnanci (pass: 123456)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('employee1','e10adc3949ba59abbe56e057f20f883e','Jakub','Horvath','25','employee1@bloodbank.sk','00421000111333','Hlavna 1 Bratislava','Employee');
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('employee2','e10adc3949ba59abbe56e057f20f883e','Adam','Kovac','25','employee2@bloodbank.sk','00421000111444','Hlavna 1 Bratislava','Employee');

-- darcovia - zaznam v tabulke user aj donor 
-- INSERT INTO User(Username,Password,Role) VALUES ('unknown','123456','Donor');
-- INSERT INTO Donor(DonorName,BloodType) VALUES('unknown','undefined');

 -- (pass: 123456)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('donor1','e10adc3949ba59abbe56e057f20f883e','Natalia','Lukacova','25','natalia@gmail.com','00421000111555','Hlavna 2 Bratislava','Donor');
INSERT INTO Donor(DonorName,BloodType)
	VALUES('donor1','A');

-- (pass: 123456)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('donor2','e10adc3949ba59abbe56e057f20f883e','Michal','Varga','25','varga@gmail.com','00421000111666','Hlavna 3 Bratislava','Donor');
INSERT INTO Donor(DonorName,BloodType)
	VALUES('donor2','B');

-- zakaznici - zaznam v tabulke user aj customer (pass: 123456)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('customer1','e10adc3949ba59abbe56e057f20f883e','Tomas','Molnar','25','molnar@gmail.com','00421000111777','Hlavna 4 Bratislava','Customer');
INSERT INTO Customer(CustomerName,LastDose,PreferredBranch)
	VALUES('customer1','2016-09-15','Bratislava');

-- (pass: 123456)
INSERT INTO User(Username,Password,FirstName,LastName,Age,Email,Phone,Address,Role)
	VALUES ('customer2','e10adc3949ba59abbe56e057f20f883e','Katarina','Balogova','25','katka@gmail.com','00421000111888','Hlavna 5 Bratislava','Customer');
INSERT INTO Customer(CustomerName,LastDose,PreferredBranch)
	VALUES('customer2','2016-09-16','Bratislava');

-- objednavky
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer1', 'Bratislava', '2008-10-09', 3, 'Prepared');
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer2', 'Zilina', '2008-7-20', 3, 'Prepared');
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer1', 'Nitra', '2009-3-05', 2, 'Complete');
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer2', 'Zilina', '2009-6-12', 2, 'Prepared');
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer1', 'Nitra', '2009-9-04', 4, 'Complete');
INSERT INTO BloodOrder(CustomerName, Branch, CreationDate, DoseCount, Status)
	VALUES ('customer2', 'Bratislava', '2010-5-01', 4, 'Prepared');

-- darovania krvi - vsetky z minulosti aj naplanovane do buducnosti + zapis tych ktore uz prebehli do tabulky dose
-- Brno Praha Bratislava Zilina Nitra Kosice Budapest Vieden Krakov


DROP FUNCTION IF EXISTS generate_branch;
CREATE FUNCTION generate_branch() RETURNS VARCHAR(255)
BEGIN
  DECLARE newbranch VARCHAR(255);
  SELECT City INTO newbranch FROM Branch ORDER BY RAND() LIMIT 1;
  RETURN newbranch;
END;

-- Function to generate random date from NOW - DAYS
DROP FUNCTION IF EXISTS generate_date;
CREATE FUNCTION generate_date(days INT) RETURNS DATE
BEGIN
  DECLARE newdate DATE DEFAULT NOW();
  SELECT NOW() - INTERVAL FLOOR(RAND() * days) DAY INTO newdate;
  RETURN newdate;
END;

-- Generate donations
DROP PROCEDURE if EXISTS generate_donations;
CREATE PROCEDURE generate_donations(max_items INT)
BEGIN

  DECLARE counter INT DEFAULT 0;
  DECLARE newDate DATE DEFAULT 0;

  START TRANSACTION;
  WHILE counter < max_items DO

    SET newDate = generate_date(365);

    INSERT INTO Donations(creationDate, donor, branch, donationDate) VALUES (
      (generate_date(365)),
      (SELECT DonorName FROM Donor ORDER BY RAND() LIMIT 1),
      (generate_branch()),
      newDate
    );

    INSERT INTO Dose(Branch, DonorName, CreationDate, OrderId) VALUES (
      (generate_branch()),
      (SELECT DonorName FROM Donor ORDER BY RAND() LIMIT 1),
      newDate,
      0
    );

    SET counter = counter + 1;
  END while;
  COMMIT;
END;

-- Generate donations
DROP PROCEDURE if EXISTS generate_future_donations;
CREATE PROCEDURE generate_future_donations(max_items INT)
BEGIN

  DECLARE counter INT DEFAULT 0;

  START TRANSACTION;
  WHILE counter < max_items DO

    INSERT INTO Donations(creationDate, donor, branch, donationDate) VALUES (
      (generate_date(365)),
      (SELECT DonorName FROM Donor ORDER BY RAND() LIMIT 1),
      (generate_branch()),
      (generate_date(-365))
    );

    SET counter = counter + 1;
  END while;
  COMMIT;
END;

call generate_donations(30);

call generate_future_donations(10);


-- priklad vztahu
INSERT INTO Relation(DonorName, CustomerName, Status) VALUES ('donor1','customer1','Friends');


<?php

// Include shared header file
include("bg_header.php");

$database = connectToDatabase();

$form = $_GET['form'];

if(isset($_POST[$form."-first-name"])) {
    $firstName = $_POST[$form."-first-name"];
}
else {
    $firstName = "test";
}
if(isset($_POST[$form."-last-name"])) {
    $lastName = $_POST[$form."-last-name"];
}
else {
    $lastName = "test";
}
if(isset($_POST[$form."-age"])) {
    $age = $_POST[$form."-age"];
}
else {
    $age = "40";
}
if(isset($_POST[$form."-email"])) {
    $email = $_POST[$form."-email"];
}
else {
    $email = "example@example.com";
}
if(isset($_POST[$form."-phone"])) {
    $phone = $_POST[$form."-phone"];
}
else {
    $phone = "00421111111111";
}
if(isset($_POST[$form."-username"])) {
    $username = $_POST[$form."-username"];
}
else {
    $username = "username";
}
if(isset($_POST[$form."-password"])) {
    $password = $_POST[$form."-password"];
}
else {
    $password = "password";
}
if(isset($_POST[$form."-address"])) {
    $address = $_POST[$form."-address"];
}
else {
    $address = "test";
}
if(isset($_POST[$form."-type"])) {
    $type = $_POST[$form."-type"];
}
else {
    $type = "Donor";
}

if (!isset($_POST['nohash'])) {
    $password = md5($password);
}

$query = "UPDATE `User` SET Password='".$password."', FirstName='".$firstName."', LastName='".$lastName."
    ', Age=".$age.", Email='".$email."', Phone='".$phone."', Address='".$address."', Role='".$type."' WHERE Username='".$username."'";
//
//    "INSERT INTO `User`(`Username`,`Password`, `FirstName`, `LastName`, `Age`, `Email`,
//                                        `Phone`, `Address`, `Role`)
//                            VALUES ('".$username."', '".$password."', '".$firstName."', '".$lastName."', '".$age."', '".
//    $email."', '".$phone."', '".$address."', '".$type."')";
$sql = mysql_query($query, $database);


if($_SESSION['role'] == 'customer'){
    header('Location: home.php');
}
elseif($_SESSION['role'] == "donor"){
    header('Location: home.php');
}
elseif($_SESSION['role'] == "admin") {
    header('location: admin_users.php');
}

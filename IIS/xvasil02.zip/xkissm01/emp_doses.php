<?php

// Include shared header file
include("bg_header.php");

if (is_null($session_username)) {
    header('location: index.php');
    die();
}

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>
<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">

        <?php
        // Generate menu list for specific role and username
        // Last argument is selected index of tab
        generateMenuList(2);
        ?>

    </ul>

    <div class='container-full'>
        <hr>
        <div style="margin: auto; display: table">
            <div id="suggestionContainerDose" class="form-component"></div>
            <div id="suggestionContainerBranch" class="form-component"></div>
            <p style="padding-top: 20px"></p>
            <input class="form-component" type="submit" value="Pridať odber" style="background-color: #990000; color: #ffffff;" onclick="addNewDose()">
        </div>

        <hr>
        <h3>Zoznam krvných dávok</h3>
        <div id="table-content-doses"></div>
    </div>

    <script type="text/javascript">

        $(function () {

            var container = $('#table-content-doses');
            var columns = ['ID', 'Login', 'Meno', 'Priezvisko', 'Pobočka', 'Dátum', 'Vek (dni)', 'V objednávke', 'Login Objednávateľa', 'Objednávatel', 'Testované'];
            var rowsPerPage = 15;
            var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getDoseCount_Employee, getDoses_Employee);
            gtable.rowAction('Akcia', 'Odstrániť', function (row) {
                if (confirm('Naozaj si prajete si zmazať dávku?')) {
                    var doseId = row[0];
                    delDose_Employee(doseId, null);
                    document.gtable.refresh();
                }
            });
            gtable.hiddenColumnIndices = [0, 7, 10];
            gtable.showIndexColumn = true;
            gtable.conditionalFormatingFunc = dosesFormattingFunc;
            gtable.noItemsMessage = "Nie sú žiadne dávky na zobrazenie";
            document.gtable = gtable;

            gtable.refresh();
        });

        function addNewDose() {
            var donor = $('#newDoseUsername').val();
            var branch = $('#newDoseBranch').val();
            addDose_Employee(branch, donor, function (data) {
                if (data) {
                    $('#newDoseUsername').val('');
                    $('#newDoseBranch').val('');
                    document.gtable.refresh();
                } else {
                    alert("Zadali ste zlé údaje!");
                }
            });
        }
        $(function() {
            new GSearch($('#suggestionContainerDose'), suggestDonor, 'newDoseUsername', 'Darca', []);
        });

        $(function() {
            new GSearch($('#suggestionContainerBranch'), suggestBranch, 'newDoseBranch', 'Pobočka', []);
        });

    </script>

</div>
</body>
</html>

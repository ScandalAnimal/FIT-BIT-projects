<?php

// Include shared header file
include("bg_header.php");

?>

<!DOCTYPE html>
<html>
<head>
    <!-- Include global header -->
    <?php include_once('bg_meta_header.php'); ?>
    <!-- Add additional files here (<meta/>, <link/>, <script/>) -->
</head>
<body>

<div class="container box">
    <div class="splash-image">
        <img src="splash.png" width="100%" height="100%" style="max-width: 100%; max-height: 100%">
    </div>
    <ul class="menu">
        <?php generateMenuList(2); ?>
    </ul>

    <div class='container-full'>
        <h3>Zoznam dávok</h3>
        <div id="table-content-dontations"></div>
    </div>
</body>
</html>

<script>

    $(function () {

        var container = $('#table-content-dontations');
        var columns = ['ID', 'Pobočka', 'Dátum', 'Vek', 'V objednávke', 'Objednávatel'];
        var rowsPerPage = 15;
        var gtable = new GTable(container, columns, 0, false, 0, rowsPerPage, getDoseCount_Donor, getDoses_Donor);
        gtable.hiddenColumnIndices = [0, 4];
        gtable.showIndexColumn = true;
        gtable.conditionalFormatingFunc = donorDosesFormattingFunc;
        gtable.noItemsMessage = 'Nemáte žiadne darovania';
        document.gtable = gtable;

        gtable.refresh();
    });

</script>

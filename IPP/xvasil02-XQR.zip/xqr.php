#!/usr/local/bin/php
<?php
#XQR:xvasil02


/*****************************************
 *****************************************
 *	Class: IPP
 *	Project: 1
 *	Option: XQR - XMLQuery in PHP 5
 *	Author: Maroš Vasilišin
 *	Login: xvasil02
 *****************************************
 *****************************************/

/*
 * This script is evaluating query, which is similar to command SELECT in SQL language,
 * over XML file. On output there is XML which fulfills requirements of query.
 */


// variable that stores query from command line or file 
$query = ""; 


// we put all data needed for accessing xml file here
$query_array = array( 
			"root" => "", // name of root element in output(optional)
			"isheader" => true, // if we generate xml header or not
			"input" => "", // file on input
			"output" => "", // file on output
		    "searched" => "", // name of searched element
		    "limit" => "", // limit of how many elements we generate on output maximally
		    "from" => "", // element from which we start searching xml
		    "fattribute" => "", // attribute of 'from' element
		    "not" => "not found", // if there was NOT
		    "element" => "", // element in WHERE clause
		    "attribute" => "", // attribute of 'element'
		    "operator" => "", // operator in WHERE
		    "literal" => "", // literal in WHERE
		    "literal_type" => "", // type of literal in WHERE (number or string)
		);


// literal from WHERE clause will be here, without quotation marks
$rightside = null; 

// this array defines words, that are invalid if they were to be tags in input XML file
$keywords = array("SELECT","LIMIT","FROM","WHERE","ROOT","ORDER","BY","ASC","DESC","NOT",">","<","=","CONTAINS");

// flag, if there is invalid tag in XML
$problem = false;

$newresult = "";


// command line script arguments control function

	function check_parameters($argv,$argc) {
		
		$i = 0; // cycles variable
		$q = false; // variable for control of query|qf (they cannot be together)

		global $query;

		global $query_array;

		$key = array( // array holding possible forms of command line arguments
		    "program" => array(
		        "form" => "/xqr.php/",
		        "was" => false,
		    ),
		    "input" => array(
		        "form" => "/^-{1,2}input=(.*)/",
		        "was" => false,
		    ),
		    "output" => array(
		        "form" => "/^-{1,2}output=(.*)/",
		        "was" => false,
		    ),
		    "query" => array(
		        "form" => "/^-{1,2}query=(.*)/",
		        "was" => false,
		        "right" => false,
		    ),
		    "qf" => array(
		        "form" => "/^-{1,2}qf=(.*)/",
		        "was" => false,
		        "right" => false,
		    ),
		    "root" => array(
		        "form" => "/^-{1,2}root=(.*)/",
		        "was" => false,
		    ),
		    "header" => array(
		        "form" => "/-n/",
		        "was" => false,
		    )
		);


		foreach ($argv as $value) { // foreach cycle iterates over all arguments

			if (($value === "--help") || ($value === "-help")) { // argument --help is separate here
				if ($argc != 2) { // --help must be only argument except of script name
					file_put_contents('php://stderr', "Bad argument(s). Try --help\n");
					exit(1);
				}
				echo ( // what will be visible to user as help
					"HELP\n" .
			        "Program Usage:" . "php xqr.php {parameters}\n\n" .
			        "Parameters can be:\n" .
			        "--help             Print help page, can be used only as single parameter\n" .
			        "--input=filename   Load XML file to read, if not provided, set to stdin\n" .
			        "--output=filename  File to store results, if not provided, set to stdout\n" .
			        "--query=request    Request for what to do over XML on input\n" .
			        "--qf=filename      Request saved in file, cannot be combined with --query=request\n" .
			        "-n                 Do not generate XML head on script output\n" .
			        "--root=element     Name of XML root wrapping results\n\n" .
			        
			        "*filename can be specified as absolute or relative path\n\n" . 
			        "Request example:\n" .
			        "SELECT " . "element LIMIT n FROM element|element.attribute|ROOT WHERE condition\n" .
					"       ORDER BY element|element.attribute ASC|DESC\n"
			    );
			    exit(0);
			}
			
			$keys = array_keys($key); // all the keys of the array '$key' are assigned to variable '$keys'

			for($i = 0; $i < count($key); $i++) { // iteration over all values
			    $found = "0"; // variable for storing value, if program would find the value
			    
			    foreach($key[$keys[$i]] as $name => $var) { // iteration over all inner values in 2D array '$key'
			        
			        if ($name === 'form') { // we are checking only 'form' attributes, to avoid duplicity
			        	
			        	$p = $key[$keys[$i]]['form'];


			        	
			        	preg_match($p, $value, $result); // evaluating the RexEx 
			        	
			        	if (!empty($result[0])) { // continue only if found match in the array
							
							$found = "1"; 
							if ($key[$keys[$i]]['was'] == true) { // check for multiple same arguments
								file_put_contents('php://stderr', "Bad argument(s). Try --help\n");
								exit(1);
							}
							else $key[$keys[$i]]['was'] = true; // if first occurence (and only possible), note it 

							
							if (($keys[$i] === 'query') || ($keys[$i] === 'qf')) { 
									// 'query' and 'qf' arguments cannot be together
								if ($q == true) {
									file_put_contents('php://stderr', "Bad argument(s). Try --help\n");
									exit(1);
								}
								else $q = true;

							}

							$right = "";
							if (!empty($result[1])) { // if arguments has right side (after =), assign it to the variable 
								$right = $result[1];
							}

							unset($result);

							if ($keys[$i] === 'input') { 
								/*if (strpos($right, ' ') !== false) {
 									$right = "\"" . $right . "\"";
								}*/
								if ((is_readable($right) == true) && (is_file($right) == true)) {
									$query_array['input'] = $right;
								}
								else {
									file_put_contents('php://stderr', "Cannot open file\n");
									exit(2);
								}
							}
							if ($keys[$i] === 'qf') {
								$key[$keys[$i]]['right'] = $right;
							}
							if ($keys[$i] === 'query') {
								$key[$keys[$i]]['right'] = $right;
							}

							if ($keys[$i] === 'root') {
								$query_array['root'] = $right;
							}

							if ($keys[$i] === 'header') {
								$query_array['isheader'] = false;
							}

							if ($keys[$i] === 'output') {
								$query_array['output'] = $right;
							}

							
						}
			        }
			        
			    }
			    if ($found === "1") { // if program finds the value, stops checking other values in array
			    	break;
			    }
			}
			if ($found === "0") { // if argument is not any of the values in '$key' array, it is invalid
		    	file_put_contents('php://stderr', "Bad argument(s). Try --help\n");
				exit(1);
			}

			$i++;
		}
		if ($q == false) {
			$query = "no-query";
		}

		// control if file in qf is valid
		
		if ($key['qf']['was'] === true) {
			echo ($key['qf']['right']);
			if (!$key['qf']['right']) {
				$query = "no-query";
			}
			elseif ((is_readable($key['qf']['right']) == true) && (is_file($key['qf']['right']) == true)) {
				
				$query = file_get_contents($key['qf']['right']);
			}
			else {				
				file_put_contents('php://stderr', "Cannot open file\n");
				exit(2);
			}
		}

		if ($key['query']['was'] === true) {
			if (!$key['query']['right']) {
				$query = "no-query";
			}
			else 
				$query = $key['query']['right'];
		}

		if (($key['qf']['right'] == "no-query") || ($key['query']['right'] == "no-query")) {
			$query = "no-query";
		} 		

	}

// function that analyses WHERE clause from query

	function where_clause($token) {
		
		global $query_array; // reference to global variable
		global $rightside;

		$condition = ""; // string that stores WHERE condition

		$delim = " \n\t"; // delimiters in WHERE clause

		if ($token === 'NOT') { // if first word in WHERE clause is NOT, we will make a note of it
			$query_array['not'] = "found";
			$token = strtok($delim);
		}

		$operations = array( // available operations in WHERE clause
			"CONTAINS" => "/^(.*)CONTAINS(.*)/",
			"=" => "/^(.*)=(.*)/",
			">" => "/^(.*)>(.*)/",
			"<" => "/^(.*)<(.*)/",
			);

		
		$flag = false;

		while (($token !== false) && ($token != 'ORDER')) { // cycle that fills variable 'condition' with whole WHERE clause
			$condition .= $token;
			if ($flag) {
				$rightside .= " " . $token;
			}
			if (($token === "=") || ($token === ">") || ($token === "<") || ($token === "CONTAINS")) {
				$flag = true;
			}

			

			$token = strtok($delim);
		}
		$rightside = substr($rightside, 1); // deleting starting space from variable

		$i = 0;

		foreach ($operations as $key => $value) { // checking for operations in array
			preg_match($value, $condition, $result);
			if (isset($result[0])) {
				if (isset($result[2]))
					$lit = $result[2];
				break;
			}
			else {
				$i++;
			}
		}

		if ($i == 4) { // if there is invalid operation
			file_put_contents('php://stderr', "ABad Query Syntax.\n");
			exit(80);
		}

		$myArray = explode('.', $result[1]); // parse name of the element(with attributes)


		// regular expression for determining all valid XML tag names(copied from official XML documentation)
		$allowedxml = '~^[:A-Z_a-z\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\x{2FF}\\x{370}-\\x{37D}\\x{37F}-\\x{1FFF}\\x{200C}-\\x{200D}\\x{2070}-\\x{218F}\\x{2C00}-\\x{2FEF}\\x{3001}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFFD}\\x{10000}-\\x{EFFFF}][:A-Z_a-z\\xC0-\\xD6\\xD8-\\xF6\\xF8-\\x{2FF}\\x{370}-\\x{37D}\\x{37F}-\\x{1FFF}\\x{200C}-\\x{200D}\\x{2070}-\\x{218F}\\x{2C00}-\\x{2FEF}\\x{3001}-\\x{D7FF}\\x{F900}-\\x{FDCF}\\x{FDF0}-\\x{FFFD}\\x{10000}-\\x{EFFFF}.\\-0-9\\xB7\\x{0300}-\\x{036F}\\x{203F}-\\x{2040}]*$~u';


		unset($result);

		// checking if element and attribute are valid XML tag names
		if (!isset($myArray[0])) {
 			$myArray[0] = null;
		}
		if (!isset($myArray[1])) {
 			$myArray[1] = null;
		}

		preg_match($allowedxml, $myArray[0],$result);
		if (!isset($result[1])) {
 			$result[1] = null;
		}
		if (!isset($result[2])) {
 			$result[2] = null;
		}
		if (($result[1] != "") || ($result[2] != "")) {
			file_put_contents('php://stderr', "BBad Query Syntax.\n");
			exit(80);
		}
		unset($result);
		preg_match($allowedxml, $myArray[1],$result);
		if (!isset($result[1])) {
 			$result[1] = null;
		}
		if (!isset($result[2])) {
 			$result[2] = null;
		}
		if (($result[1] != "") || ($result[2] != "")) {
			file_put_contents('php://stderr', "CBad Query Syntax.\n");
			exit(80);
		}


		$query_array['attribute'] = $myArray[1];
		$query_array['element'] = $myArray[0];
		$query_array['operator'] = $key;

		if (((is_int($lit)) && ($lit >= 0)) || // if literal in WHERE clause in valid number
    	 ((is_numeric($lit)) && ($lit >= 0) && ((floatval($lit)) == (intval($lit))))) {
    		 if ($query_array['operator'] === "CONTAINS") {
    			 file_put_contents('php://stderr', "DBad Query Syntax.\n");
				 exit(80);
    		 }
    		$query_array['literal'] = $lit;
    		$query_array['literal_type'] = "number";
    	}

    	// checking if literal is valid string
    	elseif (($lit[0] == '"') && ($lit[strlen($lit)-1] == '"') && (strlen($lit) > 1)) {
    		$query_array['literal'] = $lit;
    		$query_array['literal_type'] = "string";
    	}	
    	else {
    		file_put_contents('php://stderr', "EBad Query Syntax.\n");
			exit(80);
    	}
	}

// this function parses query into array

	function parse_query($query) {
		
		$i = 1;

		$delim = " \n\t"; // delimiters for original query
		$delim_from = "."; // delimiter for element.attribute

		global $query_array;
		global $keywords;
		$problem = false;

		$token = strtok($query, $delim); // parsing query to tokens

		while ($token != "") { // while not end of query

		    if (($i == 1) && ($token != "SELECT")) { // first must be SELECT
		    	file_put_contents('php://stderr', "FBad Query Syntax.\n");
				exit(80);
		    }

		    elseif ($i == 2) { // second must be name of element
		    	//echo ("token: " . $token . "\n");
		    	foreach ($keywords as $value) {
					if ($problem == true) {
						file_put_contents('php://stderr', "GBad Query Syntax.\n");
						exit(80);
					}
					if ($value == $token)
						$problem = true;
				}
		    	$query_array['searched'] = $token;
		    }

		    // third is optional LIMIT with a number
		    elseif (($i == 3) && (($token != "LIMIT") && ($token != "FROM"))) {
		    	file_put_contents('php://stderr', "HBad Query Syntax.\n");
				exit(80);
		    }

		    elseif (($i == 3) && ($token === "LIMIT")) {
		    	$token = strtok($delim);
		    	if (((is_int($token)) && ($token >= 0)) ||
		    	 ((is_numeric($token)) && ($token >= 0) && ((floatval($token)) == (intval($token))))) {
		    		$query_array['limit'] = $token;
		    	}
		    	else {
		    		file_put_contents('php://stderr', "IBad Query Syntax.\n");
					exit(80);
		    	}
		    	$i++;
		    }

		    // with or without LIMIT, FROM must be next, with element with optional attribute, or only attribute
		    elseif (($i == 3) || ($i == 5)) {
		    	if ($token != 'FROM') {
		    		file_put_contents('php://stderr', "JBad Query Syntax.\n");
					exit(80);
		    	}
		    	else {
		    		if (($i == 5) && ($query_array['limit'] == "")) {
			    		file_put_contents('php://stderr', "KBad Query Syntax.\n");
						exit(80);
			    	}
			    	else {
			    		$i = 6; // for making it easy later
			    		$token = strtok($delim);
			    		if ($token === 'ROOT') {
			    			$query_array['from'] = "ROOT";
			    		}
			    		elseif ($token === 'WHERE') {
			    			file_put_contents('php://stderr', "LBad Query Syntax.\n");
							exit(80);
			    		}
			    		elseif ($token == false) {
			    			$query_array['from'] = "";
			    		}
			    		else {
							$myArray = explode('.', $token);
							if (isset($myArray[1])) {
								$query_array['fattribute'] = $myArray[1];
							}
							if (isset($myArray[0])) {
								$query_array['from'] = $myArray[0];
							}
			    		}
			    	}
		    	}
		    }

		    // after FROM there must be WHERE, which is implemented in separate function
		    elseif (($i == 7) && ($token === 'WHERE')) {
		    	$token = strtok($delim);
		    	
		    	where_clause($token);
		    	
		    	$i++;	
		    }
		    
		    $token = strtok($delim);
		    $i++;		    
		}
		if ($i == 3) {
			file_put_contents('php://stderr', "MBad Query Syntax.\n");
			exit(80);
		}

	}


	// function that handles writing to output file, or stdout

	function write_xml($what, $file)
	{
		if (file_exists($file)) {
			if ((is_writable($file) == true) && (is_file($file) == true)) {
				$output = fopen($file, "w");
				fwrite($output, $what);
				fclose($output);
			}
			else {
				file_put_contents('php://stderr', "Cannot open file");
				exit(3);
			}
		}
		else {
			$output = fopen($file, "w");
			fwrite($output, $what);
			fclose($output);
		}

	}


	check_parameters($argv,$argc);
	$outputxml = "";

	//echo ($query);
	// if there is empty query, on output there will be empty file (optionally with header and root element)
	if ($query === "no-query") {
		$outputxml = "";

		if ($query_array['root']) {
		    $outputxml = (
		        "<" . $query_array['root'] . ">\n"
		            . $outputxml .
		        "\n</" . $query_array['root'] . ">"
		    );
		}

		if ($query_array['isheader']) {
		    $outputxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" . $outputxml;
		}

		if ($query_array['output']) {
		    write_xml($outputxml,$query_array['output']);
		} 
		else {
		    file_put_contents("php://stdout", $outputxml);
		}
		exit(0);
	}

	parse_query($query);

	// if 'from' is missing, on output there will be empty file (optionally with header and root element)

	if (($query_array['from'] == "") && ($query_array['fattribute'] == "")) {
		$outputxml = "";

		if ($query_array['root']) {
		    $outputxml = (
		        "<" . $query_array['root'] . "/>\n"
		        );
		}

		if ($query_array['isheader']) {
		    $outputxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" . $outputxml;
		}

		if ($query_array['output']) {
		    write_xml($outputxml,$query_array['output']);
		} 
		else {
		    file_put_contents("php://stdout", $outputxml);
		}
		exit(0);
	}

	foreach ($keywords as $value) {
		if ($problem) {
			file_put_contents('php://stderr', "NBad Query Syntax.\n");
			exit(80);
		}
		if (($query_array['from'] === $value) && ($value === 'ROOT')) {

		}
		elseif (($query_array['root'] === $value) || ($query_array['searched'] === $value) ||
		   ($query_array['from'] === $value) || ($query_array['fattribute'] === $value) ||
		   ($query_array['element'] === $value) || ($query_array['attribute'] === $value)){
				$problem = true;
		}
	}

	$xml_file = null;

	if ($query_array['input'] == "") { // if there is missing input, we will read from stdin
		$query_array['input'] = "php://stdin";
		//$xml_file = file_get_contents($query_array['input']);
		$xml_file = @simplexml_load_file($query_array['input']); // load xml file to variable
		if ($xml_file === false) {
			file_put_contents('php://stderr', "Invalid XML file.\n");
			exit(4);
		}
		
	}
	else {


		$file = $query_array['input'];
		// echo $file;
		if (file_exists($file)) {
		    $xml_file = @simplexml_load_file($file); // load xml file to variable
		    if ($xml_file === false) {
				file_put_contents('php://stderr', "Invalid XML file.\n");
				exit(4);
			}
		} 
		else {
		    file_put_contents('php://stderr', "Cannot open file.\n");
			exit(2);
		}
	}
	

	$result = null;
	// options for reading from variable, that stores xml file, there are all possible options for element.attribute combinations
	if ($query_array['from'] == "ROOT") {
		$query_array['from'] = "*";
	}

	if (($query_array['from'] != "") && ($query_array['fattribute'] != "")) {
		if (($query_array['element'] != "") && ($query_array['attribute'] != "")) {
			$result = $xml_file->xpath("//" . $query_array['from'] . "[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "[" . $query_array['element'] . "[@" . $query_array['attribute'] . "]]");
		}
		elseif (($query_array['element'] != "") && ($query_array['attribute'] == "")) {
			$result = $xml_file->xpath("//" . $query_array['from'] . "[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "[" . $query_array['element'] . "]");
		}
		elseif (($query_array['element'] == "") && ($query_array['attribute'] != "")) {
			$result = $xml_file->xpath("//" . $query_array['from'] . "[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "/*[@" . $query_array['attribute'] . "]");
		}
		elseif (($query_array['element'] == "") && ($query_array['attribute'] == "")) {
			$result = $xml_file->xpath("//" . $query_array['from'] . "[@" . $query_array['fattribute'] . "]//" . $query_array['searched']);
		}
	}
	elseif (($query_array['from'] != "") && ($query_array['fattribute'] == "")) {
		if ($query_array['from'] == '*') {
			if (($query_array['element'] != "") && ($query_array['attribute'] != "")) {
				$result = $xml_file->xpath("//" . $query_array['searched'] . "[" . $query_array['element'] . "[@" . $query_array['attribute'] . "]]");
			}
			elseif (($query_array['element'] != "") && ($query_array['attribute'] == "")) {
				$result = $xml_file->xpath("//" . $query_array['searched'] . "[" . $query_array['element'] . "]");
			}
			elseif (($query_array['element'] == "") && ($query_array['attribute'] != "")) {
				$result = $xml_file->xpath("//" . $query_array['searched'] . "[@" . $query_array['attribute'] . "]");
			}
			elseif (($query_array['element'] == "") && ($query_array['attribute'] == "")) {
				$result = $xml_file->xpath("//" . $query_array['searched']);
			}
		}
		else {
			if (($query_array['element'] != "") && ($query_array['attribute'] != "")) {
				$result = $xml_file->xpath("//" . $query_array['from'] . "//" . $query_array['searched'] . "[" . $query_array['element'] . "[@" . $query_array['attribute'] . "]]");
			}
			elseif (($query_array['element'] != "") && ($query_array['attribute'] == "")) {
				$result = $xml_file->xpath("//" . $query_array['from'] . "//" . $query_array['searched'] . "[" . $query_array['element'] . "]");
			}
			elseif (($query_array['element'] == "") && ($query_array['attribute'] != "")) {
				$result = $xml_file->xpath("//" . $query_array['from'] . "//" . $query_array['searched'] . "[@" . $query_array['attribute'] . "]");
			}
			elseif (($query_array['element'] == "") && ($query_array['attribute'] == "")) {
				$result = $xml_file->xpath("//" . $query_array['from'] . "//" . $query_array['searched']);
			}
		}		
		
	}
	elseif (($query_array['from'] == "") && ($query_array['fattribute'] != "")) {
		if (($query_array['element'] != "") && ($query_array['attribute'] != "")) {
			$result = $xml_file->xpath("//*[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "[" . $query_array['element'] . "[@" . $query_array['attribute'] . "]]");
		}
		elseif (($query_array['element'] != "") && ($query_array['attribute'] == "")) {
			$result = $xml_file->xpath("//*[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "[" . $query_array['element'] . "]");
		}
		elseif (($query_array['element'] == "") && ($query_array['attribute'] != "")) {
			$result = $xml_file->xpath("//*[@" . $query_array['fattribute'] . "]//" . $query_array['searched'] . "/*[@" . $query_array['attribute'] . "]");
		}
		elseif (($query_array['element'] == "") && ($query_array['attribute'] == "")) {
			$result = $xml_file->xpath("//*[@" . $query_array['fattribute'] . "]//" . $query_array['searched']);
		}
	}

	exit(0);
	// if literal is string, we must trim quotation marks for future comparison
	if ($query_array['literal_type'] === "string") {
		$rightside = substr($rightside, 1);
		$rightside = substr($rightside, 0,-1);
	}

	// from all valid elements from xml file, we choose those that match condition in WHERE clause
	if ($result != null) {
		foreach ($result as $value) {
			if (($query_array['attribute'] != "") && ($query_array['element'] != "")){
				$attr = (string)$value->$query_array['element']->attributes();
				if ($query_array['operator'] === "CONTAINS") {
					$string = (string)$value->$query_array['element'];
					if (strpos($string, $rightside) !== false) {
	 					if (strpos($attr, $rightside) !== false) {
		 					if ($query_array['not'] == "not found") {
		 						$newresult[] = $value;
		 					}
						}
						else {
							if ($query_array['not'] == "found") {
		 						$newresult[] = $value;
		 					}
						}	
					}
				}
				elseif ($query_array['operator'] == "=") {
					if ($attr === $rightside) {
						if ($query_array['not'] == "not found") {
		 					$newresult[] = $value;
		 				}
					}
					else {
						if ($query_array['not'] == "found") {
		 					$newresult[] = $value;
		 				}
					}
				}
				elseif ($query_array['operator'] == "<") {
					if ($query_array['literal_type'] === "number") {
						if ($attr < $rightside) {
							if ($query_array['not'] == "not found") {
			 					$newresult[] = $value;
			 				}
						}
						else {
							if ($query_array['not'] == "found") {
			 					$newresult[] = $value;
			 				}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($attr, $rightside) < 0) {
							if ($query_array['not'] == "not found") {
			 					$newresult[] = $value;
			 				}
						}
						else {
							if ($query_array['not'] == "found") {
			 					$newresult[] = $value;
			 				}
						}
					}
				}
				elseif ($query_array['operator'] == ">") {
					if ($query_array['literal_type'] === "number") {
						if ($attr > $rightside) {
							if ($query_array['not'] == "not found") {
			 					$newresult[] = $value;
			 				}
						}
						else {
							if ($query_array['not'] == "found") {
			 					$newresult[] = $value;
			 				}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($attr, $rightside) > 0) {
							if ($query_array['not'] == "not found") {
			 					$newresult[] = $value;
			 				}
						}
						else {
							if ($query_array['not'] == "found") {
			 					$newresult[] = $value;
			 				}
						}
					}
				}
			}
			elseif (($query_array['attribute'] != "") && ($query_array['element'] == "")){
				$attr = (string)$value->attributes();
				if ($query_array['operator'] === "CONTAINS") {
					if (strpos($attr, $rightside) !== false) {
	 					if ($query_array['not'] == "not found") {
	 						$newresult[] = $value;
	 					}
					}
					else {
						if ($query_array['not'] == "found") {
	 						$newresult[] = $value;
	 					}
					}
				}
				elseif ($query_array['operator'] == "=") {
					if ($attr === $rightside) {
						if ($query_array['not'] == "not found") {
	 						$newresult[] = $value;
	 					}
					}
					else {
						if ($query_array['not'] == "found") {
	 						$newresult[] = $value;
	 					}
					}
				}
				elseif ($query_array['operator'] == "<") {
					if ($query_array['literal_type'] === "number") {
						if ($attr < $rightside) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($attr, $rightside) < 0) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
				}
				elseif ($query_array['operator'] == ">") {
					if ($query_array['literal_type'] === "number") {
						if ($attr > $rightside) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($attr, $rightside) > 0) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
				}
			}
			elseif (($query_array['attribute'] == "") && ($query_array['element'] != "")){
				$string = (string)$value->$query_array['element'];
				if ($query_array['operator'] === "CONTAINS") {
					if (strpos($string, $rightside) !== false) {
		 				if ($query_array['not'] == "not found") {
	 						$newresult[] = $value;
	 					}
					}
					else {
						if ($query_array['not'] == "found") {
	 						$newresult[] = $value;
	 					}
					}
				}
				elseif ($query_array['operator'] == "=") {
					if ($string === $rightside) {
						if ($query_array['not'] == "not found") {
	 						$newresult[] = $value;
	 					}
					}
					else {
						if ($query_array['not'] == "found") {
	 						$newresult[] = $value;
	 					}
					}
				}
				elseif ($query_array['operator'] == "<") {
					if ($query_array['literal_type'] === "number") {
						if ($string < $rightside) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($string, $rightside) < 0) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
				}
				elseif ($query_array['operator'] == ">") {
					if ($query_array['literal_type'] === "number") {
						if ($string > $rightside) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
					elseif ($query_array['literal_type'] === "string") {
						if (strcmp($string, $rightside) > 0) {
							if ($query_array['not'] == "not found") {
	 							$newresult[] = $value;
	 						}
						}
						else {
							if ($query_array['not'] == "found") {
	 							$newresult[] = $value;
	 						}
						}
					}
				}
			}
			elseif (($query_array['from'] == "") && ($query_array['fattribute'] != "")){
				$newresult[] = $value;
				break;
			}
			elseif (($query_array['attribute'] == "") && ($query_array['element'] == "")){
				$newresult[] = $value;
				// break;
			}


		}
	}

	// if there was LIMIT in query, we only print that many elements as stated in LIMIT
	if ($newresult) {
		if ($query_array['limit'] != "") {
			foreach ($newresult as $key => $value) {
				if ($key < $query_array['limit']) {
					$outputxml .= $value->asXML();
					$outputxml .= "\n"; 
				}
				else {
					break;
				}
			}
		}
		else {
			foreach ($newresult as $key => $value) {
				$outputxml .= $value->asXML();
				$outputxml .= "\n"; 
			}
		}
	}

    if ($query_array['root']) { // optional root element
        $outputxml = (
            "<" . $query_array['root'] . ">\n"
                . $outputxml .
            "\n</" . $query_array['root'] . ">"
        );
    }

    if ($query_array['isheader']) { // optional header
        $outputxml = "<?xml version=\"1.0\" encoding=\"utf-8\"?>\n" . $outputxml;
    }

    if ($query_array['output']) { // printing to output
        write_xml($outputxml,$query_array['output']);
    } else {
        file_put_contents("php://stdout", $outputxml);
    }

?>
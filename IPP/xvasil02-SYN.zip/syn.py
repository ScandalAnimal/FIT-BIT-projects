#!/usr/bin/python

#SYN:xvasil02

import sys
import re
import os
import codecs
import fileinput

# these arrays contains info about command line parameters
arguments = {'input' : False, 'output' : False, 'format' : False, 'br' : False} 
files = {'input_file' : None, 'output_file' : None, 'format_file' : None}
# in these arrays we add values from dormat file
format_regex = []
format_reaction = []

# this function checks command line arguments validity and adds values to corresponding arrays above
def checkArguments(arguments):

    if len(sys.argv) == 1:
        return
    elif sys.argv[1] == "-help" or sys.argv[1] == "--help":
        if len(sys.argv) != 2:
            sys.stderr.write("Bad argument(s). Try --help")
            sys.exit(1)
        else:
            sys.stdout.write("HELP\n"
            "Program Usage: "
            "python3 syn.py {parameters}\n\n"
            "Parameters can be:\n"
            "--help             Prints help page, can be used only as single parameter\n"
            "--input=filename   Sets input file in UTF-8 encoding, if not provided, stdin\n"
            "--output=filename  File in UTF-8 to store results, if not provided, set to stdout\n"
            "--format=filename  File that stores information about formatting rules\n"
            "--br               Adds <br /> to the end of every line in output\n\n"

            "*filename can be specified as absolute or relative path\n\n"

            "Format file line example:\n"
            "<regular expression><one or more tabs><list of formatting commands>")
            sys.exit(0)
    for arg in sys.argv: # valid arguments are input, output, format and br
        if sys.argv[0] != arg:
            match = re.search("^-{1,2}input=(.*)$", arg)
            if match:
                if arguments['input'] != False:
                    sys.stderr.write("Bad argument(s). Try --help")
                    sys.exit(1)
                else:
                    arguments['input'] = arg.split("=")[1]
            else:
                match = re.search("^-{1,2}output=(.*)$", arg)
                if match:
                    if arguments['output'] != False:
                        sys.stderr.write("Bad argument(s). Try --help")
                        sys.exit(1)
                    else:
                        arguments['output'] = arg.split("=")[1]
                else:
                    match = re.search("^-{1,2}format=(.*)$", arg)
                    if match:
                        if arguments['format'] != False:
                            sys.stderr.write("Bad argument(s). Try --help")
                            sys.exit(1)
                        else:
                            arguments['format'] = arg.split("=")[1]
                    else:
                        match = re.search("^-{1,2}br$", arg)
                        if match:
                            if arguments['br'] != False:
                                sys.stderr.write("Bad argument(s). Try --help")
                                sys.exit(1)
                            else:
                                arguments['br'] = True
                        else:
                            sys.stderr.write("Bad argument(s). Try --help")
                            sys.exit(1)

# this function check, if files that script gets from cmd line are valid, and tries to open and read from them
def checkFileExistence(arguments,files):

    if arguments['input'] != False:
        if os.path.isfile(arguments['input']) == False: # if we got input file, that is not a file, throws error
            sys.stderr.write("Nonexistent input\n")
            sys.exit(2)
        else:
            try:
                files['input_file'] = codecs.open(arguments['input'],'r','utf-8').read() # throw error if cannot read from file
            except:
                sys.stderr.write("Cannot open input file\n")
                sys.exit(2)
    if arguments['output'] != False:
        try:
            files['output_file'] = codecs.open(arguments['output'], 'w+', 'utf-8')
        except:
            sys.stderr.write("Cannot open output file\n") # throw error when cannot write to output file
            sys.exit(3)
    if arguments['format'] != False:
        try:
            files['format_file'] = codecs.open(arguments['format'], 'r', 'utf-8').read() # if cannot read from format file, just copies input to output
        except:
            writeToFile(files)
            sys.exit(0)

    if arguments['input'] == False: # if input not given, reads from stdin
        files['input_file'] = sys.stdin.read()

# function that read formats from format file and adds values to arrays
def getFormats(files,format_regex,format_reaction):
    content = files['format_file']
    content = re.sub('\\n+', '\\n', content)

    while len(content) > 0: # while cycle through whole file
        pos_t = content.find('\t')  # divide by tabulator, we store position of tab in variable pos_t
        pos_n = content.find('\n') # we store position of newline in variable pos_n
        format_regex.append(content[0:pos_t]) # we add string from start of line to pos_t to array of regexes
        if pos_n == -1:
            format_reaction.append(content[pos_t + 1:])
            content = ''
        else:
            format_reaction.append(content[pos_t + 1:pos_n]) # we add string from pos_t to pos_n to array of html tags 
            content = content[pos_n + 1:]

    index = 0
    for value in format_reaction: # we have to take care of multiple tabulators as dividers, we delete all of them
        value = value.replace('\t', '').replace('\r', '').replace('\n', '')
        format_reaction[index] = value
        index = index + 1
    index = 0
    for value in format_regex: # we have to take care of multiple tabulators as dividers, we delete all of them
        value = value.replace('\t', '').replace('\r', '').replace('\n', '')
        format_regex[index] = value
        index = index + 1


# this function checks if formatting tags in format file are valid
def checkFormats(formats):
    for style in formats:
        params = style.split(',') # divide by dash
        for param in params:
            param = param.replace(' ','') # delete all spaces
            
            if param == "bold": # bold, italic, underline and teletype are valid
                continue
            elif param == "italic":
                continue
            elif param == "underline":
                continue
            elif param == "teletype":
                continue
            else:
                match = re.search("^size:(.*)", param) # size:(number) is valid
                if match:
                    left = param.split(':')[0]
                    right = param.split(':')[1]
                    try:
                        int(right,10) # number has to be decimal
                    except:
                        sys.stderr.write("Error in format file A\n")
                        sys.exit(4)
                    if int(right,10) <= 0: # number has to be bigger or equal than zero
                        sys.stderr.write("Error in format file B\n")
                        sys.exit(4)
                else:
                    match = re.search("^color:(.*)", param) # color:(6 hexa numbers) is valid
                    if match:
                        left = param.split(':')[0]
                        right = param.split(':')[1]
                        try:
                            int(right, 16) # number has to be hexa decimal
                        except:
                            sys.stderr.write("Error in format file C\n")
                            sys.exit(4)
                    else:
                        sys.stderr.write("Error in format file D\n")
                        sys.exit(4)

# this function determines, what tags to insert and where
def determineStyle(x, styles):
    params = styles.split(',')
    start = 0
    end = len(x)
    for param in params:
        param = param.replace(' ','') # delete all spaces
        if param == "bold":
            x = x[:start] + "<b>" + x[start:end] + "</b>" + x[end:]
            start = start + 3
            end = end + 3
        elif param == "italic":
            x = x[:start] + "<i>" + x[start:end] + "</i>" + x[end:]
            start = start + 3
            end = end + 3
        elif param == "underline":
            x = x[:start] + "<u>" + x[start:end] + "</u>" + x[end:]
            start = start + 3
            end = end + 3
        elif param == "teletype":
            x = x[:start] + "<tt>" + x[start:end] + "</tt>" + x[end:]
            start = start + 4
            end = end + 4
        else:
            match = re.search("^size:(.*)", param)
            if match:
                left = param.split(':')[0]
                right = param.split(':')[1]
                try:
                    int(right,10)
                except:
                    sys.stderr.write("Error in format file E\n")
                    sys.exit(4)
                if int(right,10) <= 0:
                    sys.stderr.write("Error in format file F\n")
                    sys.exit(4)
                x = x[:start] + "<font size=" + right + ">" + x[start:end] + "</font>" + x[end:]
                start = start + 12 + len(right)
                end = end + 12 + len(right)
            else:
                match = re.search("^color:(.*)", param)
                if match:
                    left = param.split(':')[0]
                    right = param.split(':')[1]
                    try:
                        int(right, 16)
                    except:
                        sys.stderr.write("Error in format file G\n")
                        sys.exit(4)
                    x = x[:start] + "<font color=#" + right + ">" + x[start:end] + "</font>" + x[end:]
                    start = start + 20
                    end = end + 20
                else:
                    sys.stderr.write("Error in format file H\n")
                    sys.exit(4)
    return x

# this function iterates over all regexes in format file and changes them to Python notation 
def changeRegex(original):
    i = 0
    result = ""
    if original[0] == '.' or original[0] == '|':
        sys.stderr.write("Error in format file I\n")
        sys.exit(4)
    if original == "()" or original == "!" or original == "(())":
        sys.stderr.write("Error in format file J\n")
        sys.exit(4)
    if (original[len(original)-1] == "!" or original[len(original)-1] == "(" or original[len(original)-1] == "|" or original[len(original)-1] == ".") and original[len(original)-2] != "%":
        sys.stderr.write("Error in format file K\n")
        sys.exit(4)

    left = right = 0
    first = False
    before = ""
    for c in original:
        if c == "(":
            if before == "%":
                continue
            if first == False:
                first = True
            left += 1
        elif c == ")":
            if before == "%":
                continue
            if first == False:
                sys.stderr.write("Error in format file L\n")
                sys.exit(4)    
            right += 1
        before = c

    if left != right:
        sys.stderr.write("Error in format file M\n")
        sys.exit(4)        

    for i in range(len(original)):
        character = original[i]
        if len(original) == 1: # if regex is only one character, we return it
            result = character
            break
        elif character == '.' and original[i-1] == '.':
            sys.stderr.write("Error in format file N\n")
            sys.exit(4)
        elif character == '|' and original[i-1] == '|':
            sys.stderr.write("Error in format file O\n")
            sys.exit(4)
        elif character == '.' and original[i-1] == '|':
            sys.stderr.write("Error in format file P\n")
            sys.exit(4)
        elif character == '|' and original[i-1] == '.':
            sys.stderr.write("Error in format file Q\n")
            sys.exit(4)
        elif character == '.' and original[i-1] == '!':
            sys.stderr.write("Error in format file R\n")
            sys.exit(4)
        elif character == '|' and original[i-1] == '!':
            sys.stderr.write("Error in format file S\n")
            sys.exit(4)
        elif character == '!' and original[i-1] == '!':
            sys.stderr.write("Error in format file T\n")
            sys.exit(4)
        elif character == '*' and original[i-1] == '!':
            sys.stderr.write("Error in format file U\n")
            sys.exit(4)
        elif character == '.' and original[i-1] != '%' and i > 0:
            character = ""
        elif character == '!' and original[i-1] != '%':
            inside = ''
            if original[i+1] == '(':
                char = original[i+1]    
                iterator = 0
                while char != ')':
                    inside = inside + char
                    iterator = iterator + 1
                    char = original[i+1+iterator]
                inside = inside + char
                result = result + '[^' + inside + "]"
            elif original[i+1] == '%':
                result = result + '[^' + "\\" + original[i+2] + "]"
            else:
                result = result + '[^' + original[i+1] + "]"
            character = "^"
        elif character == '%' and original[i-1] == '!':
            continue
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'a':
            result = result + '.'
            character = '.'
        elif character == '+' and original[i-1] != '%':
            result = result + character
        elif character == '%' and original[i-1] != '%' and (original[i+1] == 't' or original[i+1] == 'n' or original[i+1] == 's'):
            result = result + "\\"
            character = "\\"
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'd':
            result = result + '[0-9]'
            character = "["
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'l':
            result = result + '[a-z]'
            character = "["
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'L':
            result = result + '[A-Z]'
            character = "["
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'w':
            result = result + '[a-zA-Z]'
            character = "["
        elif character == '%' and original[i-1] != '%' and original[i+1] == 'W':
            result = result + '[a-zA-Z0-9]'
            character = "["
        elif character == '%' and original[i-1] != '%' and (original[i+1] == '.' or original[i+1] == '|' or original[i+1] == '!'
          or original[i+1] == '*' or original[i+1] == '+' or original[i+1] == '('
          or original[i+1] == ')' or original[i+1] == '%'):
            result = result + '\\'
            character = "\\"
        elif character == '%' and i == 0:
            result = result + '\\'
            character = "\\"
        elif character == '"' and original[i-1] == "!":
            continue
        elif (character == 'W' or character == 'w' or character == 'L' or character == 'l' or character == 'd' or character == 'a' or character == 'n') and (original[i-1] == '%' or original[i-1] == '!'):
            continue
        elif character == 's' and original[i-1] == '%' and original[i-2] == '!':
            continue
        elif character == "\\":
            result = result + '\\\\'
        elif character == '[' or character == ']' or character == '^' or character == '$' or character == '{' or character == '}' or character == '?':
            result = result + '\\' + character
        else:
            result = result + character

        # in some regexes has we have to exclude some characters explicitly , for instance <,>
    if result == ".+":
        result = "(?s).+"
    elif result == "..+":
        result = "(?s)..+"
    elif result == ".*":
        result = "(?s).*"
    elif result == "..*":
        result = "(?s)..*"
    if result == "[^\s]":
        result = "[^\s<>]"
    # print("Result: ",result)
    return result

# this function handles writing output to file or stdout, and also inserts breakline tag, if needed
def writeToFile(files):
    if arguments['br'] != False:
        files['input_file'] = files['input_file'].replace("\n","<br />\n")
    if files['output_file'] != None:
        files['output_file'].write(files['input_file'])
    else:
        sys.stdout.write(files['input_file'])

# in this function we delete all tags from existing file, and remember their positions in an array for future re-inserting
def trimString(files,trimmed,tags,pos):
    
    tag = False
    z = 0
    last = -1
    for c in files['input_file']: # iteration over string
        if tag == False and c == ">":
            continue
        if c == "<":
            tag = True
            tags.append(c) # we insert tag to array
            pos.append(z) # we remember tag position
            trimmed = trimmed + files['input_file'][last+1:z] # we delete tag from string
            last = z
        elif c == ">":
            tag = False
            tags.append(c)
            pos.append(z)
            last = z
        else:
            if tag == True:
                tags.append(c)
                pos.append(z)
                last = z
            else:
                tags.append(" ")
        z = z + 1
    trimmed = trimmed + files['input_file'][last+1:z]
    return (files['input_file'],trimmed,tags,pos)

# this function adds tags to string position of inserted tags is determined by 2 arrays, "pos" and "before_pos"
def addTags(trimmed,tags,pos,before_tags,before_pos):
    index = 0
    string = ""
    inserted_pos = 0
    inserted_bef = 0
    last_inserted = "before"
    while True:
        if index == len(trimmed) + len(pos) + len(before_pos):
            break
        if last_inserted == "before":
            if index-inserted_pos in before_pos:
                string = string + before_tags[index-inserted_pos]
                inserted_bef += 1
                last_inserted = "before"
            elif index-inserted_bef in pos:
                string = string + tags[index-inserted_bef]
                inserted_pos += 1
                last_inserted = "new"
            else:
                string = string + trimmed[index-inserted_bef-inserted_pos]
            index = index + 1
        else:
            if index-inserted_bef in pos:
                string = string + tags[index-inserted_bef]
                inserted_pos += 1
                last_inserted = "new"
            elif index-inserted_pos in before_pos:
                string = string + before_tags[index-inserted_pos]
                inserted_bef += 1
                last_inserted = "before"
            else:
                string = string + trimmed[index-inserted_bef-inserted_pos]
            index = index + 1

    return string
    

checkArguments(arguments)
checkFileExistence(arguments,files)
getFormats(files,format_regex,format_reaction)
checkFormats(format_reaction)

files['input_file'] = files['input_file'].replace("<","&lt").replace(">","&gt")

ln = 0
i = 0
before_tags = []
before_pos = []
# we iterate over all regexes, that has to be highlighted in text
while i < len(format_regex):
    if format_regex[i] == "!%a": # this regex does not match any string
        i = i + 1
        continue
    try:
        p = re.compile(changeRegex(format_regex[i])) # we find all matches of regex in text, and assign them to variable p
    except re.error:
        sys.stderr.write("Error in format file V\n")
        sys.exit(4)
    
    tags = []
    pos = []
    trimmed = ""
    
    files['input_file'],trimmed,tags,pos = trimString(files,trimmed,tags,pos)    
    files['input_file'] = addTags(trimmed,tags,pos,before_tags,before_pos)

    before_tags = tags
    before_pos = pos

    tags = []
    pos = []
    trimmed = ""
    
    files['input_file'],trimmed,tags,pos = trimString(files,trimmed,tags,pos)

    before_tags = tags
    before_pos = pos

    for m in p.finditer(str(trimmed)): # we iterate over matches
        x = trimmed[m.start()+ln:m.end()+ln] # in variable x we have string that we will "highlight" 
        if x == '':
            continue
        
        head = trimmed[:m.end()+ln]
        rest = trimmed[m.end()+ln:]
        index = 0
        # this cycle takes care of only inserting tags to those matches, that are not already a tag
        # it does so by checking right and left side of position, that we want to insert tag to
        for c in rest:
            if c == "<":
                y = determineStyle(x,format_reaction[i])
                a = trimmed[:m.start()+ln] + y + trimmed[m.end()+ln:]
                ln = ln + len(y) - len(x)
                trimmed = a
                break
            elif index == len(rest)-1 and c != ">":
                y = determineStyle(x,format_reaction[i])
                a = trimmed[:m.start()+ln] + y + trimmed[m.end()+ln:]
                ln = ln + len(y) - len(x)
                trimmed = a
                break
            elif c == ">":
                ind = len(head)-1
                for d in reversed(head):
                    if d == "<":
                        break
                    elif ind == 0 and d != "<":
                        y = determineStyle(x,format_reaction[i])
                        a = trimmed[:m.start()+ln] + y + trimmed[m.end()+ln:]
                        ln = ln + len(y) - len(x)
                        trimmed = a
                        break
                    elif d == ">":
                        y = determineStyle(x,format_reaction[i])
                        a = trimmed[:m.start()+ln] + y + trimmed[m.end()+ln:]
                        ln = ln + len(y) - len(x)
                        trimmed = a
                        break
                    ind = ind - 1
                break
            index = index + 1
        if len(rest) == 0:
            y = determineStyle(x,format_reaction[i])
            a = trimmed[:m.start()+ln] + y + trimmed[m.end()+ln:]
            ln = ln + len(y) - len(x)
            trimmed = a
    files['input_file'] = trimmed
    i = i + 1
    ln = 0
tags = []
pos = []
trimmed = ""
    
files['input_file'],trimmed,tags,pos = trimString(files,trimmed,tags,pos)
files['input_file'] = addTags(trimmed,tags,pos,before_tags,before_pos)
files['input_file'] = files['input_file'].replace("&lt","<").replace("&gt",">")

writeToFile(files)
/*
 * Subor:   proj2.c
 * Autor:   Maros Vasilisin, xvasil02@stud.fit.vutbr.cz, 1BIT
 * Projekt: Building H2O, 2. projekt IOS
 * Popis:   Existují dva typy procesů, kyslík a vodík.
 *          Aby se mohly spojit do molekuly vody, musí se počkat na příchod příslušných atomů,
 *          tj. jeden atom kyslíku a dva atomy vodíku.
 *          Poté se spojí do molekuly vody a proces se opakuje.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <stdbool.h>
#include <errno.h>
#include <limits.h>
#include <time.h>
#include <semaphore.h>
#include <sys/mman.h>
#include <signal.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/shm.h>
#include <sys/ipc.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/stat.h>

#define SEMA_HYD 0
#define SEMA_OXY 1
#define SEMA_MUT 2
#define SEMA_WRT 3
#define SEMA_BOND 4
#define SEMA_MUT2 5
#define SEMA_WAT 6
#define SEMA_COUNT 7

typedef struct {  //struktura pre zdielanu pamat
    int hydrogens ;
    int oxygens ;
    int A ;
    int h_count;
    int o_count;
    int gh;
    int go;
    int b;
    sem_t sem[SEMA_COUNT];
    FILE *f;
    int total_h;
    int total_o;
    int bonded;
}   Telement;

Telement *element = NULL;

#define LOCK(sem_) sem_wait(&(element->sem[sem_])) //definovane mutexy
#define UNLOCK(sem_) sem_post(&(element->sem[sem_]))

void log_write(char* type, char *msg, int i) //funkcia na zapis do suboru
{
	LOCK(SEMA_WRT);

	fprintf(element->f,"%d: %s %d: %s\n",++element->A,type,i,msg);

    fflush(element->f);

	UNLOCK(SEMA_WRT);
}

void bond(char *type,int i) { //funkcia na spajanie atomov do molekuly

    time_t t;
    useconds_t delay;

    log_write(type,"begin bonding",i);

    if (strcmp(type,"O") == 0) {
        element->oxygens--;
        }
    else element->hydrogens--;

        srand((unsigned) time(&t));
        delay = 1000*(rand() % (element->b+1));
        usleep(delay);
    LOCK(SEMA_BOND);
    log_write(type,"bonded",i);
    UNLOCK(SEMA_BOND);

}

void oxygen(int i) { //funkcia na tvorbu procesov na vytvaranie kyslika

    LOCK(SEMA_MUT);
    log_write("O","started",i);
    element->oxygens = element->oxygens + 1;


    if (element->hydrogens >= 2) {
        log_write("O","ready",i);
        UNLOCK(SEMA_HYD);
        UNLOCK(SEMA_HYD);
        //element->hydrogens = element->hydrogens - 2;
        UNLOCK(SEMA_OXY);
        //element->oxygens = element->oxygens - 1;
    }
    else {
        log_write("O","waiting",i);
        UNLOCK(SEMA_MUT);
    }
    LOCK(SEMA_OXY);
    bond("O",i);
    element->total_o = element->total_o + 1;
    UNLOCK(SEMA_MUT);
    if ((element->total_h == element->h_count) && (element->total_o == element->o_count)) {
        UNLOCK(SEMA_WAT);
    }


    LOCK(SEMA_WAT);
    UNLOCK(SEMA_WAT);
    log_write("O","finished",i);

    }

void hydrogen(int i) { //funkcia na vytvaranie procesov vodika

    LOCK(SEMA_MUT);
    log_write("H","started",i);
    element->hydrogens = element->hydrogens + 1;


    if ((element->oxygens >= 1) && (element->hydrogens >= 2)) {
        log_write("H","ready",i);
        UNLOCK(SEMA_HYD);
        UNLOCK(SEMA_HYD);
        //element->hydrogens = element->hydrogens - 2;
        UNLOCK(SEMA_OXY);
        //element->oxygens = element->oxygens - 1;
    }
    else {
        log_write("H","waiting",i);
        UNLOCK(SEMA_MUT);
    }

    LOCK(SEMA_HYD);
    bond("H",i);
    element->total_h = element->total_h + 1;
    if ((element->total_h == element->h_count) && (element->total_o == element->o_count)) {
         UNLOCK(SEMA_WAT);
    }

    LOCK(SEMA_WAT);
    UNLOCK(SEMA_WAT);
    log_write("H","finished",i);

    }



enum errors
  {
    ERRARG,
    ERRALOC,
    ERRSEM,
    ERRSHM,
    ERRFORK,
    ERRFILE
  };

const char *ERRMSG[] =
  {
    [ERRARG] =   "Chyba: použitie: ./h2o N GH GO B\n",
    [ERRALOC] = "Chyba: nepodarila sa alokácia\n",
    [ERRSEM] = "Chyba: nepodarilo sa vytvorit semafory\n",
    [ERRFORK] = "Chyba: fork sa nepodaril\n",
    [ERRSHM] = "Chyba pri vytváraní zdieľanej pamäte\n",
    [ERRFILE] = "Chyba: nepodarilo sa otvoriť súbor na zápis\n"
  };

int numbers_only(const char *s) //funkcia na kontrolu ci argumenty obsahuju len ciselne znaky
{
    while (*s) {
        if (isdigit(*s++) == 0) return 0;
    }
    return 1;
}

int kontrola_arg(int argc, char* argv[]) //funkcia na kontrolu argumentov programu
  {
    if (argc != 5)
      {
        fprintf(stderr,"%s",ERRMSG[ERRARG]);
        exit(1);
      }

    else if ((numbers_only(argv[1]) ==  0)
            || (numbers_only(argv[2]) ==  0)
            || (numbers_only(argv[3]) ==  0)
            || (numbers_only(argv[4]) ==  0))
                {
                    fprintf(stderr,"%s",ERRMSG[ERRARG]);
                    exit(1);
                }

    else if (atoi(argv[1]) <= 0)
        {
          fprintf(stderr,"%s",ERRMSG[ERRARG]);
          exit(1);
        }
    else if ((atoi(argv[2]) < 0) || (atoi(argv[2]) > 5000))
        {
          fprintf(stderr,"%s",ERRMSG[ERRARG]);
          exit(1);
        }
    else if ((atoi(argv[3]) < 0) || (atoi(argv[3]) > 5000))
        {
          fprintf(stderr,"%s",ERRMSG[ERRARG]);
          exit(1);
        }
    else if ((atoi(argv[4]) < 0) || (atoi(argv[4]) > 5000))
        {
          fprintf(stderr,"%s",ERRMSG[ERRARG]);
          exit(1);
        }
    else
    return 0;
  }


int init() { //funkcia na inicializaciu semaforov

    for(int i = 0; i < (SEMA_COUNT-1); i++)
	{
		sem_init(&element->sem[i], 1, 1);
	}
	sem_init(&element->sem[SEMA_COUNT-1],1,1);

    return 0;
}

int del() { //funkcia na mazanie semaforov
    int ret= 0;

    for(int i = 0; i < SEMA_COUNT; i++)
	{
		if (sem_destroy(&element->sem[i]) == -1 )
            ret = 2;
	}
    return ret;
    }


int main(int argc, char *argv[])
  {
    time_t t;

    if (kontrola_arg(argc,argv) == 1) {
        return 1;
    }


	int shm;


    shm = shmget(IPC_PRIVATE, sizeof(Telement), SHM_R | SHM_W); //inicializaccia zdielanej pamate


	 if (shm < 0) {
        fprintf(stderr,"%s",ERRMSG[ERRSHM]);
        exit(2);
    }

	element = shmat(shm, NULL, 0); //funkcia na priradenie zdielanej pamate

    if (element == NULL || element == (void*)0)
	{
		fprintf(stderr,"%s",ERRMSG[ERRSHM]);
        exit(2);
	}

	element->f = fopen("h2o.out","w");

    FILE *f;
    f=fopen("h2o.out","w"); // otvorenie suboru pre vypis

    if (!element->f)
	{
		fprintf(stderr,"%s",ERRMSG[ERRFILE]);
        return 2;
	}

	if (init() != 0)
        {
            fprintf(stderr,"%s",ERRMSG[ERRSEM]);
            del();
            return 2;
        }

    LOCK(SEMA_HYD);
    LOCK(SEMA_OXY);
    LOCK(SEMA_WAT);

	element->o_count = atoi(argv[1]); //priradenie hodnot do premennych zdielanej pamate
	element->h_count = 2* element->o_count;
    element->gh = atoi(argv[2]);
    element->go = atoi(argv[3]);
    element->b = atoi(argv[4]);
    element->hydrogens = 0;
    element->oxygens = 0;
    element->A = 0;
    element->total_h = 0;
    element->total_o = 0;
    element->bonded = 0;

    pid_t gen_h,gen_o;

    gen_h = fork();

    if (gen_h == 0) {
        useconds_t delay;

        pid_t children[element->h_count];

        for (int i=0;i<element->h_count;i++) {

            srand((unsigned) time(&t));
            delay = 1000*(rand() % (element->gh+1));
            usleep(delay);

            children[i] = fork();
            if (children[i] == 0) {
                hydrogen(i+1);
                _exit(0);
            }

            if (children[i] < 0) {
                fprintf(stderr,"%s",ERRMSG[ERRFORK]);
                return 2;
            }
        }
        for (int i=0;i<element->h_count;i++) {
            waitpid(children[i],NULL,0);
        }

        _exit(0);
    }

    gen_o = fork();

    if (gen_o == 0) {
        useconds_t delay;

        pid_t children[element->o_count];

        for (int i=0;i<element->o_count;i++) {

            srand((unsigned) time(&t));
            delay = 1000*(rand() % (element->go+1));
            usleep(delay);

            children[i] = fork();
            if (children[i] == 0) {
                oxygen(i+1);
                _exit(0);
            }

            if (children[i] < 0) {
                fprintf(stderr,"%s",ERRMSG[ERRFORK]);
                return 2;
            }
        }
        for (int i=0;i<element->o_count;i++) {
            waitpid(children[i],NULL,0);
        }
        _exit(0);
    }
    waitpid(gen_h,NULL,0);
    waitpid(gen_o,NULL,0);

    del();//mazanie pamate
    shmdt(element);
    shmctl(shm, IPC_RMID, NULL);
    fclose(f);
    return 0;
  }

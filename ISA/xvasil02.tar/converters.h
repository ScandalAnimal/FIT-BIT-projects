//============================================================================
// Name        : converters.h
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#ifndef CONVERTERS_H
#define CONVERTERS_H

#include <string>
#include <arpa/inet.h> 

/*
 * funkcia konvertuje data z bytoveho streamu do stringu vhodneho pre vypis a porovnavanie
 * na vstupe dostava vstupne data a ich dlzku
 * vracia konvertovany string
 */
std::string byteToHex(std::string, int);

/*
 * funkcia konvertuje hexa string do integeru
 * na vstupe dostava string v hexa notcacii
 * vracia integerovu hodnotu stringu
 */
unsigned int hexToInt(std::string);

/*
 * funkcia konvertuje string na format ipv4 adresy vhodny pre vypis
 * na vstupe dostane string mez oddelovacov
 * vracia formatovany string
 */
std::string hexToIP(std::string);

/*
 * funkcia konvertuje string na format mac adresy vhodny pre vypis
 * na vstupe dostane string mez oddelovacov
 * vracia formatovany string
 */
std::string hexToMac(std::string);

/*
 * funkcia konvertuje string na format ipv6 adresy vhodny pre vypis
 * na vstupe dostane string mez oddelovacov
 * vracia formatovany string
 */
std::string hexToIPv6(std::string);

/*
 * funkcia ktora obrati string po bytoch
 * do parametrov dostane string ktory chceme obratit
 * vracia obrateny string
 */
std::string revert(std::string);

/*
 * funkcia konvertuje znaky na ipv6 adresu
 * ako parametre dostava pole znakov co chceme konvertovat a strukturu pre ipv6 adresy
 */
void shortIPv6ToLong(char *, struct in6_addr *);

/*
 * funkcia na konverziu stringu na ipv6 string s oddelovacmi
 * ako parameter dostane string
 * a vracia konvertovany string
 */
std::string convertShortIPv6ToLong(std::string);

/*
 * funkcia na konverziu dlhej ipv6 adresy na skratenu
 * ako parameter dostane string
 * a vracia konvertovany string
 */
std::string convertLongIPv6ToShort(std::string);

/*
 * funkcia nahradza vsetky substringy stringu novou hodnotou
 * parametre: string, stary substring a novy substring
 * vracia novu hodnotu
 */
std::string replaceAllSubstrings(std::string, std::string, std::string);

/*
 * funkcia nahradza prvy substring stringu novou hodnotou
 * parametre: string, stary substring a novy substring
 * vracia novu hodnotu
 */
std::string replaceAllSubstrings(std::string, std::string, std::string);

#endif
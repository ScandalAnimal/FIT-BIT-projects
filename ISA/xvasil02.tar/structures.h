//============================================================================
// Name        : structures.h
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#ifndef STRUCTURES_H
#define STRUCTURES_H

#include <string>

/*
 * struktura pre argumenty z konzole
 * inputFileName: nazov suboru, ktory budeme prechadzat
 * filterType: typ aplikovaneho filtra
 * filterValue: hodnota aplikovaneho filtra
 * src: true ak bol zadany priznak -s
 * dst: true ak bol zadany priznak -d
 */
typedef struct arguments {
    std::string inputFileName;
    std::string filterType;
    std::string filterValue;
    bool src;
    bool dst;
} arguments;

/*
 * struktura reprezentujuca vsetky potrebne hodnoty z L2 hlavicky packetu
 * destAddress: cielova mac adresa
 * srcAddress: zdrojova adresa
 * networkProtocol: typ L3 protokolu
 * l3headerLength: dlzka L3 hlavicky
 * totalLength: totalLength policko z IPV4 hlavicky
 */
typedef struct L2_header {
	std::string destAddress;
	std::string srcAddress;
	std::string networkProtocol;
	unsigned int l3headerLength;
    std::string totalLength;
} L2_header;

/*
 * struktura reprezentujuca data z ipv4 hlavicky
 * l3protocol: verzia protokolu
 * l3destIP: cielova IP adresa
 * l3srcIP: zdrojova adresa
 */
typedef struct ipv4_header {
	std::string l3protocol;
	std::string l3destIP;
	std::string l3srcIP;
} ipv4_header;

/*
 * struktura reprezentujuca data z ipv6 hlavicky
 * nextHeader: protokol na L4 vrstve
 * srcIP: zdrojova IP adresa
 * destIP: cielova IP adresa
 */
typedef struct ipv6_header {
	std::string nextHeader;
	std::string srcIP;
	std::string destIP;
} ipv6_header;

/*
 * struktura reprezentujuca TCP hlavicku
 * l4srcPort: zdrojovy port
 * l4destPort: cielovy port
 * l4headerLength: dlzka hlavicky
 */
typedef struct tcp_header {
	std::string l4srcPort;
	std::string l4destPort;
	unsigned int l4headerLength;
} tcp_header;

/*
 * struktura reprezentujuca udp hlavicku
 * l4srcPort: zdrojovy port
 * l4destPort: cielovy port
 * l4dataLength: dlzka dat
 * l4headerLength: dlzka hlavicky
 */
typedef struct udp_header {
	std::string l4srcPort;
	std::string l4destPort;
	unsigned int l4dataLength;
	unsigned int l4headerLength;
} udp_header;

/*
 * struktura pre vypis
 * L2_length: dlzka L2 hlavicky
 * L3_length: dlzka L3 hlavicky
 * L4_length: dlzka L4 hlavicky
 * L3_protocol: typ protokolu na L3 vrstve
 * L4_protocol: typ protokolu na L4 vrstve
 * destMac: cielova mac adresa
 * destIP: cielova IP adresa
 * destPort: cielovy port
 * srcMac: zdrojova mac adresa
 * srcIP: zdrojova IP adresa
 * srcPort: zdrojovy port
 * data_length: dlzka dat
 * ipv6ExtraHeaders: priznak ci ipv6 mala extra hlavicky
 */
typedef struct packet_info {
	unsigned int L2_length;
	unsigned int L3_length;
	unsigned int L4_length;
    std::string L3_protocol;
    std::string L4_protocol;
	std::string destMac;
	std::string destIP;
	std::string destPort;
	std::string srcMac;
	std::string srcIP;
	std::string srcPort;
	unsigned int data_length;
	bool ipv6ExtraHeaders;
} packet_info;

/*
 * struktura pre hodnoty 1 a 2 na vypise
 */
typedef struct output_values {
	unsigned int output_value1;
	unsigned int output_value2;
} output_values;

#endif
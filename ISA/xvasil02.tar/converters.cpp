//============================================================================
// Name        : converters.cpp
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#include <string>
#include <iostream>
#include <sstream>
#include <arpa/inet.h> 

std::string byteToHex(std::string data, int length) {

  // pole hexa znakov
  constexpr char hexmap[] = {'0','1','2','3','4','5','6','7',
  							 '8','9','a','b','c','d','e','f'};
  
  std::string result((unsigned long) (2 * length), ' ');
  
  for (int i = 0; i < length; ++i) {
    result[2*i] = hexmap[(data[i] & 0xF0) >> 4];
    result[2*i+1] = hexmap[data[i] & 0x0F];
  }

  return result;
}

unsigned int hexToInt(std::string hexString) {

	unsigned int intValue;   
	std::stringstream ss;
	ss << std::hex << hexString;
	ss >> intValue;
	return intValue;
}

std::string hexToIP(std::string hexString) {

    // pozadovany format je XXX.XXX.XXX.XXX

	std::string result = ""; 
	std::string token;

	for (unsigned int i = 0; i < hexString.length(); i+=2) {
		token.assign(hexString,i,2);
		token = std::to_string(hexToInt(token));
		result += token;
		if (i != hexString.length() - 2) {
			result += ".";
		}
	}
	return result;
}

std::string hexToMac(std::string hexString) {

    // pozadovany format je XX:XX:XX:XX:XX:XX

	std::string result = ""; 
	std::string token;

	for (unsigned int i = 0; i < hexString.length(); i+=2) {
		token.assign(hexString,i,2);
		result += token;
		if (i != hexString.length() - 2) {
			result += ":";
		}
	}
	return result;
}

std::string hexToIPv6(std::string hexString) {

    // pozadovany format je XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX:XXXX

	std::string result = ""; 
	std::string token;

	for (unsigned int i = 0; i < hexString.length(); i+=4) {
		token.assign(hexString,i,4);
		result += token;
		if (i != hexString.length() - 4) {
			result += ":";
		}
	}
	return result;
}

std::string revert(std::string original) {
	
	std::string reverted;
	for (unsigned int i = 0; i < original.length(); i+=2) {
		reverted = original.substr(i,2) + reverted;
	}
	return reverted;
}

void shortIPv6ToLong(char * str, struct in6_addr * addr) {
   sprintf(str, "%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x:%02x%02x",
                 (int)addr->s6_addr[0], (int)addr->s6_addr[1],
                 (int)addr->s6_addr[2], (int)addr->s6_addr[3],
                 (int)addr->s6_addr[4], (int)addr->s6_addr[5],
                 (int)addr->s6_addr[6], (int)addr->s6_addr[7],
                 (int)addr->s6_addr[8], (int)addr->s6_addr[9],
                 (int)addr->s6_addr[10], (int)addr->s6_addr[11],
                 (int)addr->s6_addr[12], (int)addr->s6_addr[13],
                 (int)addr->s6_addr[14], (int)addr->s6_addr[15]);
}

std::string convertShortIPv6ToLong(std::string filterValue) {
	struct sockaddr_in6 sa;
	char *tmp = new char[50];
	inet_pton(AF_INET6, filterValue.c_str(), &(sa.sin6_addr));
	shortIPv6ToLong(tmp,&sa.sin6_addr);

	return tmp;
}

std::string replaceAllSubstrings(std::string string, std::string from, std::string to) {

    size_t start_pos = 0;

    while ((start_pos = string.find(from, start_pos)) != std::string::npos) {
        string.replace(start_pos, from.length(), to);
        start_pos += to.length();
    }

    return string;
}

std::string replaceFirstSubstring(std::string string, std::string from, std::string to) {

    size_t start_pos = 0;

    while ((start_pos = string.find(from, start_pos)) != std::string::npos) {
        string.replace(start_pos, from.length(), to);
        return string;
    }
    return string;
}

std::string convertLongIPv6ToShort(std::string ipAddress) {

    ipAddress = replaceAllSubstrings(ipAddress,"0000","*");
    ipAddress = replaceAllSubstrings(ipAddress,":000",":");
    ipAddress = replaceAllSubstrings(ipAddress,":00",":");
    ipAddress = replaceAllSubstrings(ipAddress,":0",":");

    std::string oldIP = ipAddress;
    std::string newIP = "";
    while (true) {
        newIP = replaceFirstSubstring(ipAddress,"*:*:*:*:*:*:*:*","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*:*:*:*:*:*",":");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,":*:*:*:*:*:*:","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*:*:*:*:*",":");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,":*:*:*:*:*:","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*:*:*:*",":");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,":*:*:*:*:","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*:*:*",":");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,":*:*:*:","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*:*",":");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,":*:*:","::");
        if (oldIP != newIP) {
            break;
        }
        newIP = replaceFirstSubstring(ipAddress,"*:*",":");
        if (oldIP != newIP) {
            break;
        }
        break;
    }
    ipAddress = replaceAllSubstrings(newIP,"*","0");
    return ipAddress;
}
//============================================================================
// Name        : validators.cpp
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#include <string>
#include <arpa/inet.h> 

bool isValidIP4(std::string value) {
	
	struct sockaddr_in sa;
    return inet_pton(AF_INET, value.c_str(), &(sa.sin_addr)) != 0;
}

bool isValidIP6(std::string value) {

	struct sockaddr_in6 sa;
    return inet_pton(AF_INET6, value.c_str(), &(sa.sin6_addr)) != 0;
}

bool isValidMac(const char *value) {

	for(int i = 0; i < 17; i++) {

        if(i % 3 != 2 && !isxdigit(value[i])) {
            return false;
        }
        if(i % 3 == 2 && ((value[i] != ':' ) && (value[i] != '-')) ) {
            return false;
        }
    }
    return value[17] == '\0';
}

bool isValidFilterType(char *arg) {

    // mozne hodnoty filtra
	std::string filterTypes[] {"mac", "ipv4", "ipv6", "tcp", "udp"}; 

    // prechadzanie pola moznych hodnot, porovnavanie s parametrom
	for(const std::string &filterType : filterTypes) {
		if (arg == filterType) {
			return true;
		}
	}
	return false;
}

bool isValidFilterFormat(std::string filterType, std::string filterValue) {

    // pri mac filtri validujeme ze je hodnota validna mac adresa
    if ("mac" == filterType) {
        return isValidMac(filterValue.c_str());
    }
    // pri ipv4 filtri validujeme ze je hodnota validna ipv4 adresa
    else if ("ipv4" == filterType) {
        return isValidIP4(filterValue);
    }
    // pri filtri ipv6 validujeme ze je hodnota validna ipv6 adresa
    else if ("ipv6" == filterType) {
        return isValidIP6(filterValue);
    }
    // pri filtroch tcp a udp musi byt hodnota cislo od 0 do 65535
    else if (("udp" == filterType) || ("tcp" == filterType)) {
        return (stoi(filterValue) >= 0) && (stoi(filterValue) <= 65535);
    }
    return false;
}
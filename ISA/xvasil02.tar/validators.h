//============================================================================
// Name        : validators.h
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#ifndef VALIDATORS_H
#define VALIDATORS_H

#include <string>

/*
 * validator na typ filtra v argumentoch programu
 * ako parameter dostane hodnotu filtra
 * vracia true ak je filter validna hodnota, false ak nie je
 */
bool isValidFilterType(char *);

/*
 * kontroluje validitu hodnoty filtra
 * ako parametre dostava typ filtra a hodnotu filtra
 * vracia true ak je hodnota validna, false ak nie je
 */
bool isValidFilterFormat(std::string, std::string);

/*
 * kontroluje ci je hodnota validna ipv4 adresa
 * ako parameter berie kontrolovanu hodnotu
 * vracia true ak je hodnota validna, false ak nie je
 */
bool isValidIP4(std::string);

/*
 * kontroluje ci je hodnota validna ipv6 adresa
 * ako parameter berie kontrolovanu hodnotu
 * vracia true ak je hodnota validna, false ak nie je
 */
bool isValidIP6(std::string);

/*
 * kontroluje ci je hodnota validna mac adresa
 * ako parameter berie kontrolovanu hodnotu
 * vracia true ak je hodnota validna, false ak nie je
 */
bool isValidMac(const char *);

#endif
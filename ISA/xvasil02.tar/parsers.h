//============================================================================
// Name        : parsers.h
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#ifndef PARSERS_H
#define PARSERS_H

#include <stdio.h>
#include <string.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>

#include "structures.h"

/*
 * funkcia ktora parsuje argumenty z konzole
 * ako parametre dostava pocet argumentov, pole argumentov, a strukturu v ktorej vracia argumenty
 * vracia true ak su argumenty validne, false ak je niekde chyba
 */
bool parseArguments(int, char *[], arguments&);

/*
 * funkcia ktora parsuje globalnu hlavicku z pcap suboru
 * ako parameter dostane stream zo suboru
 * vracia typ L2 hlavicky packetov
 */
std::string parseGlobalHeader(std::ifstream&);

/*
 * funkcia spracovava packet header zo suboru pcap
 * ako parameter dostava stream zo suboru a prvy znak hlavicky(kvoli kontrole konca streamu)
 */
unsigned int parsePacketHeader(std::ifstream&, char *);

/*
 * funkcia ktora spracovava L2 hlavicku packetu
 * ako parametre dostava navratovu strukturu, stream z ktoreho cita a packet_info - tam sa ukladaju udaje potrebne k vypisu
 * vracia cislo protokolu v nasledujucej hlavicke
 */
unsigned int parseL2header(L2_header&, std::ifstream&, packet_info&);

/*
 * funkcia ktora spracovava ipv4 hlavicku packetu
 * ako parametre dostava strukturu na ulozenie dat z hlavicky, strukturu z L2 vrstvy, stream z ktoreho citame byty
 * a packet_info strukturu 
 * vracia cislo protokolu v L4 hlavicke
 */
unsigned int parseIPV4header(ipv4_header&, L2_header&, std::ifstream&, packet_info&);

/*
 * funkcia ktora parsuje ipv6 hlavicky
 * na vstupe dostane strukturu kam uklada udaje o hlavicke, stream z ktoreho cita data a info strukturu potrebnu k vypisom
 * vracia cislo protokolu v L4 hlavicke
 */
unsigned int parseIPV6header(ipv6_header&, std::ifstream&, packet_info&);

/*
 * funkcia ktora parsuje tcp hlavicky
 * ako parametre dostane strukturu kam uklada udaje o hlavicke, stream z ktoreho cita data a info strukturu
 * ktora sa pouziva pri vypise
 */
void parseTcpHeader(tcp_header&, std::ifstream&, packet_info&);

/*
 * funkcia ktora parsuje udp hlavicky
 * ako parametre dostane strukturu kam uklada udaje o hlavicke, stream z ktoreho cita data a info strukturu
 * ktora sa pouziva pri vypise
 */
void parseUdpHeader(udp_header&, std::ifstream&, packet_info&);

#endif
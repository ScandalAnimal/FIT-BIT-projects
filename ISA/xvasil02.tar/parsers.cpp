//============================================================================
// Name        : parsers.cpp
// Author      : Maroš Vasilišin
// Last Update : 23.10.2016
// Project     : Network Traffic Analyzer
//============================================================================

#include <stdio.h>
#include <string.h>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>

#include "structures.h"
#include "validators.h"
#include "converters.h"


bool parseArguments(int argc, char *argv[], arguments &arg) {

    // pridavam priznaky ze nebol este zadany parameter -s ani -d
	arg.src = arg.dst = false;

    // kontrola poctu parametrov: musi byt 8 alebo 9 aby bol validny
	if (argc != 8 && argc != 9)
		return false;

    // priznaky reprezentujuce vyskyt jednotlivych parametrov -i, -f, -v, -s, -d
	bool wasParamI, wasParamF, wasParamV, wasParamS, wasParamD;
	wasParamI = wasParamF = wasParamV = wasParamS = wasParamD = false;

    // iteracia cez vsetky parametre
	for (int a = 1; a < argc; a+=2) {

        // ak sa vyskytol parameter -i, upravim priznak a ulozim do struktury
		if (strcmp(argv[a],"-i") == 0) {
            // kontrola na duplicitu
			if (wasParamI)
				return false;
			wasParamI = true;
			arg.inputFileName = argv[a+1];
		}
        // ak sa vyskytol parameter -f, skontrolujem na duplicitu, upravim priznak
		else if (strcmp(argv[a],"-f") == 0) {
			if (wasParamF)
				return false;
			wasParamF = true;

            // volanie validatora, ktory skontroluje ci zadany filter je validny
			if (isValidFilterType(argv[a+1])) {
				arg.filterType = argv[a+1];
			}
			else
				return false;
		}
        // pri vyskyte parametru -v skontrolujem duplicitu, upravim priznak a vlozim hodnotu do struktury
		else if (strcmp(argv[a],"-v") == 0) {
			if (wasParamV)
				return false;
			wasParamV = true;
			arg.filterValue = argv[a+1];
		}
        // ak sa nasiel parameter -s skontrolujem duplicitu, upravim priznak, vlozim do struktury
		else if (strcmp(argv[a],"-s") == 0) {
			if (wasParamS)
				return false;
			wasParamS = true;
			arg.src = true;
			a--;
		}
        // ak sa nasiel parameter -d skontrolujem duplicitu, upravim priznak, vlozim do struktury
		else if (strcmp(argv[a],"-d") == 0) {
			if (wasParamD)
				return false;
			wasParamD = true;
			arg.dst = true;
			a--;
		}
		else
			return false;
	}

    // kontrola, ze aspon jeden z parametrov -s, -d bol zadany
	if (!wasParamS && !wasParamD)
		return false;

    // ak nebol filter top10, tak este kontrolujem ci je hodnota filtra validna
    return !(("top10" != arg.filterValue) && (!isValidFilterFormat(arg.filterType, arg.filterValue)));
}

std::string parseGlobalHeader(std::ifstream &inputStream) {

    // global header ma fixnu velkost 24 bytov
	unsigned int GLOBAL_HEADER_SIZE = 24; 
	char *globalHeader = new char[GLOBAL_HEADER_SIZE];

    // nacitanie 24 bytov zo streamu do pola globalHeader
	for (unsigned int i = 0; i < GLOBAL_HEADER_SIZE; i++) {
		inputStream.get(globalHeader[i]);
	}

    // prevod pola charov do stringu
	std::string globalHeaderStr(globalHeader,GLOBAL_HEADER_SIZE);

    // prevod stringu do hexa znakov
	globalHeaderStr = byteToHex(globalHeaderStr,GLOBAL_HEADER_SIZE);

    // vracia linkLayerType, teda typ L2 hlavicky
    delete[](globalHeader);
	return globalHeaderStr.substr(40,8);
}

unsigned int parsePacketHeader(std::ifstream &inputStream, char *packetTimestampFirst) {

    // fixna velkost 16 bytov
	unsigned int PACKET_HEADER_SIZE = 16; 

	char *packetHeader = new char[PACKET_HEADER_SIZE];
	packetHeader[0] = packetTimestampFirst[0];

    // nacitanie obsahu streamu do pola
	for (unsigned int i = 1; i < PACKET_HEADER_SIZE; i++) {
		inputStream.get(packetHeader[i]);
	}
    // prevod pola na string
	std::string packetHeaderStr(packetHeader,PACKET_HEADER_SIZE);
	packetHeaderStr = byteToHex(packetHeaderStr,PACKET_HEADER_SIZE);

	std::string packetLength = packetHeaderStr.substr(16,8);

    delete[](packetHeader);
    // ulozenie velkosti packetu
	return hexToInt(revert(packetLength));
}

unsigned int parseL2header(L2_header &L2header, std::ifstream &inputStream, packet_info &packetInfo) {

	unsigned int L2_HEADER_SIZE = 15;
	char *header = new char[L2_HEADER_SIZE];

    // nacitanie 15 znakov z hlavicky do pola
	for (unsigned int i = 0; i < L2_HEADER_SIZE; i++) {
		inputStream.get(header[i]);
	}
    // prevod pola do stringu
	std::string L2HeaderStr(header,L2_HEADER_SIZE);
    delete[](header);
	L2HeaderStr = byteToHex(L2HeaderStr,L2_HEADER_SIZE);

    // ulozenie zdrojovej a cielovej mac adresy do struktury
	L2header.destAddress = L2HeaderStr.substr(0,12);
	L2header.srcAddress = L2HeaderStr.substr(12,12);
	std::string l2EtherType = L2HeaderStr.substr(24,4);

    // ulozenie cisla protokolu v nasledujucej hlavicke
	int etherType = hexToInt(l2EtherType);
	if (etherType == 2048) {
		L2header.networkProtocol = "ipv4";
	}
	else if (etherType == 2054) {
		L2header.networkProtocol = "arp";
	} 
	else if (etherType == 34525) {
		L2header.networkProtocol = "ipv6";
	}
	else {
		fputs("Invalid network protocol\n", stderr);
        exit(1);
	}

    // ulozenie zdrojovej a cielovej mac adresy aj do struktury info
	packetInfo.destMac = hexToMac(L2header.destAddress);
	packetInfo.srcMac = hexToMac(L2header.srcAddress);

    char *skipBytes = new char[10];

    // ziskanie bytu ktory reprezentuje dlzku L3 hlavicky a cislo protokolu
    std::string headerStr = L2HeaderStr.substr(28,2);

    // rozdelenie po 4 bitoch
	std::string a,b;
	a.assign(headerStr,0,1);
	b.assign(headerStr,1,1);

	if (L2header.networkProtocol == "ipv4") {

        // dlzka l3 hlavicky je 4x hodnota policka
		L2header.l3headerLength = 4 * hexToInt(b);
		unsigned int l3ipVersion = hexToInt(a);

        // kontrola ci sa zhoduju hodnoty v polickach
		if (l3ipVersion == 4) {
            // preskocenie 8 bytov, ktore nas nezaujimaju
			for (unsigned int i = 0; i < 8; i++) {
			  	inputStream.get(skipBytes[i]);
			}
            std::string str(skipBytes,8);
            str = byteToHex(str,8);
            L2header.totalLength = str.substr(2,4);

            // ulozenie dlzky hlaviciek do info struktury
			packetInfo.L2_length = 14;
			packetInfo.L3_length = 8 + 1;
            delete[](skipBytes);
			return 4; // vraciame 4 ako ipv4
		}
		else {
			std::cout << "not ipv4 and should be" << std::endl;
			exit(1);
		}
	}
	else if (L2header.networkProtocol == "ipv6"){

		unsigned int l3ipVersion = hexToInt(a);
        // kontrola zhody na polickach
		if (l3ipVersion == 6) {
            // preskocenie 5 bytov
			for (unsigned int i = 0; i < 5; i++) {
		  		inputStream.get(skipBytes[i]);
			}
            L2header.totalLength = "";
            // ulozenie dlzky do info struktury
			packetInfo.L2_length = 14;
            delete[](skipBytes);
            // vraciame 6 ako ipv6
			return 6;
		}
		else {
			std::cout << "not ipv6 and should be";
			exit(1);
		}
	}
    else if (L2header.networkProtocol == "arp") {
        packetInfo.L2_length = 14;
        delete[](skipBytes);
        return 10;
    }

    // ak sa nejedna o ipv4 ani ipv6 ani arp/rarp na L3 vrstve tak vraciame chybu
	return 1;
}

unsigned int parseIPV4header(ipv4_header &ipv4header, L2_header &L2header, 
							std::ifstream &inputStream, packet_info &packetInfo) {
	
	// do premennej si vlozime kolko bytov este potrebujeme precitat zo streamu
	unsigned int HEADER_SIZE = L2header.l3headerLength - 9; 
	char *header = new char[HEADER_SIZE];

	// nacitame potrebny pocet bytov
	for (unsigned int i = 0; i < HEADER_SIZE; i++) {
		inputStream.get(header[i]);
	}
	// prevedieme na string
	std::string headerStr(header,HEADER_SIZE);
	headerStr = byteToHex(headerStr,HEADER_SIZE);

	// ulozime si protokol, source IP a destination IP adresu
	ipv4header.l3protocol = headerStr.substr(0,2);
	ipv4header.l3srcIP = headerStr.substr(6,8);
	ipv4header.l3destIP = headerStr.substr(14,8);

	// protokol prevedieme do integeru
	unsigned int protocolNumber = hexToInt(ipv4header.l3protocol);

	// do info struktury si ulozime dlzku hlavicky a adresy
	packetInfo.L3_length = L2header.l3headerLength;
	packetInfo.destIP = hexToIP(ipv4header.l3destIP);
	packetInfo.srcIP = hexToIP(ipv4header.l3srcIP);
    packetInfo.L3_protocol = "4";

    delete[](header);
	// vraciame cislo protokolu na L4 vrstve 
	return protocolNumber;
}

/*
 * funkcia ktora preskakuje hlavicky ipv6 ktore tam mozu byt navyse
 */
void skipOptionHeaders(std::ifstream &inputStream, packet_info &packetInfo) {

	char *option = new char[56];

    // zistime aka hlavicka nasleduje
	inputStream.get(option[0]);

	std::string optStr(option,1);
	optStr = byteToHex(optStr,1);
    // do premennej vlozime info aka hlavicka nasleduje
	unsigned int next = hexToInt(optStr);

    // precitame celu hlavicku
	for (unsigned int i = 1; i < 56; i++) {
		inputStream.get(option[i]);
	}

	std::string x(option,56);
	x = byteToHex(x,56);

    // ak nenasleduje hlavicka 41 tak opakujeme (41 je ipv6)
	if (next != 41) {
		skipOptionHeaders(inputStream,packetInfo);
	}

    // ulozime info do strutury pre vypis
	packetInfo.L3_length += 56;
    packetInfo.ipv6ExtraHeaders = true;

    delete[](option);
}

unsigned int parseIPV6header(ipv6_header &ipv6header, std::ifstream &inputStream, packet_info &packetInfo) {

    unsigned int HEADER_SIZE = 34; 
	char *header = new char[HEADER_SIZE];

    // precitame celu hlavicku do pola
	for (unsigned int i = 0; i < HEADER_SIZE; i++) {
		inputStream.get(header[i]);
	}
    // premenime pole na string
	std::string headerStr(header,HEADER_SIZE);
	headerStr = byteToHex(headerStr,HEADER_SIZE);

    // vlozime nextHeader a IP adresy do struktury
	ipv6header.nextHeader = headerStr.substr(0,2);
	ipv6header.srcIP = headerStr.substr(4,32);
	ipv6header.destIP = headerStr.substr(36,32);

    // cislo protokolu prekonvertujeme na integer
	unsigned int protocolNumber = hexToInt(ipv6header.nextHeader);

    // zvysime velkost hlavicky o 40 (default hodnota pre velkost ipv6 hlavicky)
	packetInfo.L3_length += 40;

    // ak nenasleduje tcp ani udp hlavicka tak musime preskocit dane hlavicky
	if (protocolNumber != 6 && protocolNumber != 17) {
		skipOptionHeaders(inputStream,packetInfo);

		char *skip = new char[6];

		for (unsigned int i = 0; i < 6; i++) {
			inputStream.get(skip[i]);
		}
		protocolNumber = parseIPV6header(ipv6header,inputStream,packetInfo);
	}

    // vlozime info o IP adresach do struktury pre vypis
	packetInfo.destIP = hexToIPv6(ipv6header.destIP);
	packetInfo.srcIP = hexToIPv6(ipv6header.srcIP);
    packetInfo.L3_protocol = "6";

    delete[](header);
    // vraciame cislo L4 protokolu
	return protocolNumber;
}

void parseTcpHeader(tcp_header &tcpHeader, std::ifstream &inputStream, packet_info &packetInfo) {

	unsigned int HEADER_SIZE = 13;
	char *header = new char[HEADER_SIZE];

    // precitame byty zo streamu do pola
	for (unsigned int i = 0; i < HEADER_SIZE; i++) {
		inputStream.get(header[i]);
	}
    // konverzia na string
	std::string headerStr(header,HEADER_SIZE);
	headerStr = byteToHex(headerStr,HEADER_SIZE);

    // vlozime do struktury informacie o portoch a dlzke hlavicky
	tcpHeader.l4srcPort = headerStr.substr(0,4);
	tcpHeader.l4destPort = headerStr.substr(4,4);
	std::string l4dataOffset = headerStr.substr(24,2);
	tcpHeader.l4headerLength = hexToInt(l4dataOffset) / 4;

    // preskocime zvysok hlavicky
	char *skip = new char[tcpHeader.l4headerLength];
	for (unsigned int i = 0; i < (tcpHeader.l4headerLength - HEADER_SIZE); i++) {
  		inputStream.get(skip[i]);
	}

	packetInfo.L4_length = tcpHeader.l4headerLength;
	packetInfo.srcPort = std::to_string(hexToInt(tcpHeader.l4srcPort));
	packetInfo.destPort = std::to_string(hexToInt(tcpHeader.l4destPort));
    packetInfo.L4_protocol = "tcp";

    delete[](header);
    delete[](skip);
}

void parseUdpHeader(udp_header &udpHeader, std::ifstream &inputStream, packet_info &packetInfo) {

	unsigned int HEADER_SIZE = 8; 
	char *header = new char[HEADER_SIZE];

    // nacitame hlavicku do pola
	for (unsigned int i = 0; i < HEADER_SIZE; i++) {
		inputStream.get(header[i]);
	}
    //konverzia na string
	std::string headerStr(header,HEADER_SIZE);
	headerStr = byteToHex(headerStr,HEADER_SIZE);

    // ulozime si hodnoty portov a dlzku hlavicky a dat
	udpHeader.l4srcPort = headerStr.substr(0,4);
	udpHeader.l4destPort = headerStr.substr(4,4);
	udpHeader.l4dataLength = hexToInt(headerStr.substr(8,4));
	udpHeader.l4dataLength -= 8;
	udpHeader.l4headerLength = 8;

	packetInfo.L4_length = udpHeader.l4headerLength;
	packetInfo.srcPort = std::to_string(hexToInt(udpHeader.l4srcPort));
	packetInfo.destPort = std::to_string(hexToInt(udpHeader.l4destPort));
    packetInfo.L4_protocol = "udp";

    delete[](header);
}
//============================================================================
// Name        : analyzer.cpp
// Author      : Maroš Vasilišin
// Last Update : 18.11.2016
// Project     : Network Traffic Analyzer
//============================================================================

#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <map>

#include "structures.h"
#include "validators.h"
#include "converters.h"
#include "parsers.h"

using namespace std;

/*
 * funkcia pouzivana na vynulovanie vsetkych hodnot struktury packet_info
 * ako parameter dostane strukturu
 */
void clearInfo(packet_info &packetInfo) {

	packetInfo.L2_length = 0;
	packetInfo.L3_length = 0;
	packetInfo.L4_length = 0;
	packetInfo.destMac = "";
	packetInfo.srcMac = "";
	packetInfo.destIP = "";
	packetInfo.srcIP = "";
	packetInfo.destPort = "";
	packetInfo.srcPort = "";
	packetInfo.data_length = 0;
	packetInfo.ipv6ExtraHeaders = false;
}

/*
 * funkcia ktora z informacii o danom packete a filtroch spocita hodnotu1 pre vypis
 * ako parametre dostava argumenty programu a informacie o packete
 * vracia hodnotu1 packetu - teda celkovu dlzku packetu v zavislosti na filtroch
 */
unsigned int getOutputValue1(arguments &arg, packet_info &packetInfo) {

	unsigned int totalSize = packetInfo.L2_length + 
							 packetInfo.L3_length + 
							 packetInfo.L4_length + 
							 packetInfo.data_length;
	bool argMac = (arg.filterType == "mac");
	bool argIp = (arg.filterType == "ipv4") || (arg.filterType == "ipv6");
	bool argIp4 = (arg.filterType == "ipv4");
	bool argIp6 = (arg.filterType == "ipv6");
	bool argTransport = (arg.filterType == "tcp") || (arg.filterType == "udp");
    bool argTcp = (arg.filterType == "tcp");
    bool argUdp = (arg.filterType == "udp");

    if (argIp4 && packetInfo.L3_protocol != "4") {
        return 0;
    }
    if (argIp6 && packetInfo.L3_protocol != "6") {
        return 0;
    }
    if (argTcp && packetInfo.L4_protocol != "tcp") {
        return 0;
    }
    if (argUdp && packetInfo.L4_protocol != "udp") {
        return 0;
    }

    if ((arg.src) && (arg.dst)) {
		if (argMac) {
			return ((arg.filterValue == packetInfo.srcMac) || (arg.filterValue == packetInfo.destMac)) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP) && !isValidIP4(packetInfo.destIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP) && !isValidIP6(packetInfo.destIP)))
                return 0;
			return ((arg.filterValue == packetInfo.srcIP) || (arg.filterValue == packetInfo.destIP)) ? totalSize : 0;
		}
		if (argTransport) {
			return ((arg.filterValue == packetInfo.srcPort) || (arg.filterValue == packetInfo.destPort)) ? totalSize : 0;
		}
	}
	else if ((arg.src) && !(arg.dst)) {
		if (argMac) {
			return (arg.filterValue == packetInfo.srcMac) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP)))
                return 0;
            return (arg.filterValue == packetInfo.srcIP) ? totalSize : 0;
		}
		if (argTransport) {
			return (arg.filterValue == packetInfo.srcPort) ? totalSize : 0;
		}
	}
	else if (!(arg.src) && (arg.dst)) {
		if (argMac) {
			return (arg.filterValue == packetInfo.destMac) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.destIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.destIP)))
                return 0;
			return (arg.filterValue == packetInfo.destIP) ? totalSize : 0;
		}
		if (argTransport) {
			return (arg.filterValue == packetInfo.destPort) ? totalSize : 0;
		}
	}
	else {
		fputs("Invalid parameters\n", stderr);
        exit(1);
	}

}

/*
 * funkcia ktora z informacii o danom packete a filtroch spocita hodnotu2 pre vypis
 * ako parametre dostava argumenty programu a informacie o packete
 * vracia hodnotu2 packetu - teda dlzku niektorych hlaviciek a dat v zavislosti na filtri a parametroch
 */
unsigned int getOutputValue2(arguments &arg, packet_info &packetInfo, unsigned int packetNumber) {

	unsigned int totalSize = 0;
	bool argMac = (arg.filterType == "mac");
	bool argIp = (arg.filterType == "ipv4") || (arg.filterType == "ipv6");
	bool argIp4 = (arg.filterType == "ipv4");
    bool argIp6 = (arg.filterType == "ipv6");
    bool argTransport = (arg.filterType == "tcp") || (arg.filterType == "udp");
    bool argTcp = (arg.filterType == "tcp");
    bool argUdp = (arg.filterType == "udp");

    if (argIp4 && packetInfo.L3_protocol != "4") {
        return 0;
    }
    if (argIp6 && packetInfo.L3_protocol != "6") {
        return 0;
    }
    if (argTcp && packetInfo.L4_protocol != "tcp") {
        return 0;
    }
    if (argUdp && packetInfo.L4_protocol != "udp") {
        return 0;
    }
	if ((arg.src) && (arg.dst)) {
		if (argMac) {
			totalSize = packetInfo.L3_length + packetInfo.L4_length + packetInfo.data_length;
			return ((arg.filterValue == packetInfo.srcMac) || (arg.filterValue == packetInfo.destMac)) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP) && !isValidIP4(packetInfo.destIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP) && !isValidIP6(packetInfo.destIP)))
                return 0;
			totalSize = packetInfo.L4_length + packetInfo.data_length;
			return ((arg.filterValue == packetInfo.srcIP) || (arg.filterValue == packetInfo.destIP)) ? totalSize : 0;
		}
		if (argTransport) {
			totalSize = packetInfo.data_length;
			return ((arg.filterValue == packetInfo.srcPort) || (arg.filterValue == packetInfo.destPort)) ? totalSize : 0;
		}
	}
	else if ((arg.src) && !(arg.dst)) {
		if (argMac) {
			totalSize = packetInfo.L3_length + packetInfo.L4_length + packetInfo.data_length;
            return (arg.filterValue == packetInfo.srcMac) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP)))
                return 0;
			totalSize = packetInfo.L4_length + packetInfo.data_length;
			return (arg.filterValue == packetInfo.srcIP) ? totalSize : 0;
		}
		if (argTransport) {
			totalSize = packetInfo.data_length;
			return (arg.filterValue == packetInfo.srcPort) ? totalSize : 0;
		}
	}
	else if (!(arg.src) && (arg.dst)) {
		if (argMac) {
			totalSize = packetInfo.L3_length + packetInfo.L4_length + packetInfo.data_length;
			return (arg.filterValue == packetInfo.destMac) ? totalSize : 0;
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.destIP)))
                return 0;
            else if ((argIp6) && (!isValidIP6(packetInfo.destIP)))
                return 0;
			totalSize = packetInfo.L4_length + packetInfo.data_length;
			return (arg.filterValue == packetInfo.destIP) ? totalSize : 0;
		}
		if (argTransport) {
			totalSize = packetInfo.data_length;
			return (arg.filterValue == packetInfo.destPort) ? totalSize : 0;
		}
	}
	else {
		fputs("Invalid parameters\n", stderr);
        exit(1);
	}

}

/*
 * funkcia ktora pripocitava 2 hodnoty do struktury
 * ako vstup dostane povodne hodnoty a nove hodnoty
 * ako vystup vrati strukturu uz s novymi hodnotami
 */
output_values updateValues(output_values originalValue, unsigned int output_value1, unsigned int output_value2) {

	originalValue.output_value1 += output_value1;
	originalValue.output_value2 += output_value2;

	return originalValue;
}

/*
 * funkcia ktora na zaklade argumentov programu vytvara mapu, v ktorej su dlzky packetov pre jednotlive adresy/porty
 * berie do uvahy argumenty programu a na zaklade nich sa rozhoduje ci hodnoty vlozi do mapy alebo nie
 * ako vstupy dostane argumenty, informacie o packete a vystupnu mapu
 */
void insertToMap(arguments &arg, packet_info &packetInfo, map<string, output_values> &top10Map,
                 L2_header L2header, unsigned int packetLength) {

	bool argMac = (arg.filterType == "mac");
	bool argIp = (arg.filterType == "ipv4") || (arg.filterType == "ipv6");
	bool argIp4 = (arg.filterType == "ipv4");
    bool argIp6 = (arg.filterType == "ipv6");
    bool argTransport = (arg.filterType == "tcp") || (arg.filterType == "udp");
    bool argTcp = (arg.filterType == "tcp");
    bool argUdp = (arg.filterType == "udp");

    if (argIp4 && packetInfo.L3_protocol != "4") {
        return;
    }
    if (argIp6 && packetInfo.L3_protocol != "6") {
        return;
    }
    if (argTcp && packetInfo.L4_protocol != "tcp") {
        return;
    }
    if (argUdp && packetInfo.L4_protocol != "udp") {
        return;
    }

    unsigned int output_value1 = packetInfo.L2_length +
							 	 packetInfo.L3_length + 
							 	 packetInfo.L4_length + 
							 	 packetInfo.data_length;
	unsigned int output_value2 = 0;
	if (argMac) {
		output_value2 = packetInfo.L3_length + packetInfo.L4_length + packetInfo.data_length;
	}
	else if (argIp) {
		output_value2 = packetInfo.L4_length + packetInfo.data_length;
	}
	else if (argTransport) {
		output_value2 = packetInfo.data_length;
	}

    unsigned int pom = output_value2;
    if (L2header.totalLength != "") {
        if ((hexToInt(L2header.totalLength) + 14) < packetLength) {
            if (pom != 0) {
                pom -= packetLength - hexToInt(L2header.totalLength) - 14;
            }
        }
    }
    output_value2 = pom;

	output_values originalValue;


    if ((arg.src) && (arg.dst)) {
		if (argMac) {
			originalValue = top10Map[packetInfo.srcMac];
			top10Map[packetInfo.srcMac] = updateValues(originalValue,output_value1,output_value2);
			if (packetInfo.srcMac != packetInfo.destMac) {
                originalValue = top10Map[packetInfo.destMac];
                top10Map[packetInfo.destMac] = updateValues(originalValue, output_value1, output_value2);
            }
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP) && !isValidIP4(packetInfo.destIP)))
                return;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP) && !isValidIP6(packetInfo.destIP)))
                return;
			originalValue = top10Map[packetInfo.srcIP];
			top10Map[packetInfo.srcIP] = updateValues(originalValue,output_value1,output_value2);
            if (packetInfo.srcIP != packetInfo.destIP) {
                originalValue = top10Map[packetInfo.destIP];
                top10Map[packetInfo.destIP] = updateValues(originalValue, output_value1, output_value2);
            }
		}
		if (argTransport) {
            originalValue = top10Map[packetInfo.srcPort];
            top10Map[packetInfo.srcPort] = updateValues(originalValue,output_value1,output_value2);

            if (packetInfo.srcPort != packetInfo.destPort) {
                originalValue = top10Map[packetInfo.destPort];
                top10Map[packetInfo.destPort] = updateValues(originalValue, output_value1, output_value2);
            }
		}
	}
	else if ((arg.src) && !(arg.dst)) {
		if (argMac) {
			originalValue = top10Map[packetInfo.srcMac];
			top10Map[packetInfo.srcMac] = updateValues(originalValue,output_value1,output_value2);
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.srcIP)))
                return;
            else if ((argIp6) && (!isValidIP6(packetInfo.srcIP)))
                return;
			originalValue = top10Map[packetInfo.srcIP];
			top10Map[packetInfo.srcIP] = updateValues(originalValue,output_value1,output_value2);
		}
		if (argTransport) {
			originalValue = top10Map[packetInfo.srcPort];
			top10Map[packetInfo.srcPort] = updateValues(originalValue,output_value1,output_value2);
		}
	}
	else if (!(arg.src) && (arg.dst)) {
		if (argMac) {
			originalValue = top10Map[packetInfo.destMac];
			top10Map[packetInfo.destMac] = updateValues(originalValue,output_value1,output_value2);
		}
		if (argIp) {
            if ((argIp4) && (!isValidIP4(packetInfo.destIP)))
                return;
            else if ((argIp6) && (!isValidIP6(packetInfo.destIP)))
                return;
			originalValue = top10Map[packetInfo.destIP];
			top10Map[packetInfo.destIP] = updateValues(originalValue,output_value1,output_value2);
		}
		if (argTransport) {
			originalValue = top10Map[packetInfo.destPort];
			top10Map[packetInfo.destPort] = updateValues(originalValue,output_value1,output_value2);
		}
	}
	else {
		fputs("Invalid parameters\n", stderr);
        exit(1);
	}

}

/*
 * funkcia ktora prechadza cely subor pomocou streamu,
 * postupne ho cely rozparsuje a nakoniec vypise hodnoty na vystup
 * ako parametre dostava vstupny stream a parametre z konzole
 * vracia 0 v pripade uspechu, inu hodnotu v pripade neuspechu
 */
int readDataFromStream(ifstream &inputStream, arguments &arg) {

    char *skipBytes;

    // zistenie typu L2 hlaviciek packetov z globalnej hlavicky
    string linkLayerType = parseGlobalHeader(inputStream);

    // premenna na velkost dat v packetoch
    unsigned int dataSize = 0;

    // premenna oznacujuca poradie packetu
    int packetNumber = 1;

    // premenna na cislo pouziteho protokolu
    unsigned int protocolNumber = 0;

    // deklaracia struktury pre hlavicku packetov
	char *packetTimestampFirst = new char[1];

    // premenna do ktorych sa bude ukladat priebezne hodnota1 a hodnota2, ktore sa budu vypisovat
	unsigned int output_value1 = 0;
	unsigned int output_value2 = 0;

    // mapa, ktora sa bude vyuzivat pri filtri top10
	map<string, output_values> top10Map;

    // flag ktory urcuje ze na L3 vrstve neni Ipv4 ani Ipv6
    bool differentL3Header = false;

    // flag ktory urcuje ze na L4 vrstve neni Tcp ani Udp
    bool differentL4Header = false;

    // prechadzam cely stream az do konca
	while(inputStream.get(packetTimestampFirst[0])) {

        // deklaracia struktury packet_info, ktora bude ukladat vsetky informacie potrebne pre spravny vypis
		packet_info packetInfo;
        // vynulovanie hodnot v strukture
		clearInfo(packetInfo);
        unsigned int packetLength = 0;

		if (hexToInt(linkLayerType) == 16777216) { // ethernet

            // spracovanie packet hlavicky zo suboru
			packetLength = parsePacketHeader(inputStream,packetTimestampFirst);
            skipBytes = new char[packetLength];

            // spracovanie L2 hlavicky
			L2_header L2header;
			unsigned int ipVersion = parseL2header(L2header,inputStream,packetInfo);

			// ak ip verzia hlavicky je 4
			if (ipVersion == 4) {

				// spracovanie ipv4 hlavicky
				ipv4_header ipv4header;
				protocolNumber = parseIPV4header(ipv4header,L2header,inputStream,packetInfo);

				// ak na L4 vrstve je protokol TCP
				if (protocolNumber == 6) {

					// spracovanie TCP hlavicky
					tcp_header tcpHeader;
					parseTcpHeader(tcpHeader,inputStream,packetInfo);
					// vypocitana velkost dat je dlzka packetu minus dlzky hlaviciek
					dataSize = packetLength - 14 - L2header.l3headerLength - tcpHeader.l4headerLength;

                }
				else if (protocolNumber == 17) { // UDP

					// spracovanie udp hlavicky
					udp_header udpHeader;
					parseUdpHeader(udpHeader,inputStream,packetInfo);
             		// pri udp je dlzka dat ulozena v hlavicke
					dataSize = udpHeader.l4dataLength;

				}
				else { // ani TCP ani UDP
                    differentL4Header = true;
					// velkost dat je dlzka packetu minus dlzky L2 a L3 hlaviciek (14 + 20)
					dataSize = packetLength - 34;

				}
				// preskocenie dat
             	for (unsigned int i = 0; i < (dataSize); i++) {
			  		inputStream.get(skipBytes[i]);
				}
            }
			// verzia IPv6
			else if (ipVersion == 6) {

				// zparsovanie ipv6 hlavicky
				ipv6_header ipv6header;
				protocolNumber = parseIPV6header(ipv6header,inputStream,packetInfo);

				// ak nasleduje TCP hlavicka
				if (protocolNumber == 6) {

					// spracovanie tcp hlavicky
					tcp_header tcpHeader;
					parseTcpHeader(tcpHeader,inputStream,packetInfo);

					// dlzka dat je dlzka packetu minus dlzky hlaviciek
					dataSize = packetLength - 14 - packetInfo.L3_length - tcpHeader.l4headerLength;

				}
				else if (protocolNumber == 17) { // UDP

					// spracovanie udp hlavicky
					udp_header udpHeader;
					parseUdpHeader(udpHeader,inputStream,packetInfo);

					// pri udp je dlzka dat ulozena v hlavicke
					dataSize = udpHeader.l4dataLength;

				}
				else { // ak neni ani tcp ani udp
                    differentL4Header = true;
					dataSize = packetLength - 14 - packetInfo.L3_length;

				}
				// preskocenie dat
				for (unsigned int i = 0; i < (dataSize); i++) {
			  		inputStream.get(skipBytes[i]);
				}
			}
			else { // ak neni ani ipv4 ani ipv6

				for (int i = 0; i < (packetLength - 15); i++) {
					inputStream.get(skipBytes[i]);
				}
                if (arg.filterType == "mac") {
                    differentL3Header = true;
                }
                dataSize = 28;
                packetInfo.L2_length = packetLength - 28;
			}

            // do info struktury pridame informaciu o dlzke dat
			packetInfo.data_length = dataSize;

            // ak v danom packete nebolo Ipv4 ani Ipv6
            if (differentL3Header) {
                if (arg.filterValue != "top10") {
                    output_value1 += getOutputValue1(arg,packetInfo);
                    output_value2 += getOutputValue2(arg,packetInfo, packetNumber);
                }
                else {
                    insertToMap(arg,packetInfo,top10Map, L2header, packetLength);
                }
                differentL3Header = false;
            }
			// ipv6 moze mat viacero hlaviciek, len vtedy ak ide o filter mac a su tam tieto hlavicky tak zapiseme data
			else if ((!packetInfo.ipv6ExtraHeaders) || (arg.filterType == "mac")) {

                if (!(differentL4Header && (arg.filterType == "tcp" || arg.filterType == "udp"))) {

                    // ak podmienka neplati tak sa pytame ci ide o filter top10
                    if (arg.filterValue != "top10") {
                        // ak neide o filter top10 tak pripocitame hodnoty dlziek hlaviciek a packetov do premennych
                        output_value1 += getOutputValue1(arg, packetInfo);

                        unsigned int pom = getOutputValue2(arg, packetInfo, packetNumber);
                        if (L2header.totalLength != "") {
                            if ((hexToInt(L2header.totalLength) + 14) < packetLength) {
                                if (pom != 0) {
                                    pom -= packetLength - hexToInt(L2header.totalLength) - 14;
                                }
                            }
                        }

                        output_value2 += pom;
                    }
                        // ak ide o filter top10, pytame sa ci neide o packet nepodporovaneho typu
                    else if ((packetInfo.L2_length != 0) || (packetInfo.L3_length != 0) ||
                             (packetInfo.L4_length != 0) || (packetInfo.data_length != 0)) {
                        // ak je to v poriadku tak vlozime data do mapy
                        insertToMap(arg, packetInfo, top10Map, L2header, packetLength);
                    }
                }
                else {

                    differentL4Header = false;
                }
			}
            // zvysime hodnotu urcujucu poradie packetu
            packetNumber++;
		}
		else {  // ak nie je na L2 vrstve ethernetova hlavicka ide o chybu
            fputs("Not ethernet\n", stderr);
			exit(1);
		}
	}

	// ak sa nejedna o filter top10 tak vypiseme hodnotu 1 a 2
	if (arg.filterValue != "top10") {
		cout << output_value1 << " " << output_value2 << endl;
	}
	else { // ak sa jedna o filter top10

		// ulozime si dlzku mapy do premennej
		int mapSize = (int) top10Map.size();

		// iterujeme cez mapu maximalne 10x
		int iterator = 1;
		while (iterator <= 10) {

			// ak je menej prvkov nez 10 tak musime cyklus prerusit skor nez dojde do konca
			if (iterator > mapSize) {
				break;
			}
			// vyhladame polozku s maximalnou hodnotou v mape
			int maximum = 0;
			string maximumKey = "";
			for(auto elem : top10Map) {
				output_values tmp = elem.second;
				if (tmp.output_value1 > maximum) {
					maximum = tmp.output_value1;
					maximumKey = elem.first;
				}
			}
			// maximalnu hodnotu vlozime do premennej
			output_values maximumElement = top10Map[maximumKey];

			// vypiseme maximalnu hodnotu v danom formate
            string shortenedIpv6Address = "";
			if (arg.filterType == "ipv6") {
                shortenedIpv6Address = convertLongIPv6ToShort(maximumKey);
                cout << shortenedIpv6Address << " " << maximumElement.output_value1 << " " << maximumElement.output_value2 << endl;
            }
            else {
                cout << maximumKey << " " << maximumElement.output_value1 << " " << maximumElement.output_value2 << endl;
            }
			// zmazeme maximum z pola a pokracujeme v cykle od zaciatku
			top10Map.erase(maximumKey);
			iterator++;
		}
	}
    delete[](skipBytes);
    delete[](packetTimestampFirst);
    return 0;
}

/*
 * Hlavny pristupovy bod do programu
 */
int main(int argc, char *argv[]) {

    // struktura obsahujuca vsetky parametre programu z konzole
	arguments arg;

    // volanie funkcie, ktora parsuje a validuje argumenty konzole
    if (!parseArguments(argc,argv,arg)) {
        fputs("Invalid parameters\n", stderr);
        exit(1);
    }

    // konverzia ipv6 do plneho tvaru ak je to potrebne
    if ((arg.filterType == "ipv6") && (arg.filterValue != "top10")) {
		arg.filterValue = convertShortIPv6ToLong(arg.filterValue);	
    }

    // nastavenie vstupneho suboru
    string inputFile = arg.inputFileName;

    // vytvorenie streamu na nacitavanie binarnneho suboru
    ifstream inputStream(inputFile, ios::in | ios::binary);
	// kontrola validity suboru
    if (!inputStream.good()) {
        fputs("Invalid file name\n", stderr);
		exit(1);
	}

    // volanie funkcie ktora prechadza subor
	return readDataFromStream(inputStream,arg);
}